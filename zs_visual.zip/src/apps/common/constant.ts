/** @format */
const RSA_PUBLIC_PKC_1 = `
-----BEGIN RSA PUBLIC KEY-----
MIGJAoGBAMnesoVaXu3Ery02pQIc96zI2nGPq+tXtwHI6mwISdvh6GFc9MjCFegO
9Uahn6ikl9TWHFtOwZjkhXy1d7t8rJTLftykJ+RaKwqwDF1V0z5PDKeBh7mFmZcH
k7bXPP5Dt06pEzqML0Wv6bakI7VhK/C/+5gOt9XpfOvHg43Z+lcxAgMBAAE=
-----END RSA PUBLIC KEY-----
`
const RSA_PRIVATE_PKC_1 = `
-----BEGIN RSA PRIVATE KEY-----
MIICXQIBAAKBgQDJ3rKFWl7txK8tNqUCHPesyNpxj6vrV7cByOpsCEnb4ehhXPTI
whXoDvVGoZ+opJfU1hxbTsGY5IV8tXe7fKyUy37cpCfkWisKsAxdVdM+TwyngYe5
hZmXB5O21zz+Q7dOqRM6jC9Fr+m2pCO1YSvwv/uYDrfV6Xzrx4ON2fpXMQIDAQAB
AoGAHrT6cOCDSiW+A+GpDf48CpNu7xFMtHreQq4+QnqsSX8+qvjJ33PugyMrWjgh
ojSPR/fdzmHXfxtb1tF/ygw38BEKL5o65Fx1WrEyrepS6RBLnSfDhi9qNXodjNpP
/Tz4r605nzVIigyq/hAlT8fe8zIdjfLOFVO9ACaYjKUT1rUCQQDyhzcbzUe5qq1g
oeilAXba2Z1bfrvtZaWz65Z+74yfUUUx1P0lL2HZNvmmjzN65cBurNrE3SK2AlC4
UzZ6E1lzAkEA1RVQ1KKnU4wE6CYK3W3tRlF1WeqJMMFc8RJw1A59MvKxdsyE+U2C
ykSoHAbIlz1AInLedRJ/lvQMIxKSjM2zywJBALG0SbjhTTDJ0of/mots6z2oPhiQ
X/quhB+0+2y+8Xa7Acxll6brdPLHyV01iC8AsWNm3FVrAsgCIkstDbmc++kCQDGY
koXLjhK+Jm46XJEJgw646w2Qr3nvp8hcuHJDJRT0tCWomNLGHckijdZoJcw9722V
Ov4Y3iWujByluAKZ5l0CQQDLdN0Iz/2AGm7G8PyA8oenFH4NDOxXlRwLCzXlVDuI
X5Ap9YS8mE406E65d8+67z0Xt5kXg34Vi7neK0/hLINP
-----END RSA PRIVATE KEY-----
`
const RSA_PRIVATE_PKC_8 = `
-----BEGIN PRIVATE KEY-----
MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBAN9ZB5+D6Iu1PFbz
lW/HiwXuLjy7D5pzhrupOEVOtlf0mGmaDglucL62SCLK9Wxz46G/7LU+Z3UTJnGd
Xb4en07Eys2OT8PWNnu4xrNq6qnq1K3Xv6nLyk4VVBHGMsQOTmyBSz9R5PZMAhpa
nDiwcBcp2Xr2OJFTdYmMgFAX0bGrAgMBAAECgYBqftgMrmfmnb8ssq6xgtL+O+ie
Go/BFI7M0k47deGqJL27tLI2uwtVVDMnK+FEGioTCSGD9kJ8Z2owSFnXemB42YJV
smdSXq9brPtzoPurKXfP6T5GUx+Ce6nJ6NfXa66YuSV0BlHWZQEUk7U5zLi3Brt7
XUBW0iYlF/ewbiqmqQJBAO+2X0vKgXqmzHTmat0DuHzPhW2+i+DaqPERkSwbWFZp
PHM4U+sSG4Qia2Y8+37Rf3g+ns00TEwxu+zzJd1vMOcCQQDuhgGsbhGa/wXQSEEt
fj6qUL6o4vsnmeZgDYjhDg4LMazwnwv519Z9Q1AdT3TioCBnDzKQ8jabIq4Ouvsj
3yydAkEAoMp78aLMZzErQ96rH8U3IsEwhwShXxpM6CcYcbWF87BzU/YclDl5K5DK
6bFOISr1jfqzGoJSC2nw3GfcpkPHUQJBAO5lZXrPsCz4Qvk/nlU33q4fcdAevOOB
wG20WWCGyaaKic0dSbz26tvb0VDaP3rajEg1OlcAn29CpDD41VWvE0kCQQDNct/a
RKUBg6ZuGG/ofUOfBWynpOSuZX8INWNP+1R6VckiKNwXTeQinUtHVik+S08mWEH4
gD0zCTNRDDe/jMxQ
-----END PRIVATE KEY-----
`
const RSA_PUBLIC_PKC_8 = `
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDfWQefg+iLtTxW85Vvx4sF7i48
uw+ac4a7qThFTrZX9Jhpmg4JbnC+tkgiyvVsc+Ohv+y1Pmd1EyZxnV2+Hp9OxMrN
jk/D1jZ7uMazauqp6tSt17+py8pOFVQRxjLEDk5sgUs/UeT2TAIaWpw4sHAXKdl6
9jiRU3WJjIBQF9GxqwIDAQAB
-----END PUBLIC KEY-----
`
const enum GlobalVariable {
  AUTH_FAILED_URL = '/auth_failed',
  AUTH_FAILED_TEMP_URL = '/auth_failed_temp',
  BOARD_SHARE_AES_KEY = '91016ece016543b584f48e0666678cc7',
  HTTP_HEADER_ORIGIN = 'CredEx',
}
const enum HttpHeaderContentType {
  JSON = 'application/json; charset=utf-8',
  UPLOADFILE = 'multipart/form-data',
  FORMDATA = 'application/x-www-form-urlencoded; charset=utf-8',
  HTML = 'text/html; charset=utf-8',
  TEXT = 'text/plain; charset=utf-8',
}
interface EncryptAndDecryptKey {
  RSA_PUBLIC_PKC_1: string
  RSA_PRIVATE_PKC_1: string
  RSA_PRIVATE_PKC_8: string
  RSA_PUBLIC_PKC_8: string
}
const EncryptAndDecryptKeys: EncryptAndDecryptKey = {
  RSA_PRIVATE_PKC_1,
  RSA_PUBLIC_PKC_1,
  RSA_PRIVATE_PKC_8,
  RSA_PUBLIC_PKC_8,
}
export { GlobalVariable, EncryptAndDecryptKeys, HttpHeaderContentType }
