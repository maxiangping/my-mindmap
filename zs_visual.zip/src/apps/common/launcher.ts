/** @format */

import PopLayer from '@/apps/components/popLayer'
import { VAsset, VFoucs, VInput, VTouch, VTap, VEditor, VMouse } from '@/apps/directives/index'
import '@/apps/hooks'
import { isEmpty, isNull, throttle } from '@/apps_modules/functor'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import { store as storeInstance } from '@/store'
import { SESSION_KEY, setSessionKey } from '@/store/net/modules/auth'

import Vue, { CreateElement, VueConstructor } from 'vue'
import VueRouter, { NavigationGuard, RawLocation, Route, RouteRecord } from 'vue-router'
import { Store } from 'vuex'
import { AppImporter, GenericsModule, RouteImporter } from './dynImporter'
// import { clearTimer, startTimer } from '@/store/net/modules/config'

export type LaunchHandle = (vue: VueConstructor) => Promise<void>

/**
 * 功能: 默认授权方案
 * @param to
 * @param _
 * @param next
 */
export const defAuthHandle = async (
  to: Route,
  _: Route,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  next: (to?: RawLocation | false | ((vm: Vue) => any) | void) => void
) => {
  const authurl = isEmpty(to.redirectedFrom) ? to.fullPath : to.redirectedFrom
  if (to.matched.some((record: RouteRecord) => record.meta.requiresAuth)) {
    if (storeInstance.getters['Auth/requireAuth']) {
      next({
        name: 'AuthFailed',
        query: {
          callback: authurl,
        },
      })
      return
    }
  }
  next()
}

const loadRouter = async (explorer: PROJECT | PROJECT[], joinBaseConfigure = true): Promise<VueRouter> => {
  // 加载菜单
  return new RouteImporter(explorer, joinBaseConfigure ? [GenericsModule.base] : []).genericsVariable()
}

export type RegisterModule = (store: Store<RootState>) => void

export const visibilitychange = async () => {
  const status = document.visibilityState === 'visible' || !document.hidden
  // if (status) {
  //   startTimer()
  // } else {
  //   clearTimer()
  // }
  await storeInstance.dispatch('Client/visibilitychange', status, {
    root: true,
  })
}

const dispatchResize = async () => {
  await storeInstance.dispatch('Client/resize', [document.body.clientWidth, document.body.clientHeight], {
    root: true,
  })
}

const cleanup = () => {
  const loadingPanel = document.querySelector('#loading-panel')
  if (loadingPanel !== null) {
    loadingPanel.remove()
  }
}

interface LauncherArgument {
  beforeLaunch?: LaunchHandle
  authRouter?: NavigationGuard
  registerModule?: RegisterModule | RegisterModule[]
  explorer: PROJECT | PROJECT[]
  baseConfigure?: boolean
  autoLoad?: boolean
}

export class Launcher {
  private readonly beforeLaunch?: LaunchHandle
  private readonly authRouter?: NavigationGuard
  private readonly registerModule?: RegisterModule | RegisterModule[]
  private readonly explorer: PROJECT | PROJECT[]
  private readonly baseConfigure?: boolean
  public readonly autoLoad?: boolean

  public constructor({
    beforeLaunch,
    authRouter,
    registerModule,
    explorer,
    baseConfigure,
    autoLoad = false,
  }: LauncherArgument) {
    this.beforeLaunch = beforeLaunch
    this.authRouter = authRouter
    this.registerModule = registerModule
    this.explorer = explorer
    this.baseConfigure = baseConfigure
    this.autoLoad = autoLoad
  }

  private static bindDirective() {
    Vue.directive('tap', VTap)
    Vue.directive('asset', VAsset)
    Vue.directive('editor', VEditor)
    Vue.directive('touch', VTouch)
    Vue.directive('input', VInput)
    Vue.directive('focus', VFoucs)
    Vue.directive('mouse', VMouse)
  }

  public async launch() {

    //sessionId
    const shareToken = 'eyJhbGciOiJIUzI1NiJ9.eyJwcm9OdW0iOiJ6eHdkanoiLCJzdWIiOiLpu5jorqTliIbkuqvnlKjmiLciLCJwcm9JbmZvIjoiWEplcnVZTUM3NHkyeUg0SlV3SnM2Wm9YbWtsaWd0M01va3dOdFVMRWJoZVdqdW5Ob0haY2dKTStCZTFJbnliZ1MreHUyTG1WdVU5akRoWlNUZFpqUjVqOGJEVVhTNFdJR05FaGFJWlVQWHEyTEZ6VUNsbEtzc1RvZnNjVnFBQlpBcFpON2N6UVZZbG9BU0l2WGg1OEJpc1JWdHQ2OHU4MVYzdzVSNVB6UXhUWlhWbjJhOTUvbko0cy95a3QwTFpRQWh0cWJ6TStEeFZhQVpQQ09oaGRCUkZYbzBpK0dnZ1FvK0NwYkZwTkZYTVZvTE5jMnJOUEkwdVRHVnprK0pwQnVha21zZW1CWlFFa2RBUklNM2N2bzBOVVhtcWtyclozMXBsVEQ5UHM3T2ZLdE9LREd3RGhtYmxjUlFTNUEyMUFGMU40UTM3Q3F3U1NmZUFWSEFnYklUZFNPdTVMeUJpdlZEczkraS9majB2SEhDV1hBUFo4M2NKa0RrUUxsNTNmT2s3ditwSExXOCtTT1VrclVhSm54MTFYWERIZ1JRVEkzZmo5S01rKzE0cXdOS2tBZzBCWTRyd2wwbVVGdFVBdit3ckFSeHcrdkNqRU5jZW1BaTZpTXQ2V1NQVGFPZkpjVDlSZmpQZXpzbkpwdm11RE4xSSsvOXEvNytrQXBGYnFoNnpRWkorUXpuS0loWFZPbTYxbk43RG1LSXljRE5JTlRaeWJOdUhtWXc3TCtoTVd6YU5TeXcyd0RwcGcraTlLV2tXYnI1bHIzNkJNOFg3V0ZhQlJKVzNFN0dheWw2QktRenlSV0Y1anhRaWdaRW95Nmh5SWV2bFIydk5jT3dib0R0RGdyWEZEbDlGYy9abzBlTUNBdXUrb0dmZzBDVUM4SW4rak9ZSU5QS2c9IiwiZXhwIjoxOTQ2NDQ4Mzk4LCJ1c2VyIjp7InZlcnNpb24iOiI5NGNjNjVjMy01NDExLTQxODctOTU2OS05ZGQ4YTRlMDY4YWEiLCJleHBpcmVUaW1lIjozMTUzNjAwMDAwMDAsImlkIjowfSwiaWF0IjoxNjMxMDg4Mzk4LCJqdGkiOiI5NGNjNjVjMy01NDExLTQxODctOTU2OS05ZGQ4YTRlMDY4YWEifQ.mvwyjgxjVJg9DOSOCMSvXM4KzZA-u9pqnXcl1ejlNgA'
    setSessionKey(SESSION_KEY.SHARE_TOKEN, shareToken)

    if (!isNull(this.beforeLaunch)) {
      await this.beforeLaunch(Vue)
    }
    Launcher.bindDirective()

    // 注册modules
    if (!isNull(this.registerModule)) {
      const _registedModules_ = Array.isArray(this.registerModule) ? this.registerModule : [this.registerModule]

      _registedModules_.map(async registerModule => {
        registerModule(storeInstance)
      })
    }

    const router = await this.routeInterceptor()

    this.mountPopLayer(router)
      .then(() => this.mountApp(router))
      .then(() => {
        // startTimer()
      })
    // this.mountPopLayer(router)

    cleanup()

    await dispatchResize()
  }

  public resized<T>() {
    let timer!: number
    return throttle<T>(() => {
      clearTimeout(timer)
      timer = window.setTimeout(dispatchResize, 1e2)
    }, 2e2)
  }

  private async routeInterceptor(): Promise<VueRouter> {
    Vue.use(VueRouter)
    const router = await loadRouter(this.explorer, this.baseConfigure)

    router.beforeEach(!isNull(this.authRouter) ? this.authRouter : defAuthHandle)

    return router
  }

  private async mountApp(router: VueRouter) {
    const projectName = process.env.VUE_APP_PROJECT_NAME
    const appImporter = new AppImporter(projectName as PROJECT)
    const app = await appImporter.genericsVariable()
    // const explorer = await storeInstance.dispatch('Explorer/syncExplorer', {
    //   projectName: projectName as string,
    //   sync: true,
    // })
    // const currentRoute = router.currentRoute
    // if (isNull(explorer) && this.autoLoad) {
    //   const count = Number(window.sessionStorage.getItem('reload'))
    //   if (count > 2) return
    //   window.sessionStorage.setItem('reload', `${count + 1}`)
    //   window.location.reload()
    // }
    // if (!isNull(explorer) && !Array.isArray(explorer)) {
    //   if (explorer.code !== 400) {
    //     return Promise.reject()
    //   }
    // }

    // let url = GlobalVariable.AUTH_FAILED_URL as string
    // if (Array.isArray(explorer)) {
    // url = currentRoute.path
    // if (currentRoute.path === GlobalVariable.AUTH_FAILED_URL) {
    //   url = '/'
    // }
    // url = currentRoute.path === GlobalVariable.AUTH_FAILED_URL ? '/' : currentRoute.path
    // }
    // if (currentRoute.path !== url && !this.autoLoad) {
    if (router.currentRoute.name !== 'Home') {
      await router.replace({ path: '/home/0' })
    }
    // }
    // window.sessionStorage.removeItem('reload')
    return new Promise<void>((resolve, reject) => {
      new Vue({
        router,
        store: storeInstance,
        errorCaptured: reject,
        mounted: resolve,
        render: (h: CreateElement) => h(app),
      }).$mount('#app')
    })
  }

  private mountPopLayer(router: VueRouter) {
    return new Promise<void>((resolve, reject) => {
      new Vue({
        router,
        store: storeInstance,
        errorCaptured: reject,
        mounted: resolve,
        render: (h: CreateElement) => h(PopLayer),
      }).$mount('#poplayer')
    })
  }
}
