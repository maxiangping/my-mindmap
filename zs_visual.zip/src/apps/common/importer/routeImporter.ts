/** @format */

import { Importer } from '@/apps/common/importer/importer'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import VueRouter, { RouteConfig } from 'vue-router'
import { GenericsModule } from './conf'

export class RouteImporter extends Importer {
  public constructor(protected _projects: PROJECT | PROJECT[], protected _modules: GenericsModule | GenericsModule[]) {
    super(_projects, _modules)
  }

  public async genericsVariable(): Promise<VueRouter> {
    const imports = await Promise.all(super.projects.map(this.dynImport))
    const modules = await Promise.all(super.modules.map(this.importByModule))
    const routes = [imports, modules].flat(2)

    return new VueRouter({
      base: process.env.BASE_URL,
      mode: 'history',
      routes,
    })
  }

  protected async importByModule(module: GenericsModule): Promise<RouteConfig[]> {
    const m = await import(`@/apps/router/routes/${module}`)
    return m.default
  }

  protected async dynImport<T = RouteConfig[]>(project: PROJECT): Promise<T> {
    // todo
    const { routes } = await import(`@/apps/app_${project}/router/index`)
    return routes
  }
}
