/** @format */

export const enum GenericsModule {
  base = 'base',
  example = 'example',
}
