/** @format */

import { GenericsModule } from '@/apps/common/importer/conf'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import Vue, { VueConstructor } from 'vue'

export abstract class Importer {
  protected constructor(private __projects: PROJECT | PROJECT[], private __modules: GenericsModule | GenericsModule[]) {
    // nothing here
  }

  protected get projects() {
    return this.toArray<PROJECT>(this.__projects)
  }

  protected get modules() {
    return this.toArray<GenericsModule>(this.__modules)
  }

  protected toArray<T>(val: T | T[]): T[] {
    return Array.isArray(val) ? val : [val]
  }

  protected abstract async dynImport(project: PROJECT): Promise<VueConstructor<Vue>>
}
