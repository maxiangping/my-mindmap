/** @format */

import { Importer } from '@/apps/common/importer/importer'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import Vue, { VueConstructor } from 'vue'

export class AppImporter extends Importer {
  public constructor(protected _projects: PROJECT) {
    super(_projects, [])
  }

  public async genericsVariable(): Promise<VueConstructor<Vue>> {
    return this.dynImport()
  }

  protected async dynImport(): Promise<VueConstructor<Vue>> {
    const md = await import(`@/apps/components/app/view.vue`)
    return md.default as VueConstructor<Vue>
  }
}
