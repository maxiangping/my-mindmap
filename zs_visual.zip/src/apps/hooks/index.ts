/** @format */

import Component from 'vue-class-component'

Component.registerHooks(['beforeRouteUpdate', 'beforeRouteEnter', 'beforeRouteLeave'])
