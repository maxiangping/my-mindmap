<!-- @format -->
<template>
  <div class="count-percent full pr flex xy-axis-center">
    <chart
      :chart-option="chartOption"
      :data-source="chartDataSource"
      :key="chartId"
    ></chart>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
