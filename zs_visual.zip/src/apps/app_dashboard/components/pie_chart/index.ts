/** @format */

import { Component, Mixins } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { getUuid } from '@/apps_modules/toolbox/math'
import { confCreator, SINGLE_SERIES_CHARTS } from '@/apps_modules/fusionchart/types'
import { chartConfig } from './config'
import { deepCopy } from '@/apps_modules/functor'

@Component({
  name: 'PieChart',
  components: {
    NumberUnit,
    chart: async () => {
      return import(/* webpackChunkName: 'fusionchart_comp' */ '@/apps/components/chart.fc')
    },
  },
})
export default class PieChartController extends Mixins(ChartRequestMixins) {
  public chartId = getUuid()

  public chartOption = confCreator(SINGLE_SERIES_CHARTS.PIE_2D)

  public get chartDataIdMap() {
    return (
      this.charDataList[0]?.data.reduce((map: Record<string, string[]>, item) => {
        map[item[0]] = item
        return map
      }, {}) ?? {}
    )
  }

  public getDataById(id: number | string) {
    return this.chartDataIdMap[`ID000${id}`]?.[2] ?? '0'
  }

  public get totalValue() {
    return this.item.categoryLabels?.map((item,index) => {
      return {
        label: item,
        value:this.getDataById(this.item.categoryIds?.[index] ?? '')
      }
    }) ?? []
  }




  public get chartData() {
    return  this.totalValue
  }

  public get chartDataSource(): IFCDataSource {
    this.chartId = getUuid()
    const chartConfigItem = deepCopy(chartConfig)
    if(this.item.categoryColors) {
      chartConfigItem.paletteColors = this.item.categoryColors
    }

    return {
      chart: chartConfigItem,
      data: this.chartData,
    }
  }


}
