/** @format */
import { Component, Prop, Vue } from 'vue-property-decorator'
@Component({
  name: 'ChartBorder',
  components: {},
})
export default class ChartBorder extends Vue {
  @Prop({ type: String, default: '' })
  public title!: string
  @Prop({ type: String, default: '' })
  public subTitle!: string

  @Prop({ type: String, default: 'rgba(60,73,222,0.08)' })
  bg!: string
}
