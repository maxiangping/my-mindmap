<!-- @format -->

<template>
  <section class="chart-border flex -column" :style="{ background: bg }">
    <div class="module-title" v-show="title">
      {{ title }}
      <span class="sub-title pr" v-show="subTitle">(&nbsp;{{ subTitle }}&nbsp;)</span>
    </div>
    <img v-asset:src="`icon/dashboard/home/border_angle.svg`" alt="" class="angle pa left top" />
    <img v-asset:src="`icon/dashboard/home/border_angle.svg`" alt="" class="angle pa left bottom" />
    <img v-asset:src="`icon/dashboard/home/border_angle.svg`" alt="" class="angle pa right top" />
    <img v-asset:src="`icon/dashboard/home/border_angle.svg`" alt="" class="angle pa right bottom" />
    <div class="border-content">
      <slot></slot>
    </div>
  </section>
</template>

<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
