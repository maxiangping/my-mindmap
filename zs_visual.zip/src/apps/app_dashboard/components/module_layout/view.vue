<!-- @format -->

<template>
  <div class="page-wrap flex full" :class="[`flex-${layoutType}`]">
    <div
      class="out-wrap flex"
      :class="[`out-${layoutType}`]"
      v-for="(item, index) in data"
      :key="index"
      :style="`flex: ${item.size};${item.style}`"
    >
      <div
        class="inner-wrap"
        :class="[`inner-${layoutType}`]"
        v-for="(chart,chartIndex) in item.chartList"
        :key="chartIndex"
        :style="`flex: ${chart.size};${chart.style}`"
      >
        <chart-border :title="chart.title" :subTitle="getChartSubTitle(chart)">
          <component :is="chart.contentName" :item="chart"></component>
        </chart-border>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>

<style src="./style.less" lang="less" scoped></style>
