/** @format */
import { Component, Prop, Vue } from 'vue-property-decorator'
import { chartBorder, PieChart } from '@/apps/app_dashboard/components/index'
import {
  HomeBoardProfit,
  HomeBoardMonthContrast,
  HomeBoardBankContrast,
  HomeBoardManageScale,
} from '@/apps/app_dashboard/components/huaxia_board/homeBoard'
import {
  DepositBoardRemainder,
  DepositBoardAverageRemainder,
  DepositBoardIncreaseCount,
  DepositBoardAverageIncreaseCount,
  DepositBoardIncreaseCountChart,
  DepositBoardAverageIncreaseChart,
} from '@/apps/app_dashboard/components/huaxia_board/depositBoard'
import { BoardChartItem } from '@/store/model/dashboard/home'
@Component({
  name: 'ModuleLayout',
  components: {
    chartBorder,
    PieChart,
    HomeBoardProfit,
    HomeBoardMonthContrast,
    HomeBoardBankContrast,
    HomeBoardManageScale,
    DepositBoardRemainder,
    DepositBoardAverageRemainder,
    DepositBoardIncreaseCount,
    DepositBoardAverageIncreaseCount,
    DepositBoardIncreaseCountChart,
    DepositBoardAverageIncreaseChart,
  },
})
export default class ModuleLayoutController extends Vue {
  @Prop({ type: String })
  public layoutType!: string

  @Prop({ type: Array, default: () => [] })
  public data!: unknown[][]

  public getChartSubTitle(chart: BoardChartItem) {
    return chart.date ? `${chart.date} ${chart.subTitle}` : `${chart.subTitle}`
  }
}
