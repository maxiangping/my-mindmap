<!-- @format -->
<template>
  <div class="manage-scale full flex -column">
    <div class="top-part full-w flex pr">
      <div class="top-left flex -column">
        <div class="total-remainder row-part flex -column x-space-between">
          <div class="remainder-row full-w flex y-axis-center" v-for="(row, index) in totalRemainder" :key="index">
            <number-unit
              v-for="item in row"
              :class="`total-number-${index}`"
              :key="item.headText"
              :headText="item.headText"
              :contentFontSize="item.contentFontSize"
              :contentMargin="item.contentMargin"
              :headHeight="item.headHeight"
              :headFontSize="item.headFontSize"
              :contentHeight="item.contentHeight"
              :content="item.content"
              :unitMargin="item.unitMargin"
              :isBlock="item.isBlock"
              :unit="item.unit"
              :color="item.color"
            ></number-unit>
          </div>
        </div>
        <!-- <div class="definite-remainder row-part flex -column">
          <div class="definite-count flex -column x-axis-center">
            <div
              class="definite-count-item flex y-axis-center x-space-between"
              v-for="item in definiteCountList"
              :key="item.label"
            >
              <span class="full-h flex y-axis-center">
                <img v-asset:src="`icon/huaxia/${item.label}.svg`" class="full-h mr-8" alt="" />
                <span>{{ item.value[0] }}</span>
              </span>
              <span class="full-h flex y-axis-center">
                <div>{{ item.value[1] }}亿元</div>
                <div class="ml-40">{{ item.value[2] }}户</div>
              </span>
            </div>
          </div>
          <div class="average-count flex x-space-between">
            <number-unit
              v-for="item in averageRemainder"
              class="average-number"
              :key="item.headText"
              :headText="item.headText"
              :contentFontSize="item.contentFontSize"
              :contentMargin="item.contentMargin"
              :headHeight="item.headHeight"
              :headFontSize="item.headFontSize"
              :contentHeight="item.contentHeight"
              :content="item.content"
              :unitMargin="item.unitMargin"
              :isBlock="item.isBlock"
              :unit="item.unit"
              :color="item.color"
            ></number-unit>
          </div>
        </div> -->
      </div>
      <div class="top-right flex -column">
        <div class="total-remainder row-part flex -column x-space-between">
          <div class="remainder-row flex y-axis-center" v-for="(row, index) in definiteRemainder" :key="index">
            <number-unit
              v-for="item in row"
              class="total-number"
              :key="item.headText"
              :headText="item.headText"
              :contentFontSize="item.contentFontSize"
              :contentMargin="item.contentMargin"
              :headHeight="item.headHeight"
              :headFontSize="item.headFontSize"
              :contentHeight="item.contentHeight"
              :content="item.content"
              :unitMargin="item.unitMargin"
              :isBlock="item.isBlock"
              :unit="item.unit"
              :color="item.color"
            ></number-unit>
          </div>
        </div>
        <!-- <div class="definite-remainder row-part flex -column">
          <div class="full-h flex -column x-space-around">
            <div
              class="average-count-item flex y-axis-center x-space-between"
              v-for="item in averageDefiniteRemainder"
              :key="item.label"
            >
              <span class="full-h flex y-axis-center">
                <img v-asset:src="`icon/huaxia/${item.label}.svg`" class="full-h mr-8" alt="" />
                <span>{{ item.value[0] }}</span>
              </span>
              <span class="full-h flex y-axis-center">
                <div>{{ item.value[1] }}亿元</div>
                <div class="ml-40">{{ item.value[2] }}户</div>
              </span>
            </div>
          </div>
        </div> -->
      </div>
      <div class="pa middle-img flex -column xy-axis-center">
        <img v-asset:src="`icon/huaxia/circle.svg`" class="full pa" alt="" />
        <div class="circle-bg pa" :style="{ height: loanPercent + '%' }"></div>
        <div class="middle-label">存贷比</div>
        <div class="middle-value">{{ loanPercent }}%</div>
      </div>
      <div class="middle-line pa"></div>
    </div>
    <div class="bottom-part full-w pr flex y-axis-center">
      <img v-asset:src="`icon/huaxia/bottom_bg.svg`" class="bottom-bg pa full-w" alt="" />
      <div class="bottom-left flex y-axis-center">
        <img v-asset:src="`icon/huaxia/bottom_head.svg`" alt="" class="bottom-head" />
        <number-unit
          v-for="(item, index) in customerCount"
          :key="item.headText"
          :class="[`bottom-number-${index}`, 'bottom-number']"
          :headText="item.headText"
          :contentFontSize="item.contentFontSize"
          :contentMargin="item.contentMargin"
          :headHeight="item.headHeight"
          :headFontSize="item.headFontSize"
          :contentHeight="item.contentHeight"
          :content="item.content"
          :unitMargin="item.unitMargin"
          :isBlock="item.isBlock"
          :unit="item.unit"
          :color="item.color"
        ></number-unit>
      </div>
      <div class="bottom-right flex y-axis-center">
        <number-unit
          class="bottom-right-item"
          v-for="item in definiteCustomer"
          :key="item.headText"
          :headText="item.headText"
          :contentFontSize="item.contentFontSize"
          :contentMargin="item.contentMargin"
          :headHeight="item.headHeight"
          :headFontSize="item.headFontSize"
          :contentHeight="item.contentHeight"
          :content="item.content"
          :unitMargin="item.unitMargin"
          :isBlock="item.isBlock"
          :unit="item.unit"
          :color="item.color"
        ></number-unit>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
