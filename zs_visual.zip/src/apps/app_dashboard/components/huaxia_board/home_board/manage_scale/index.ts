/** @format */

import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import {  numberSplitByThousandth } from '@/apps/app_dashboard/common/util'
import { CommonSelectData } from '@/store/model/common'
import { NumberUnitItem } from '@/store/model/dashboard/home'
import { Component, Mixins } from 'vue-property-decorator'
@Component({
  name: 'HomeBoardManageScale',
  components: {},
})
export default class HomeBoardManageScaleController extends Mixins(ChartRequestMixins) {
  public get loanPercent() {
    return Number(this.getDataById(61)).toFixed(2)
  }

  public get customerCount(): NumberUnitItem[] {
    return [
      {
        headText: '客户总数',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(Number(this.getDataById(62))),
        unit: '户',
        isBlock: false,
        contentHeight: 38,
        contentFontSize: 32,
        contentMargin: '4px 4px 0 0',
        unitMargin: '0 0 4px 0',
        color: '#48d1ff',
      },
      {
        headText: '较年初增量',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(Number(this.getDataById(63))),
        unit: '户',
        isBlock: false,
        contentHeight: 24,
        contentFontSize: 20,
        contentMargin: '8px 4px 0 0',
        unitMargin: '3px 0 0 0',
      },
      {
        headText: '较年初增速',
        headHeight: 21,
        headFontSize: 18,
        content: Number(this.getDataById(64)).toFixed(2),
        isBlock: false,
        unit: '%',
        contentHeight: 24,
        contentFontSize: 20,
        contentMargin: '8px 4px 0 0',
        unitMargin: '3px 0 0 0',
        color: '#48d1ff',
      },
    ]
  }

  public get definiteCustomer(): NumberUnitItem[] {
    return [
      {
        headText: '对公客户数',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(Number(this.getDataById(65))),
        isBlock: false,
        contentHeight: 24,
        contentFontSize: 20,
        contentMargin: '10px 4px 0 0',
        unitMargin: '3px 0 0 0',
        unit: '户',
      },
      {
        headText: '个人客户数',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(Number(this.getDataById(66))),
        isBlock: false,
        contentHeight: 24,
        contentFontSize: 20,
        contentMargin: '10px 4px 0 0',
        unitMargin: '3px 0 0 0',
        unit: '户',
      },
    ]
  }

  public get totalRemainder(): NumberUnitItem[][] {
    return [
      [
        {
          headText: '存款余额',
          headHeight: 21,
          headFontSize: 18,
          // content: '1,788.31',
          content: numberSplitByThousandth(this.toUnitValue(this.getDataById('04'))),
          isBlock: false,
          contentHeight: 48,
          contentFontSize: 36,
          contentMargin: '8px 0 0 0',
          unitMargin: '0 0 4px 0',
        },
        {
          headText: '户数',
          headHeight: 21,
          headFontSize: 18,
          // content: '1,653,555',
          content: numberSplitByThousandth(Number(this.getDataById('01'))),
          isBlock: false,
          unit: '户',
          contentHeight: 48,
          contentFontSize: 36,
          contentMargin: '8px 0 0 0',
          unitMargin: '0 0 4px 0',
        },
      ],
      [
        {
          headText: '较年初增量',
          headHeight: 21,
          headFontSize: 18,
          content: numberSplitByThousandth(this.toUnitValue(this.getDataById('09'))),
          isBlock: false,
          contentHeight: 28,
          contentFontSize: 24,
          contentMargin: '4px 4px 0 0',
          unitMargin: '0 0 2px 0',
          unit: '亿元',
        },
        {
          headText: '较年初增速',
          headHeight: 21,
          headFontSize: 18,
          content: Number(this.getDataById('10')).toFixed(2) + '%',
          isBlock: false,
          contentHeight: 28,
          contentFontSize: 24,
          contentMargin: '4px 4px 0 0',
          unitMargin: '0 0 2px 0',
          unit: '',
          color: '#48d1ff',
        },
      ],
    ]
  }

  public get definiteCountList(): CommonSelectData<string[]>[] {
    return [
      {
        label: 'company',
        value: [
          '对公',
          numberSplitByThousandth(this.toUnitValue(this.getDataById('05'))),
          numberSplitByThousandth(Number(this.getDataById('02'))),
        ],
      },
      {
        label: 'personal',
        value: [
          '个人',
          numberSplitByThousandth(this.toUnitValue(this.getDataById('06'))),
          numberSplitByThousandth(Number(this.getDataById('03'))),
        ],
      },
    ]
  }

  public get averageRemainder(): NumberUnitItem[] {
    return [
      {
        headText: '日均余额',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('15'))),
        isBlock: false,
        contentHeight: 48,
        contentFontSize: 40,
        contentMargin: '2px 4px 0 0',
        unitMargin: '0 0 4px 0',
      },
      {
        headText: '较年初增量',
        headHeight: 21,
        headFontSize: 18,
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('20'))),
        isBlock: false,
        contentHeight: 28,
        contentFontSize: 24,
        contentMargin: '16px 4px 4px 0',
        unitMargin: '0 0 6px 0',
      },
      {
        headText: '较年初增速',
        headHeight: 21,
        headFontSize: 18,
        content: Number(this.getDataById('21')).toFixed(2) + '%',
        isBlock: false,
        contentHeight: 28,
        contentFontSize: 24,
        contentMargin: '16px 4px 4px 0',
        unitMargin: '0 0 6px 0',
        unit: '',
        color: '#48d1ff',
      },
    ]
  }

  public get definiteRemainder(): NumberUnitItem[][] {
    return [
      [
        {
          headText: '各项贷款余额',
          headHeight: 21,
          headFontSize: 18,
          content: numberSplitByThousandth(this.toUnitValue(this.getDataById('30'))),
          isBlock: false,
          contentHeight: 48,
          contentFontSize: 36,
          contentMargin: '8px 4px 0 0',
          unitMargin: '0 0 4px 0',
        },
        {
          headText: '户数',
          headHeight: 21,
          headFontSize: 18,
          content: numberSplitByThousandth(Number(this.getDataById('26'))),
          isBlock: false,
          unit: '户',
          contentHeight: 48,
          contentFontSize: 36,
          contentMargin: '8px 4px 0 0',
          unitMargin: '0 0 4px 0',
        },
      ],
      [
        {
          headText: '较年初增量',
          headHeight: 21,
          headFontSize: 18,
          content: numberSplitByThousandth(this.toUnitValue(this.getDataById('45'))),
          isBlock: false,
          contentHeight: 28,
          contentFontSize: 24,
          contentMargin: '4px 4px 0 0',
          unitMargin: '0 0 2px 0',
          unit: '亿元',
        },
        {
          headText: '较年初增速',
          headHeight: 21,
          headFontSize: 18,
          content: Number(Number(this.getDataById('49'))).toFixed(2) + '%',
          isBlock: false,
          contentHeight: 28,
          contentFontSize: 24,
          contentMargin: '4px 4px 0 0',
          unitMargin: '0 0 2px 0',
          unit: '',
          color: '#48d1ff',
        },
      ],
    ]
  }

  public get averageDefiniteRemainder(): CommonSelectData<string[]>[] {
    return [
      {
        label: 'company',
        value: [
          '对公条线',
          numberSplitByThousandth(this.toUnitValue(this.getDataById('31'))),
          numberSplitByThousandth(Number(this.getDataById('27'))),
        ],
      },
      {
        label: 'personal',
        value: [
          '个人条线',
          numberSplitByThousandth(this.toUnitValue(this.getDataById('32'))),
          numberSplitByThousandth(Number(this.getDataById('28'))),
        ],
      },
      {
        label: 'small_loan',
        value: [
          '普惠金融条线',
          numberSplitByThousandth(this.toUnitValue(this.getDataById('35'))),
          numberSplitByThousandth(Number(this.getDataById('29'))),
        ],
      },
    ]
  }

  public get chartDataIdMap() {
    return (
      this.charDataList[0]?.data.reduce((map: Record<string, string[]>, item) => {
        map[item[0]] = item
        const time = item.pop()
        this.$set(this.item, 'subTitle', `${time ?? ''}`)
        // const dateList = item.pop()?.split('-')
        // const year = dateList?.[0]
        // const month = dateList?.[1]
        // const day = dateList?.[2]
        // if (!isNull(year) && !isNull(month)&& !isNull(day)) this.$set(this.item, 'subTitle', `${year}年${month}月${day}日`)
        return map
      }, {}) ?? {}
    )
  }

  public getDataById(id: number | string) {
    return this.chartDataIdMap[`ID000${id}`]?.[1] ?? '0'
  }
}
