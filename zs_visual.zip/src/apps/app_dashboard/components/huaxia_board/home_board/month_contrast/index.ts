/** @format */

import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { isNull } from '@/apps_modules/functor'
import { Component, Mixins } from 'vue-property-decorator'
@Component({
  name: 'HomeBoardMonthContrast',
  components: {},
})
export default class HomeBoardMonthContrastController extends Mixins(ChartRequestMixins) {
  public get chartData() {
    return (
      this.charDataList[0]?.data?.map(item => {
        const dateList = item.pop()?.split('-')
        const month = dateList?.[1]
        const year = dateList?.[0]
        if (!isNull(year) && !isNull(month)) this.$set(this.item, 'date', `${year}年${month}月`)
        // const date = item.pop()?.split('-')?.[1]
        // if (!isNull(date)) this.$set(this.item, 'date', `${date}月`)
        return [item[0], ...item.slice(1).map(item => Number(item))]
      }) ?? []
    )
  }
  public get mockData() {
    return [['名称', '存款余额', '贷款余额', '对公贷款', '个人贷款'], ...this.chartData]
  }
}
