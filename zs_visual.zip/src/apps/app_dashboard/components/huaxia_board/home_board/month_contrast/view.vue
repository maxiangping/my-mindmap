<!-- @format -->
<template>
  <div class="month-contrast full flex x-space-between y-axis-center">
    <div
      class="list-item full-h flex -column x-space-between y-axis-center"
      v-for="item in mockData"
      :class="{ 'huaxia-column': item[0].includes('华夏') }"
      :key="item[0]"
    >
      <div class="list-row flex full-w xy-axis-center" v-for="(row, index) in item" :key="index">
        {{ row }}
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
