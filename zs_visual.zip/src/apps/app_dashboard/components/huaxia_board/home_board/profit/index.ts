/** @format */

import { NumberUnitItem, ValueTrendItem } from '@/store/model/dashboard/home'
import { Component, Mixins } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import { getValueTrendClass, numberSplitByThousandth } from '@/apps/app_dashboard/common/util'
import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { isNull } from '@/apps_modules/functor'
@Component({
  name: 'HomeBoardProfit',
  components: {
    NumberUnit,
  },
})
export default class HomeBoardProfitController extends Mixins(ChartRequestMixins) {
  public getValueTrendClass = getValueTrendClass

  public get mockValue(): string[] {
    const date = this.chartData[9]
    const year = new Date().getFullYear()
    if (!isNull(date)) this.$set(this.item, 'subTitle', `${year}年 第${date}季度`)
    return [1, 4, 7].map(item => Number(this.chartData[item]).toFixed(2))
  }

  public get finishPercent(): ValueTrendItem<string>[] {
    return [
      {
        label: '完成率',
        value: Number(this.chartData[2] ?? 0) + '%',
        trend: true,
      },
      {
        label: '完成率',
        value: Number(this.chartData[5] ?? 0) + '%',
        trend: true,
      },
      {
        label: '',
        value: Number(this.chartData[8]?? 0) + '%' ,
        trend: false,
      },
    ]
  }

  public get chartData() {
    return this.charDataList[0]?.data?.[0] ?? []
  }

  public get mockData(): NumberUnitItem[] {
    return [
      {
        headText: '拨备前利润',
        unit: '亿元',
        headFontSize: 20,
        contentFontSize: 56,
        contentMargin: '10px 0 0 0',
        color: '#48D1FF',
        headHeight: 26,
        contentHeight: 66,
        unitFontiSize: 20,
        content: numberSplitByThousandth(Number(this.chartData[0] ?? 0)),
        unitMargin: '0 0 14px 0',
        isBlock: false,
      },
      {
        headText: '中间业务净收入',
        unit: '亿元',
        headFontSize: 20,
        contentFontSize: 56,
        contentMargin: '10px 0 0 0',
        color: '#48D1FF',
        headHeight: 26,
        contentHeight: 66,
        unitFontiSize: 20,
        content: numberSplitByThousandth(Number(this.chartData[3] ?? 0)),
        unitMargin: '0 0 14px 0',
        isBlock: false,
      },
      {
        headText: '运营费用成本收入比',
        unit: '%',
        headFontSize: 20,
        contentFontSize: 56,
        contentMargin: '10px 0 0 0',
        color: '#48D1FF',
        headHeight: 26,
        contentHeight: 66,
        unitFontiSize: 20,
        content: numberSplitByThousandth(Number(this.chartData[6] ?? 0)),
        unitMargin: '0 0 14px 0',
        isBlock: false,
      },
    ]
  }

  public getHeight(value: string) {
    if (value === '完成') return '100%'
    if (value === '未完成') return '0%'
    return value
  }
}
