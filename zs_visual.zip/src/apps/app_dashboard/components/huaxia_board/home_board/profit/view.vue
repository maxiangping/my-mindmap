<!-- @format -->
<template>
  <div class="home-profit flex -column full x-space-around">
    <div class="profit-item flex full-w" v-for="(item, index) in mockData" :key="index">
      <div class="left flex-auto">
        <number-unit
          :headText="item.headText"
          :unit="item.unit"
          :headFontSize="item.headFontSize"
          :contentFontSize="item.contentFontSize"
          :contentMargin="item.contentMargin"
          :color="item.color"
          :headHeight="item.headHeight"
          :contentHeight="item.contentHeight"
          :unitFontiSize="item.unitFontiSize"
          :content="item.content"
          :unitMargin="item.unitMargin"
          :isBlock="item.isBlock"
        ></number-unit>
        <div class="flex y-axis-center percent">
          <span>季度同比</span>
          <span class="ml-8 quarter-contrast"
            >{{ mockValue[index] }}%</span
          >
        </div>
      </div>
      <div class="right flex xy-axis-center">
        <div class="circle flex xy-axis-center pr flex -column xy-axis-center">
          <img class="full pa" v-asset:src="`icon/huaxia/circle.svg`" alt="" />
          <div class="circle-bg pa" :style="{ height: getHeight(finishPercent[index].value) }"></div>
          <!-- <img
            class="pa full-w"
            v-asset:src="`icon/huaxia/value_line.svg`"
            :style="{ bottom: finishPercent[index].value }"
            alt=""
          /> -->
          <div class="pr finish-label">{{ finishPercent[index].label }}</div>
          <div class="pr finish-value">{{ finishPercent[index].value }}</div>
        </div>
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
