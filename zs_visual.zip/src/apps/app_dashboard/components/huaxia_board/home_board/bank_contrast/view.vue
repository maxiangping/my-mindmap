<!-- @format -->
<template>
  <div class="bank-contrast x-space-evenly y-axis-center full flex -column pr">
    <div class="chart-part full-h dark full-w">
      <chart :chart-option="chartOption" :data-source="chartDataSource" :key="chartId"></chart>
    </div>
    <div class="list-part full-w flex -column">
      <div class="list-item flex y-axis-center">
        <div class="list-cell flex xy-axis-center" v-for="cell in firstColumn" :key="cell">{{ cell }}</div>
      </div>
      <div
        class="list-item flex y-axis-center"
        v-for="(row,rowIndex) in currentPageData"
        :key="row[0]"
        :class="{ 'shenzhen-row': row[0].includes('深圳'),'color-percent2': rowIndex === 4 }"
      >
        <div class="list-cell flex xy-axis-center" v-for="(cell, index) in row" :key="index">
          <div v-if="index <= 1">{{ cell }}</div>
          <div v-else class="flex -column xy-axis-center">
            <span>{{ cell }}{{index === 3 ? '万' : ''}}</span>
            <span class="value-row"
              >占比&nbsp;<span class="color-percent" >{{ getPercent(cell, row[1], 0) }}</span></span
            >
          </div>
        </div>
      </div>
    </div>
    <div class="pager flex y-axis-center x-space-between">
      <img
        v-asset:src="`icon/huaxia/pager_pre.svg`"
        class="pager-btn"
        @click="changeIndex(-1)"
        alt="上一页"
        title="上一页"
      />
      <img
        v-asset:src="`icon/huaxia/pager_next.svg`"
        @click="changeIndex(1)"
        class="pager-btn"
        alt="下一页"
        title="下一页"
      />
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
