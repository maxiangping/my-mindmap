/** @format */
export const chartConfig: IFCDSChart = {
  caption: '手机银行交易额',
  paletteColors: '#434DEF,#F6C022',
  maxColWidth: '24',
  divLineAlpha: 1,
  showLegend: '1',
  showToolTip: '1',
  legendPosition: 'top-center',
  showPercentValues: '0',
  showValues: '0',
  theme: 'dashboard',
  formatNumberScale: 0,
}
