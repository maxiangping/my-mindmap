/** @format */

import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { getPercent } from '@/apps/app_dashboard/common/util'
import { isNull } from '@/apps_modules/functor'

import { confCreator, STACKED_CHARTS } from '@/apps_modules/fusionchart/types'
import { getUuid } from '@/apps_modules/toolbox/math'

import { Component, Mixins } from 'vue-property-decorator'
import { chartConfig } from './config'
@Component({
  name: 'DepositBoardMonthContrast',
  components: {
    chart: async () => {
      return import(/* webpackChunkName: 'fusionchart_comp' */ '@/apps/components/chart.fc')
    },
  },
})
export default class DepositBoardMonthContrastController extends Mixins(ChartRequestMixins) {
  public chartOption = confCreator(STACKED_CHARTS.STACKED_COLUMN_2D)

  public get mockData(): string[][] {
    return (
      this.charDataList[0]?.data?.map(item => {
        // const dateList = item.pop()?.split('-')
        // const month = dateList?.[1]
        // const year = dateList?.[0]
        // if (!isNull(year) && !isNull(month)) this.$set(this.item, 'date', `${year}年${month}月`)
        const day = item.pop()
        if (!isNull(day) ) this.$set(this.item, 'date', `${day}`)
        return [item[0], ...item.slice(1).map(item => `${Number(item)}`)]
      }) ?? []
    )
  }

  public index = 0
  public get currentPageData() {
    const list = this.mockData.filter(item => !item[0].includes('深圳'))
    const SZItem = this.mockData.filter(item => item[0].includes('深圳'))
    const currentList = list.slice(this.index * this.pageSize, (this.index + 1) * this.pageSize)
    return [...SZItem, ...currentList]
  }

  public firstColumn: string[] = ['月份', '交易金额', '交易占比', '交易客户数']

  private get categories() {
    return this.currentPageData.map(item => {
      return {
        label: item[0],
      }
    })
  }

  public pageSize = 5

  public get totalPage() {
    return Math.ceil(this.mockData.length / this.pageSize)
  }

  public chartId = getUuid()

  public get dataset() {
    this.chartId = getUuid()
    return ['个人交易额'].map((item, index) => {
      return {
        seriesname: item,
        data: this.currentPageData.map((item,childIndex) => {
          return {
            value: item[index + 2] ?? '0',
            displayValue: item[index + 2] ?? '0',
            color: childIndex === this.currentPageData.length-1 ? '#ff382c' : '',
          }
        }),
      }
    })
  }

  public get chartDataSource(): IFCDataSource {
    return {
      chart: chartConfig,
      data: [],
      categories: [{ category: this.categories }],
      dataset: this.dataset,
    }
  }

  public timer = -1

  public initTimer() {
    if (this.timer > 0) {
      window.clearInterval(this.timer)
    }
    this.timer = window.setInterval(() => {
      this.index = (this.index + 1) % this.totalPage
    }, 8e3)
    this.$once('hook:beforeDestroy', () => {
      window.clearInterval(this.timer)
    })
  }

  public mounted() {
    this.initTimer()
  }

  public changeIndex(v: number) {
    this.index = (this.index + v + this.totalPage) % this.totalPage
    this.initTimer()
  }

  public getPercent = getPercent
}
