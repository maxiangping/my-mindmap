/** @format */

export { default as DepositBoardRemainder } from './deposit_board/remainder/view.vue'
export { default as DepositBoardAverageRemainder } from './deposit_board/average_remainder/view.vue'
export { default as DepositBoardIncreaseCount } from './deposit_board/increase_count/view.vue'
export { default as DepositBoardAverageIncreaseCount } from './deposit_board/average_increase/view.vue'
export { default as DepositBoardIncreaseCountChart } from './deposit_board/increase_count_chart/view.vue'
export { default as DepositBoardAverageIncreaseChart } from './deposit_board/average_increase_chart/view.vue'
