/** @format */

export { default as HomeBoardProfit } from './home_board/profit/view.vue'
export { default as HomeBoardMonthContrast } from './home_board/month_contrast/view.vue'
export { default as HomeBoardBankContrast } from './home_board/bank_contrast/view.vue'
export { default as HomeBoardManageScale } from './home_board/manage_scale/view.vue'
