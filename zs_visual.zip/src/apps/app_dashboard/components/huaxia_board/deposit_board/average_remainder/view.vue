<!-- @format -->
<template>
  <div class="average-remainder full flex -column">
    <div class="remainder-amount full-w flex x-space-between">
      <div class="flex y-axis-center">
        <number-unit
          :headText="amountData.headText"
          :contentFontSize="amountData.contentFontSize"
          :contentMargin="amountData.contentMargin"
          :headHeight="amountData.headHeight"
          :contentHeight="amountData.contentHeight"
          :content="amountData.content"
          :unit="amountData.unit"
          :unitMargin="amountData.unitMargin"
          :isBlock="amountData.isBlock"
        ></number-unit>
      </div>
      <div class="flex amount-img">
        <!-- <img v-asset:src="`icon/huaxia/loan_amount.svg`" alt="" /> -->
      </div>
    </div>
    <div class="remainder-definite full-w flex -column">
      <div class="definite-item flex">
         <span class="definite-item-title">地区</span>
         <span class="definite-item-title">交易额</span>
       </div>
      <div class="definite-item flex" v-for="(item) in amountDefinite" :key="item.icon">
        <!-- <div class="part-img part">
          <img v-asset:src="`icon/huaxia/${item.icon}.svg`" class="full-w" alt="" />
        </div> -->
        <number-unit
          class="part middle"
          :headText="item.headText"
          :contentFontSize="item.contentFontSize"
          :contentMargin="item.contentMargin"
          :headHeight="item.headHeight"
          :contentHeight="item.contentHeight"
          :headFontSize="item.headFontSize"
          :content="item.content"
          :unitMargin="item.unitMargin"
          :unit="item.unit"
          :color="item.color"
        ></number-unit>
        <!-- <number-unit
          class="part"
          :headText="definitePercent[index].headText"
          :contentFontSize="definitePercent[index].contentFontSize"
          :contentMargin="definitePercent[index].contentMargin"
          :headHeight="definitePercent[index].headHeight"
          :contentHeight="definitePercent[index].contentHeight"
          :unitFontiSize="definitePercent[index].unitFontiSize"
          :content="definitePercent[index].content"
          :unitMargin="definitePercent[index].unitMargin"
          :unit="definitePercent[index].unit"
          :color="definitePercent[index].color"
        ></number-unit> -->
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
