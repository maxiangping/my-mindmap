/** @format */

import { NumberUnitItem, NumberUnitWithIcon } from '@/store/model/dashboard/home'
import { Component, Mixins } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import { getValueTrendClass, numberSplitByThousandth } from '@/apps/app_dashboard/common/util'
import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
@Component({
  name: 'DepositBoardAverageRemainder',
  components: {
    NumberUnit,
  },
})
export default class DepositBoardAverageRemainderController extends Mixins(ChartRequestMixins) {
  public getValueTrendClass = getValueTrendClass
  public get chartDataIdMap() {
    return (
      this.charDataList[0]?.data.reduce((map: Record<string, string[]>, item) => {
        map[item[0]] = item
        this.$set(this.item, 'subTitle', `${this.lastMonth ?? ''}`)
        return map
      }, {}) ?? {}
    )
  }

  public getDataById(id: number | string) {
    return this.chartDataIdMap[`ID000${id}`]?.[2] ?? '0'
  }

  public get amountDefinite(): NumberUnitWithIcon[] {
    return [
      {
        headText: '华南',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('16'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'company',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
        unit: '亿元',
      },
      {
        headText: '华中',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('17'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
        unit: '亿元',
      },
      {
        headText: '华北',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('18'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal2',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
        unit: '亿元',
      },
    ]
  }

  // public get definitePercent(): NumberUnitItem[] {
  //   return [
  //     {
  //       headText: '占比',
  //       color: '#48D1FF',
  //       content: numberSplitByThousandth(Number(this.getDataById('18')).toFixed(2)),
  //       contentHeight: 28,
  //       contentFontSize: 24,
  //       contentMargin: '6px 0 0 0',
  //       unit: '%',
  //       headHeight: 24,
  //       headFontSize: 18,
  //     },
  //     {
  //       headText: '占比',
  //       color: '#48D1FF',
  //       content: numberSplitByThousandth(Number(this.getDataById('19')).toFixed(2)),
  //       contentHeight: 28,
  //       contentFontSize: 24,
  //       contentMargin: '6px 0 0 0',
  //       unit: '%',
  //       headHeight: 24,
  //       headFontSize: 18,
  //     },
  //   ]
  // }

  public get amountData(): NumberUnitItem {
    return {
      headText: '',
      content: numberSplitByThousandth(this.toUnitValue(this.getDataById('15'))),
      headHeight: 21,
      contentHeight: 62,
      contentFontSize: 56,
      contentMargin: '0 4px 0 0 ',
      isBlock: false,
      unitMargin: '0 0 4px 0',
      unit: '亿元',
    }
  }
}
