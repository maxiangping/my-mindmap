/** @format */

import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { confCreator, SCROLL_CHARTS } from '@/apps_modules/fusionchart/types'
import { getUuid } from '@/apps_modules/toolbox/math'
import { Component, Mixins } from 'vue-property-decorator'
import { chartConfig } from './config'
@Component({
  name: 'DepositBoardIncreaseCountChart',
  components: {
    chart: async () => {
      return import(/* webpackChunkName: 'fusionchart_comp' */ '@/apps/components/chart.fc')
    },
  },
})
export default class DepositBoardIncreaseCountChartController extends Mixins(ChartRequestMixins) {
  public chartId = getUuid()

  public chartOption = confCreator(SCROLL_CHARTS.SCROLL_COLUMN_2D)
  // public chartOption = confCreator(COMBINATION_CHARTS.STACKED_COLUMN2D_AND_LINE_SINGLE_Y_AXIS)

  // private get currentChartData() {
  //   return this.charDataList[0]?.data ?? []
  // }

  private get currentChartData() {
    return this.charDataList[0]?.data?.map(item => {
      return [item[0], ...item.slice(1).map(item => `${Number(item)}`)]
    }) ?? []
  }

  public get chartDataSource(): IFCDataSource {
    chartConfig.yAxisMaxValue = this.chartValRange(this.dataset, 1e2).max
    return {
      chart: chartConfig,
      data: [],
      categories: [{ category: this.categories.length > 0 ? this.categories : [{ label: '' }] }],
      dataset: this.dataset,
    }
  }

  private get categories() {
    return this.currentChartData.map(item => {
      const labels = item[0]?.split('-') ?? [0,0,0]
      return {
        label: `${labels[2]}月`,
      }
    })
  }

  public get dataset() {
    this.chartId = getUuid()
    return ['交易额', '上年同期交易额'].map((item, index) => {
      return {
        seriesname: item,
        // renderAs: index === 0 ? 'line' : 'stackedcolumn',
        data: this.currentChartData.map((item,rowIndex) => {
          return {
            value: item[index + 1] ?? '0',
            displayValue: item[index + 1] ?? '0',
            color: index === 0 ? rowIndex === this.currentChartData.length -1 ? '#ff382c' : '#3434F8' : '#48d1ff'
          }
        }),
      }
    })
  }
}
