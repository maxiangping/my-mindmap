<!-- @format -->
<template>
  <div class="increase-count-chart full light">
    <chart :chart-option="chartOption" :data-source="chartDataSource" :key="chartId"></chart>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
