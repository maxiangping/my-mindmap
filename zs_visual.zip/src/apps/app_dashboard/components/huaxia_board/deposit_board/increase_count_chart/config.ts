/** @format */
export const chartConfig: IFCDSChart = {
  caption: '',
  paletteColors: '#3434F8,#48d1ff,#6FDFB1',
  divLineAlpha: 100,
  showLegend: '1',
  showToolTip: '1',
  legendPosition: 'top-center',
  showValues: '0',
  theme: 'dashboard',
  legendBgColor: '#3434F8,#48d1ff,#6FDFB1',
  anchorBgColor: '', // 锚点-空心（不给背景色即可）
  drawAnchors: '0', // 出现锚点
  anchorRadius: '2', // 锚点-半径
  numberSuffix: '',
  // labelStep: '30',
  setAdaptiveYMin: 1,
  formatNumberScale: 0,
}
