/** @format */

import { NumberUnitWithIcon } from '@/store/model/dashboard/home'
import { Component, Mixins } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import { getValueTrendClass, numberSplitByThousandth } from '@/apps/app_dashboard/common/util'
import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'

@Component({
  name: 'DepositBoardAverageIncreaseCount',
  components: {
    NumberUnit,
  },
})
export default class DepositBoardAverageIncreaseCountController extends Mixins(ChartRequestMixins) {

  public getValueTrendClass = getValueTrendClass

  public get chartDataIdMap() {
    return (
      this.charDataList[0]?.data.reduce((map: Record<string, string[]>, item) => {

        map[item[0]] = item
        this.$set(this.item, 'subTitle', `${this.lastMonth ?? ''}`)
        return map
      }, {}) ?? {}
    )
  }

  public getDataById(id: number | string) {
    return this.chartDataIdMap[`ID000${id}`]?.[2] ?? '0'
  }

  // public get totalIncrease(): NumberUnitItem[] {
  //   return [
  //     {
  //       headText: '总增量',
  //       content: numberSplitByThousandth(this.toUnitValue(this.getDataById('20'))),
  //       contentHeight: 48,
  //       contentFontSize: 40,
  //       headHeight: 21,
  //       contentMargin: '2px 4px 0 0 ',
  //       unitMargin: '0 0 4px 0',
  //       isBlock: false,
  //       unit: '万户',
  //     },
  //     {
  //       headText: '总增速',
  //       content: numberSplitByThousandth(Number(this.getDataById('21')).toFixed(2)),
  //       contentHeight: 38,
  //       contentFontSize: 32,
  //       contentMargin: '2px 4px 0 0 ',
  //       unitMargin: '0 0 4px 0',
  //       unit: '%',
  //       headHeight: 21,
  //       color: getTextColor(this.getDataById('21')),
  //       isBlock: false,
  //     },
  //   ]
  // }

  // public get definiteCount(): IncreaseCountItem[] {
  //   return [
  //     {
  //       headText: '对公增量',
  //       content: numberSplitByThousandth(this.toUnitValue(this.getDataById('22'))),
  //       contentHeight: 38,
  //       contentFontSize: 30,
  //       headHeight: 21,
  //       contentMargin: '9px 4px 0 0 ',
  //       unitMargin: '0 0 4px 0',
  //       percentLabel: '对公增速',
  //       percent: numberSplitByThousandth(Number(this.getDataById('23')).toFixed(2)) + '%',
  //       color: getTextColor(this.getDataById('23')),
  //       isBlock: false,
  //     },
  //     {
  //       headText: '个人增量',
  //       content: numberSplitByThousandth(this.toUnitValue(this.getDataById('24'))),
  //       contentHeight: 38,
  //       contentFontSize: 30,
  //       headHeight: 21,
  //       contentMargin: '9px 4px 0 0 ',
  //       unitMargin: '0 0 4px 0',
  //       percentLabel: '个人增速',
  //       percent: numberSplitByThousandth(Number(this.getDataById('25')).toFixed(2)) + '%',
  //       color: getTextColor(this.getDataById('25')),
  //       isBlock: false,
  //     },
  //   ]
  // }

  public get definiteCount(): NumberUnitWithIcon[] {
    return [
      {
        headText: '华南',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('20'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'company',
        headHeight: 38,
        headFontSize: 18,
        color: 'rgb(255, 56, 44)',
        unit: '万户',
      },
      {
        headText: '华中',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('22'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal',
        headHeight: 38,
        headFontSize: 18,
        color: 'rgb(255, 56, 44)',
        unit: '万户',
      },
      {
        headText: '华北',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('24'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal2',
        headHeight: 38,
        headFontSize: 18,
        color: 'rgb(255, 56, 44)',
        unit: '万户',
      },
    ]
  }
}
