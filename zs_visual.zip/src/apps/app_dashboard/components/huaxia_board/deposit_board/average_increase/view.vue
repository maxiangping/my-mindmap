<!-- @format -->
<template>
  <div class="average-increase full flex -column">
    <!-- <div class="top flex full-w">
      <number-unit
        class="top-number"
        v-for="item in totalIncrease"
        :key="item.headText"
        :headText="item.headText"
        :contentFontSize="item.contentFontSize"
        :contentMargin="item.contentMargin"
        :headHeight="item.headHeight"
        :contentHeight="item.contentHeight"
        :content="item.content"
        :unitMargin="item.unitMargin"
        :unit="item.unit"
        :color="item.color"
        :isBlock="item.isBlock"
      ></number-unit>
    </div>
    <div class="bottom full-w flex -column">
      <div class="increase-item flex x-space-between y-axis-center" v-for="item in definiteCount" :key="item.headText">
        <div class="number-part">
          <number-unit
            :headText="item.headText"
            :contentFontSize="item.contentFontSize"
            :contentMargin="item.contentMargin"
            :headHeight="item.headHeight"
            :contentHeight="item.contentHeight"
            :content="item.content"
            :unitMargin="item.unitMargin"
            :isBlock="item.isBlock"
          ></number-unit>
        </div>
         <div class="percent-part">
          <number-unit
            :headText="item.percentLabel"
            :contentFontSize="20"
            :contentMargin="'12px 0 0 0'"
            :headHeight="21"
            :contentHeight="24"
            :content="item.percent"
            :unitMargin="'0 0 0 0'"
            :unit="''"
            :color="item.color"
            :isBlock="item.isBlock"
          ></number-unit>
        </div>
      </div>
    </div>-->
      <div class="remainder-definite full-w flex -column">
      <div class="definite-item flex">
         <span class="definite-item-title">地区</span>
         <span class="definite-item-title">客户数</span>
       </div>
      <div class="definite-item flex" v-for="(item) in definiteCount" :key="item.headText">
        <number-unit
          class="part middle"
          :headText="item.headText"
          :contentFontSize="item.contentFontSize"
          :contentMargin="item.contentMargin"
          :headHeight="item.headHeight"
          :contentHeight="item.contentHeight"
          :headFontSize="item.headFontSize"
          :content="item.content"
          :unitMargin="item.unitMargin"
          :unit="item.unit"
          :color="item.color"
        ></number-unit>

      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
