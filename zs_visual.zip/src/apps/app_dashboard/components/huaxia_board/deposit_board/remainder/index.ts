/** @format */

import { NumberUnitItem, NumberUnitWithIcon } from '@/store/model/dashboard/home'
import { Component, Mixins, Watch } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import { getValueTrendClass, numberSplitByThousandth } from '@/apps/app_dashboard/common/util'
import ChartRequestMixins from '@/apps/app_dashboard/common/chartRequest.mixins'
import { namespace } from 'vuex-class'

const NSDashboard = namespace('Dashboard')
@Component({
  name: 'DepositBoardRemainder',
  components: {
    NumberUnit,
  },
})
export default class DepositBoardRemainderController extends Mixins(ChartRequestMixins) {
  @NSDashboard.Action('setTime')
  public setTime!: (time: string) => void

  public getValueTrendClass = getValueTrendClass

  public get chartDataIdMap() {
    return (
      this.charDataList[0]?.data.reduce((map: Record<string, string[]>, item) => {
        map[item[0]] = item
        this.$set(this.item, 'subTitle', `${this.curMonth ?? ''}`)
        return map
      }, {}) ?? {}
    )
  }

  public getDataById(id: number | string) {
    return this.chartDataIdMap[`ID000${id}`]?.[2] ?? '0'
  }

  public get amountDefinite(): NumberUnitWithIcon[] {
    return [
      {
        headText: '华南',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('05'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'company',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
      },
      {
        headText: '华中',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('06'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
      },
      {
        headText: '华北',
        content: numberSplitByThousandth(this.toUnitValue(this.getDataById('07'))),
        contentHeight: 38,
        contentFontSize: 28,
        contentMargin: '0 0 0 30px',
        unitMargin: '0 0 0 20px',
        icon: 'personal2',
        headHeight: 38,
        headFontSize: 18,
        color: '#48D1FF',
      },
    ]
  }

  // public get definitePercent(): NumberUnitItem[] {
  //   return [
  //     {
  //       headText: '占比',
  //       color: '#48D1FF',
  //       content: numberSplitByThousandth(Number(this.getDataById('07')).toFixed(2)),
  //       contentHeight: 28,
  //       contentFontSize: 24,
  //       contentMargin: '6px 0 0 0',
  //       unit: '%',
  //       headHeight: 24,
  //       headFontSize: 18,
  //     },
  //     {
  //       headText: '占比',
  //       color: '#48D1FF',
  //       content: numberSplitByThousandth(Number(this.getDataById('08')).toFixed(2)),
  //       contentHeight: 28,
  //       contentFontSize: 24,
  //       contentMargin: '6px 0 0 0',
  //       unit: '%',
  //       headHeight: 24,
  //       headFontSize: 18,
  //     },
  //   ]
  // }

  public get amountData(): NumberUnitItem {
    return {
      headText: '',
      content: numberSplitByThousandth(this.toUnitValue(this.getDataById('04'))),
      headHeight: 21,
      contentHeight: 62,
      contentFontSize: 56,
      contentMargin: '0 4px 0 0 ',
      isBlock: false,
      unitMargin: '0 0 4px 0',
    }
  }

  @Watch('amountData')
  public getTime() {
    const time = this.chartDataIdMap['ID00004']?.[3] ?? '0'
    this.setTime(time)
  }
}
