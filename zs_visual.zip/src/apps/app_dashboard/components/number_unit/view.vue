<!-- @format -->
<template>
  <div class="number-unit flex -column">
    <span
      class="head-text flex y-axis-center"
      v-show="headText"
      :style="{ 'font-size': `${headFontSize}px`, height: `${headHeight}px` }"
      >{{ headText }}</span
    >
    <div class="comment" v-show="comment">{{ comment }}</div>
    <div class="flex number-content" :class="{ 'x-space-between': isBlock }" :style="{ height: `${contentHeight}px` }">
      <span
        class="content-text"
        :style="{
          height: `${contentFontSize}px`,
          'font-size': `${contentFontSize}px`,
          'line-height': `${contentFontSize}px`,
          color: color,
          margin: contentMargin,
        }"
      >
        {{ content }}
      </span>
      <span
        class="content-unit"
        :style="{
          height: `${unitFontSize}px`,
          'font-size': `${unitFontSize}px`,
          'line-height': `${unitFontSize}px`,
          margin: unitMargin,
        }"
      >
        {{ unit }}
      </span>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
