/** @format */

import { Component, Prop, Vue } from 'vue-property-decorator'
@Component({
  name: 'NumberUnit',
  components: {},
})
export default class NumberUnitController extends Vue {
  @Prop({ type: String, default: '亿元' })
  public unit!: string
  @Prop({ type: Number, default: 21 })
  public headHeight!: number

  @Prop({ type: Number, default: 16 })
  public headFontSize!: number
  @Prop({ type: String, default: '' })
  public headText!: string
  @Prop({ type: Number, default: 24 })
  public contentFontSize!: number
  @Prop({ type: Number, default: 16 })
  public unitFontSize!: number
  @Prop({ type: Number, default: 38 })
  public contentHeight!: number
  @Prop({ type: String, default: '' })
  public contentMargin!: string
  @Prop({ type: String, default: '#FFFFFF' })
  public color!: string
  @Prop({ type: String, default: '' })
  public content!: string
  @Prop({ type: String, default: '' })
  public unitMargin!: string
  @Prop({ type: Boolean, default: true })
  public isBlock!: boolean
  @Prop({ type: String, default: '' })
  public comment!: string
}
