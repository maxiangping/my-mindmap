/** @format */

export { default } from './module_layout/view.vue'
