/** @format */

import { Launcher, visibilitychange } from '@/apps/common/launcher'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import './assets/common_class.less'
import { dashboardModule } from '@/store/modules/dashboardRegister'

window.addEventListener(
  'DOMContentLoaded',
  async () => {
    const launcher = new Launcher({
      explorer: PROJECT.DASHBOARD,
      autoLoad: true,
      beforeLaunch: async () => {},
      baseConfigure: true,
      registerModule: [dashboardModule],
    })

    await launcher.launch()
    const resize = launcher.resized()
    window.addEventListener('resize', resize, false)
    window.addEventListener('orientationchange', resize, false)
    document.addEventListener('visibilitychange', visibilitychange, false)
  },
  false
)
