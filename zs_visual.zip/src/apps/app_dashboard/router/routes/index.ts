/** @format */

export { default as routes } from './dashboard'
