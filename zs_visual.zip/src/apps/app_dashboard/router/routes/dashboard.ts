/** @format */

import { Route } from 'vue-router'

export default [
  {
    path: '/home/:id',
    name: 'Home',
    component: async () =>
      import(
        /* webpackChunkName: "huaxia_home" */
        '@/apps/app_dashboard/views/homePage'
      ),
    meta: { requiresAuth: true },
    props: (route: Route) => {
      const id = Number.parseInt(route.params.id)
      if (Number.isNaN(id)) return { id: 0 }
      return { id }
    },
  },
]
