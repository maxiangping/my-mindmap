<!-- @format -->
<template>
  <div class="home flex -column full">
    <div class="page-head flex xy-axis-center pr">
      <div class="pa flex xy-axis-center logo">经营指标大屏</div>
      <div class="page-title">{{ boardName }}</div>
      <div class="pa time" v-if="id !== 0">业务日期：{{ timeText }}</div>
    </div>
    <div class="page-content">
      <component :is="boardType"></component>
    </div>
    <div class="page-bottom flex xy-axis-center">
      <div class="board-item pr" v-for="board in boardTypeList" :key="board.com">
        <img class="bottom-bg pa full" v-asset:src="`icon/huaxia/board_bg.svg`" alt="" />
        <div
          @click="chooseBoard(board.id)"
          class="board-name pa flex xy-axis-center"
          :class="{ 'cur-board': board.com === boardType }"
        >
          {{ board.name }}
        </div>
        <img
          :class="{ 'cur-btn-bg': board.com === boardType }"
          class="bottom-bg cur-bg pa"
          v-asset:src="`icon/huaxia/cur_btn.svg`"
          alt=""
        />
      </div>
    </div>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
