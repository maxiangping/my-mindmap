/** @format */

import { BoardInfoItem } from '@/store/model/dashboard/home'
import { Component, Prop, Vue } from 'vue-property-decorator'
import { HomeBoard, DepositBoard } from '../board'
import { namespace } from 'vuex-class'

const NSDashboard = namespace('Dashboard')
@Component({
  name: 'Home',
  components: {
    HomeBoard,
    DepositBoard,
  },
})
export default class HomeController extends Vue {
  public boardTypeList: BoardInfoItem[] = [
    {
      com: 'HomeBoard',
      name: '综合看板2',
      id: 0,
    },
    {
      name: '定位问题',
      com: 'DepositBoard',
      id: 1,
    },
  ]

  @Prop({ type: Number })
  public id!: number

  @NSDashboard.Getter('time')
  public timeText!: string

  public get boardType() {
    return this.boardTypeList[this.id]?.com ?? 'HomeBoard'
  }
  public get boardName() {
    return this.boardTypeList[this.id]?.name ?? '综合看板'
  }

  public chooseBoard(id: number) {
    if (id === this.id) return
    this.$router.replace({ name: 'Home', params: { id: `${id}` } })
  }
}
