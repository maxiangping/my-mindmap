/** @format */

export { default as HomeBoard } from './home_board/view.vue'
export { default as DepositBoard } from './deposit_board/view.vue'
