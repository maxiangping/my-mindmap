<!-- @format -->
<template>
  <div class="deposit-board flex full">
    <module-layout :data="pageConfig" layoutType="row"></module-layout>
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
