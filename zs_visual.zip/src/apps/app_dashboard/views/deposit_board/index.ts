/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { pageConfig } from './config'
import ModuleLayout from '@/apps/app_dashboard/components/moduleLayout'
@Component({
  name: 'DepositBoard',
  components: {
    ModuleLayout,
  },
})
export default class DepositBoardController extends Vue {
  public pageConfig = pageConfig
}
