/** @format */

import { BoardOutItem } from '@/store/model/dashboard/home'

export const pageConfig: BoardOutItem[] = [
  {
    chartList: [
      {
        title: '交易额',
        subTitle: '',
        datasetId: 10005,
        chartId: [10005],
        contentName: 'DepositBoardRemainder',
        size: '455',
      },
      {
        title: '交易额占比',
        subTitle: '7月',
        datasetId: 10005,
        chartId: [10007],
        contentName: 'PieChart',
        size: '555',
        categoryLabels: ['华南','华中','华北'],
        categoryIds: ['09','11','13'],
        categoryColors: '#434DEF,#FFC107,#48d1ff',
      },
      {
        title: '交易额历史分析',
        subTitle: '2021年 单位:万元',
        datasetId: 10010,
        chartId: [10021],
        contentName: 'DepositBoardIncreaseCountChart',
        size: '829',
      },
    ],
    size: '1',
  },
  {
    size: '1',
    chartList: [
      {
        title: '交易额',
        subTitle: '',
        datasetId: 10005,
        chartId: [10006],
        contentName: 'DepositBoardAverageRemainder',
        size: '455',
      },
      {
        title: '交易额占比',
        subTitle: '6月',
        datasetId: 10005,
        chartId: [10008],
        contentName: 'PieChart',
        size: '555',
        categoryLabels: ['华南','华中','华北'],
        categoryIds: ['20','22','24'],
        categoryColors: '#434DEF,#FFC107,#48d1ff',
      },
      {
        title: '交易客户数历史分析',
        subTitle: '2021年 单位:万户',
        datasetId: 10011,
        chartId: [10022],
        contentName: 'DepositBoardAverageIncreaseChart',
        size: '829',
      },
    ],
  },
]
