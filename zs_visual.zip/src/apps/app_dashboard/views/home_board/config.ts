/** @format */

import { BoardOutItem } from '@/store/model/dashboard/home'

export const pageConfig: BoardOutItem[] = [
  {
    chartList: [
      {
        title: '经营效益',
        subTitle: '季度数据',
        datasetId: 10001,
        chartId: [10003],
        contentName: 'HomeBoardProfit',
        size: '1',
      },
    ],
    size: '388',
  },
  {
    size: '953',
    chartList: [
      {
        title: '经营规模',
        datasetId: 10004,
        chartId: [10004],
        contentName: 'HomeBoardManageScale',
        size: '540',
      },
      {
        title: '同业月度对比',
        datasetId: 10003,
        chartId: [10002],
        contentName: 'HomeBoardMonthContrast',
        size: '258',
        subTitle: '单位:亿元',
      },
    ],
    style: 'margin-left:70px',
  },
  {
    size: '388',
    chartList: [
      {
        title: '个人手机银行交易额',
        datasetId: 10002,
        chartId: [10001],
        contentName: 'HomeBoardBankContrast',
        size: '1',
        subTitle: '单位:亿元',
      },
    ],
    style: 'margin-left:70px',
  },
]
