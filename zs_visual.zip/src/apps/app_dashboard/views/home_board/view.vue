<!-- @format -->
<template>
  <div class="home-board flex full pr">
    <module-layout :data="pageConfig" layoutType="column"></module-layout>
    <img class="pa left-part page-bg" v-asset:src="'icon/huaxia/page_bg.svg'" alt="" />
    <img class="pa right-part page-bg" v-asset:src="'icon/huaxia/page_bg.svg'" alt="" />
  </div>
</template>
<script lang="ts">
export { default } from './index'
</script>
<style src="./style.less" lang="less" scoped></style>
