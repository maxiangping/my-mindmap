/** @format */

export { default } from './home/view.vue'
