/** @format */

import { Component, Prop, Vue } from 'vue-property-decorator'
import NumberUnit from '@/apps/app_dashboard/components/numberUnit'
import { BoardChartItem, ChartOriginData } from '@/store/model/dashboard/home'
import { getChartById } from '@/store/api/modules/dashboard/home'
import { namespace } from 'vuex-class'
import { isEmpty } from '@/apps_modules/functor'

const NSDashboard = namespace('Dashboard')
@Component({
  name: 'DepositBoardAverageRemainder',
  components: {
    NumberUnit,
  },
})
export default class ChartRequestMixins extends Vue {
  @NSDashboard.Getter('time')
  public timeText!: string
  @Prop({ type: Object })
  public item!: BoardChartItem

 public get curMonth() {
   const times = this.timeText?.split('-') ?? []
   if(times.length === 3) {
     return `${times[1]?.replace(/^0/u,'') ?? ''}月`
   }
   return  ''
 }

 public get  lastMonth (){
  return isEmpty(this.curMonth) ? '' : `${parseInt(this.curMonth) - 1}月`
 }
  private get chartIds() {
    return this.item.chartId
  }

  public charDataList: ChartOriginData[] = []

  public async initData() {
    const res = await Promise.all(
      this.chartIds.map(item => {
        return getChartById({
          widgetId: `${item}`,
          datasetId: `${this.item.datasetId}`,
        })
      })
    )
    this.charDataList = res.map(item => item?.data) as ChartOriginData[]
  }

  public numberUnit = Math.pow(10, 8)

  public toUnitValue(v: string | number, unit = this.numberUnit) {
    return (Number(v) / unit).toFixed(2)
  }

  public chartValRange(dataset: IFCDSDataset, num = 1e1) {
    const chartValueList = dataset.flatMap(item => item.data.flatMap(data => Number(data.value)))
    return {
      max: Math.ceil(Math.max(...chartValueList) / num + 1) * num ?? 0,
      min: Math.floor(Math.min(...chartValueList) / num - 1) * num ?? 0,
    }
  }

  public created() {
    this.initData()
  }
}
