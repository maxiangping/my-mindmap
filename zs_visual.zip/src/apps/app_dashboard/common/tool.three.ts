/** @format */
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'
import * as THREE from 'three'

const getRandomAngle = (basic = Math.PI): number => {
  const r = Math.random() > 0.5
  const angle = basic + (Math.PI * Math.random()) / 2
  return r ? angle + Math.PI : angle
}

const loadGLModel = (url: string) => {
  const loader = new GLTFLoader()
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return loadSource<any>(loader, url)
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const loadSource = <T>(loader: any, name: string): Promise<T> => {
  return new Promise(res => {
    loader.load(`${process.env.VUE_APP_PUBLIC_PATH}model/${name}`, (v: T) => {
      res(v)
    })
  })
}

const loadText = (name: string): Promise<THREE.Font> => {
  const loader = new THREE.FontLoader()
  return loadSource<THREE.Font>(loader, name)
}

const changePivot = (x: number, y: number, z: number, wrapper: THREE.Object3D, obj: THREE.Object3D) => {
  wrapper.position.set(x, y, z)
  wrapper.add(obj)
  obj.position.x -= x
  obj.position.y -= y
  obj.position.z -= z
}

const doModelAnimate = (
  renderer: THREE.WebGLRenderer,
  scene: THREE.Scene,
  camera: THREE.Camera,
  handle: () => void
) => {
  window.requestAnimationFrame(doModelAnimate.bind(this, renderer, scene, camera, handle))
  handle()
  renderer.render(scene, camera)
}

const createSprite = (path: string) => {
  const texture = new THREE.TextureLoader().load(`${process.env.VUE_APP_PUBLIC_PATH}model/${path}`)
  const spriteMaterial = new THREE.SpriteMaterial({
    // color: 0x4EF9FF,//设置精灵矩形区域颜色
    // alphaMap:texture,
    map: texture,
    // rotation: Math.PI / 4,//旋转精灵对象45度，弧度值
  })
  return new THREE.Sprite(spriteMaterial)
}

export { getRandomAngle, loadGLModel, loadText, changePivot, doModelAnimate, createSprite }
