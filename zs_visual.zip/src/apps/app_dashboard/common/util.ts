/** @format */

import { deepCopy } from '@/apps_modules/functor'
import { SpecialValueMap } from '@/store/model/common'

/** @format */

// 去掉空数据
function filterValueNoEmpty(data: string[]) {
  return data.filter(item => item.split('&')[2]?.split('=')[1] !== '0')
}

function getDataURLBySrc(src: string, callBack: (dataUrl: string) => void) {
  const canvas = document.createElement('canvas') as HTMLCanvasElement
  const img = new Image()
  img.src = src
  img.onload = function () {
    const imgWidth = img.width
    const imgHeight = img.height
    canvas.width = imgWidth * 2
    canvas.height = imgHeight * 2
    const ctx = canvas?.getContext('2d')
    ctx?.clearRect(0, 0, canvas.width, canvas.height)
    ctx?.drawImage(img, 0, 0, imgWidth, imgHeight, 0, 0, canvas.width, canvas.height)
    const dataURL = canvas.toDataURL('image/png')
    callBack(dataURL)
  }
}

function dataURLtoFile(dataurl: string, filename: string) {
  //将base64转换为文件
  const arr = dataurl.split(',')
  const mimes = arr[0]?.match(/:(.*?);/)
  const mime = mimes && mimes?.length > 1 ? mimes[1] : ''
  const bstr = atob(arr[1])
  let n = bstr.length
  const u8arr = new Uint8Array(n)
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n)
  }
  return new File([u8arr], filename, { type: mime })
}

function compareByNumber(array: string[][], key: number) {
  const newArray = deepCopy(array)
  newArray.sort((curr: string[], next: string[]) => {
    return Number(next[key]) - Number(curr[key])
  })
  return newArray
}

function compareByString(array: string[][], key: number) {
  const newArray = deepCopy(array)
  newArray.sort((curr: string[], next: string[]) => {
    return next[key] < curr[key] ? 1 : -1
  })
  return newArray
}

function groupByKey(array: string[][], key: number) {
  const listTree: string[][][] = array
    .filter((el, index, arr) => index === arr.findIndex(_el => _el[key] === el[key]))
    // 组装
    .map((item: string[]) => {
      const childrens = array.filter((arr: string[]) => arr[key] === item[key])
      return childrens
    })
  return listTree
}

// 对象item和一个对象数组的合并跟求和
function sumOfObjectItem(dataSet: string[][], dataItem: string[]) {
  const dataSetTemp: string[][] = deepCopy(dataSet)
  if (dataSetTemp.filter(item => item[0] === dataItem[0]).length > 0) {
    dataSetTemp.forEach(item => {
      if (item[0] === dataItem[0]) {
        item[2] = '' + (Number(item[2]) + Number(dataItem[2]))
      }
    })
  } else {
    dataSetTemp.push(dataItem)
  }
  return dataSetTemp
}

// 两个对象数组的合并跟求和
function sumOfObjectArray(dataSet: string[][], data: string[][]) {
  let dataSetTemp: string[][] = deepCopy(dataSet)
  data.map(dataItem => {
    dataSetTemp = sumOfObjectItem(dataSetTemp, dataItem)
  })
  return dataSetTemp
}

function styleObjectToString(style: SpecialValueMap<number | string>): string {
  return Object.entries(style).reduce((res: string, item: [string, number | string]) => {
    res += `${item[0]}:${item[1]};`
    return res
  }, '')
}
const getValueTrendClass = (v: number | string) => {
  return Number(v) >= 0 ? 'value-up' : 'value-down'
}
const getTextColor = (v: number | string) => {
  return Number(v) > 0 ? '#FF382C' : ' #62DAAB'
}
//数字转千分位
const numberSplitByThousandth = (v: number | string): string => {
  const pre = Number(v) >= 0 ? '' : '-'
  const vList = `${Math.abs(Number(v))}`.split('.')
  return `${pre}${vList[0]?.replace(/(\d{1,3})(?=(\d{3})+(?:$|\.))/gu, '$1,')}${vList[1] ? `.${vList[1]}` : ''}`
}

export const getPercent = (v: number, sum: number, fixNum = 2) => {
  return `${((v * 100) / sum).toFixed(fixNum)}%`
}
export {
  filterValueNoEmpty,
  getDataURLBySrc,
  dataURLtoFile,
  groupByKey,
  compareByNumber,
  compareByString,
  sumOfObjectArray,
  sumOfObjectItem,
  styleObjectToString,
  getValueTrendClass,
  getTextColor,
  numberSplitByThousandth,
}
