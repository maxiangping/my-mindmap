/** @format */

export { default as ChartsLayout } from './charts/view.vue'
export { default as CockpitLayout } from './cockpit/view.vue'
export { default as EvenlyLayout } from './evenly/view.vue'
export { default as LargeScreenLayout } from './large_screen/view.vue'
export { default as SimulationLayout } from './simulation/view.vue'

export { axis } from './evenly/conf'
