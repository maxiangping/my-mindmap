/** @format */

import { isEmpty } from '@/apps_modules/functor'
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSClient = namespace('Client')

@Component({
  name: 'SimulationLayout',
})
export default class SimulationLayout extends Vue {
  public showHeader = true

  @NSClient.Getter
  public sizeOfScreen!: number

  @Prop([String]) public caption!: string
  @Prop([String]) public subcaption!: string
  @Prop({ type: String, default: '' }) public autoCaption!: string

  public async mounted() {
    if (!isEmpty(this.autoCaption)) {
      this.resizeHandle()
    }
  }

  @Watch('sizeOfScreen')
  private resizeHandle() {
    this.showHeader = document.body.offsetHeight > 996
  }
}
