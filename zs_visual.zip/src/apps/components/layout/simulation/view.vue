<!-- @format -->

<template>
  <section class="container">
    <header v-show="showHeader" class="flex y-axis-center header">
      <div class="vw100">
        <h1 class="txc" v-text="caption" />
        <div class="sub txr" v-text="subcaption"></div>
      </div>
    </header>
    <section class="flex y-axis-center simlation-wrap">
      <slot />
    </section>
  </section>
</template>
<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" scoped />
