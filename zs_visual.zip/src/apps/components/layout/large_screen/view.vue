<!-- @format -->

<template>
  <section class="flex -column container">
    <header class="flex y-axis-center header">
      <div class="flex y-baseline">
        <h1 class="caption" v-text="caption"></h1>
        <i class="subcaption" v-text="subcaption"></i>
      </div>
      <section class="flex -mid">
        <slot name="header"></slot>
      </section>
    </header>
    <section class="flex xy-axis-center charts-wrap" :class="containerType">
      <slot></slot>
      <div v-if="algin" class="fc-card empty" />
      <div v-if="algin" class="fc-card empty" />
    </section>
  </section>
</template>
<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" scoped></style>
