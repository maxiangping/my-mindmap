/** @format */

import { Component, Prop, Vue } from 'vue-property-decorator'

@Component({
  name: 'LargeScreenLayout',
})
export default class LargeScreenLayout extends Vue {
  @Prop({ type: String, default: '' }) public containerType!: string
  @Prop({ type: String, default: '' }) public caption!: string
  @Prop({ type: String, default: '' }) public subcaption!: string
  @Prop({ type: Boolean, default: true }) public algin!: boolean
}
