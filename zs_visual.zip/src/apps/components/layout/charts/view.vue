<!-- @format -->

<template>
  <section class="container">
    <header v-show="showHeader" class="header">
      <h1 class="txc" v-text="dynCaption"></h1>
      <!-- <div class="sub txr" v-text="subcaption"></div> -->
    </header>
    <article>
      <slot :name="dyntab"></slot>

      <section class="flex y-axis-center charts-wrap" :class="containerType">
        <slot></slot>
        <div v-if="algin" class="fc-card empty"></div>
        <div v-if="algin" class="fc-card empty"></div>
      </section>
      <slot name="footer"></slot>
    </article>
    <div class="directory_tab" :class="{ show_tab: statue }" @click="toggleTab">目录</div>

    <div class="close_tab" :class="{ show_tab: statue }">
      <div v-tap @click.stop="toggleTab">
        <div class="close_title">
          <div class="touch_title">
            <span>轻触这里</span>
            <span>关闭目录</span>
          </div>
        </div>
        <div class="close_icon">
          <icon :name="iconName" :size="`43,60`" />
        </div>
      </div>
      <section class="menu-wrap">
        <!-- <tree :menus="menus"/> -->
        <dyn-header :class="{ header_capt: statue }"></dyn-header>
        <tabbarmobile :tab-index="tabIndex" :tabs="tabs" @slideTo="slideTo"></tabbarmobile>
      </section>
    </div>
  </section>
</template>
<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" scoped></style>
