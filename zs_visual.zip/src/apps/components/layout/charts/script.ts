/** @format */

import { isEmpty, isNull } from '@/apps_modules/functor'
import { Icon } from '@/apps_modules/toolbox/assets'
import { MEDIA_SCREEN } from '@/apps_modules/toolbox/runtime'
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

import { DynHeader } from '@/apps/components/explorer/dyn'
import { Tree } from '@/apps/components/explorer/tree'
import icon from '@/components/Icon.vue'
import tabbar from '@/components/TabBar.vue'
import tabbarmobile from '@/components/TabMobile.vue'

const NSClient = namespace('Client')
const NSNavigator = namespace('Navigator')

const enum DeviceType {
  touch = '',
  normal = 'header',
}

@Component({
  components: {
    DynHeader,
    Tree,
    icon,
    tabbar,
    tabbarmobile,
  },
  name: 'ChartsLayout',
})
export default class ChartsLayout extends Vue {
  public tabIndex = 0
  public showHeader = true
  public dyntab: DeviceType = DeviceType.normal

  public statue = false
  public iconName = Icon.md_ic_close_tap

  @NSClient.Getter
  public sizeOfScreen!: number

  @NSNavigator.Getter('subcaption')
  public globalSubcaption!: string

  @NSNavigator.Getter
  public tabs!: string[]

  @NSNavigator.Action('expand')
  public expandNavigator!: (expend?: boolean) => void

  @Prop({ type: String, default: '' }) public containerType!: string
  @Prop({ type: String, default: '' }) public caption!: string
  @Prop({ type: String, default: '' }) public subcaption!: string
  @Prop({ type: String, default: '' }) public autoCaption!: string
  @Prop({ type: Boolean, default: true }) public algin!: boolean

  public get dynCaption() {
    return this.dyntab === DeviceType.touch ? this.globalSubcaption : this.caption
  }

  public async mounted() {
    this.resizeHandle(document.body.offsetWidth)
    // 开发测试
    // setTimeout(this.expandNavigator,3e3)
  }

  public get tab() {
    return this.tabs[this.tabIndex]
  }

  public toggleTab() {
    this.statue = !this.statue
  }

  public async slideTo(tabIndex: number) {
    this.statue = false
    this.tabIndex = tabIndex
    this.$emit('slideTo', tabIndex)
  }

  @Watch('sizeOfScreen')
  private resizeHandle(size?: number, pv?: number) {
    if (size === pv) return
    const horSize = isNull(size) ? document.body.offsetWidth : size
    this.updateDyntab(horSize)
    if (!isEmpty(this.autoCaption)) {
      this.showHeader = horSize > MEDIA_SCREEN.MINI_SCREEN
    }
  }

  private updateDyntab(horSize: number) {
    if (horSize < MEDIA_SCREEN.PAD_SCREEN) {
      if (this.dyntab !== DeviceType.touch) {
        this.dyntab = DeviceType.touch
      }
    } else {
      if (this.dyntab !== DeviceType.normal) {
        this.dyntab = DeviceType.normal
      }
    }
  }
}
