<!-- @format -->

<template>
  <section class="flex" :class="`${axis === 'x' ? '' : '-column'} ${axis}-axis-evenly`">
    <slot></slot>
  </section>
</template>
<script lang="ts">
export { default } from './index'
</script>
