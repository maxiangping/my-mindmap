/** @format */

export enum axis {
  X = 'x',
  Y = 'y',
  XY = 'xy',
}
