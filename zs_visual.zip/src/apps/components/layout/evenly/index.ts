/** @format */

import { axis } from '@/apps/components/layout/evenly/conf'
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component({ name: 'EvenlyLayout' })
export default class EvenlyLayout extends Vue {
  @Prop({ type: String, default: axis.X })
  public axis!: string
}
