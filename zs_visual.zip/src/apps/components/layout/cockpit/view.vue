<!-- @format -->

<template>
  <section class="container flex box_wrap">
    <h1 class="page_title">综合视图</h1>
    <evenly :axis="axis.X" class="col-3 l_col">
      <slot name="sideOfLeft"></slot>
    </evenly>
    <evenly :axis="axis.X" class="col-4">
      <slot></slot>
    </evenly>
    <evenly :axis="axis.X" class="col-3 r_col">
      <slot name="sideOfRight"></slot>
    </evenly>
  </section>
</template>
<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" scoped></style>
