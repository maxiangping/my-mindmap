/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { axis } from '../evenly/conf'
import evenly from '../evenly/view.vue'

@Component({
  components: { evenly },
  name: 'CockpitLayout',
})
export default class CockpitLayout extends Vue {
  public axis = axis
}
