/** @format */

import { MixinsFunctor } from '@/apps/mixins/functor'
import { freezeFactory } from '@/apps_modules/functor'
import FCComponent from '@/apps_modules/fusionchart'
import icon from '@/components/Icon.vue'
import { ChartObject, EventObject, FusionCharts } from 'fusioncharts'
import { mixins } from 'vue-class-component'
import { Component, Prop, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSClient = namespace('Client')

Vue.use(FCComponent)

@Component({
  components: { icon },
  name: 'FusionCharts',
})
export default class VueFusionCharts extends mixins(MixinsFunctor) {
  public dynComponent = 'fusioncharts'

  @Prop({ type: String, default: '' })
  public rootClass!: string

  @Prop({ type: String, default: '' })
  public title!: string

  @Prop({ type: Object, default: () => freezeFactory({}) })
  public chartOption!: ChartObject

  @Prop({ type: Object, default: () => freezeFactory({}) })
  public dataSource!: string | JSONType

  @Prop({ type: String, default: '' })
  public refId!: string

  @Prop({ type: String, default: '' })
  public taskName!: string

  @Prop({ type: Boolean, default: false })
  public resizable!: boolean

  @Prop({ type: Number, default: 0 })
  public iterIndex!: number

  @Prop({ type: String, default: '' })
  public boardName!: string

  public baseUrl: string | undefined = process.env.BASE_URL

  public charts?: FusionCharts

  public onceRenderComplete = false

  public get el(): Element {
    return this.$el
  }

  @NSClient.Getter
  public registeredFusionCharts!: number

  public renderIndex = -1

  @NSClient.Action('registerFusionChart')
  public registerFusionChart!: (counter: number) => void

  public entityClick(arg: IFCMapClickEvent) {
    this.$emit('entity-click', arg)
  }

  public async realTimeUpdateComplete(e: { data: { updateObject: ObjectConstructor } }) {
    this.$emit('real-time-update-complete', e.data.updateObject)
  }

  public async renderComplete(e: EventObject) {
    this.charts = e.sender
    if (!this.onceRenderComplete) {
      this.$emit('once-render-complete', this.charts, this.refId, this.taskName)
      this.onceRenderComplete = true
    }
    this.$emit('render-complete', this.charts, this.refId, this.taskName)
  }

  public async mounted() {
    this.registerFusionChart(1)
    this.renderIndex = this.registeredFusionCharts
    if (this.isRealtime) {
      document.addEventListener('visibilitychange', this.handleVisibilityChange, false)
    }
  }

  public beforeDestroy() {
    this.registerFusionChart(-1)
    if (this.isRealtime) {
      document.removeEventListener('visibilitychange', this.handleVisibilityChange)
    }
    this.charts?.dispose()
  }

  public slicingStart(e: SliceEvent) {
    this.$emit('slicing-start', e)
  }

  private get isRealtime() {
    const chartType = this.chartOption.type
    return chartType?.startsWith('realtime') ?? false
  }

  private handleVisibilityChange() {
    if (document.hidden) {
      this.charts?.stopUpdate()
      return
    }
    this.charts?.restartUpdate()
  }
}
