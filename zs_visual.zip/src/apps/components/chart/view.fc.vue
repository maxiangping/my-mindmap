<!-- @format -->

<template>
  <section class="fc-card" :class="rootClass">
    <header v-if="!isEmpty(title)" class="flex y-axis-center fc-title">
      <div v-if="!isEmpty(boardName)" class="flex -mid-first">
        <img
          style="margin-right: 4px"
          width="16"
          height="16"
          :src="`${baseUrl}${boardName === 'personal' ? 'tb-personal' : 'tb-group'}.svg`"
          alt
        />
      </div>
      <div class="-mid title" v-text="title"></div>
    </header>
    <component
      :is="dynComponent"
      v-once
      class="fc-chart-wrap"
      :class="chartOption.type"
      :type="chartOption.type"
      :width="chartOption.width"
      :height="chartOption.height"
      :data-format="chartOption.dataFormat"
      :data-source="dataSource"
      @entityClick="entityClick"
      @realTimeUpdateComplete="realTimeUpdateComplete"
      @renderComplete="renderComplete"
      @slicingStart="slicingStart"
    />
    <!-- @chartClick="chartClick" -->
  </section>
</template>
<script lang="ts">
export { default } from './chart.fc'
</script>
