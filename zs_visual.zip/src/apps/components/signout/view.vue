<!-- @format -->

<template>
  <section></section>
</template>

<script src="./index.ts" lang="ts"></script>
