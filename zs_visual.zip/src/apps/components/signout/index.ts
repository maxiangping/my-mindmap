/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { GlobalVariable } from '@/apps/common/constant'

const NSAuth = namespace('Auth')
@Component({
  name: 'SignOut',
})
export default class SignOut extends Vue {
  @NSAuth.Action('cleanup')
  public signout!: () => Promise<void>

  public async created() {
    await this.signout()
    await this.$router.replace(GlobalVariable.AUTH_FAILED_URL)
  }
}
