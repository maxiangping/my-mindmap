<!-- @format -->

<template>
  <section v-tap class="flex route-tab noselect -tap" @click.stop="tabIndent($event)">
    <div v-for="(tab, i) in tabs" :key="`route-tab-${i}`" class="route-tab-wrap" :class="{ active: i == routeIndex }">
      <Tab :data-index="i" :tab="tab" />
    </div>
  </section>
</template>
<script src="./index.ts" lang="ts"></script>
<style src="./style.less" lang="less" scoped></style>
