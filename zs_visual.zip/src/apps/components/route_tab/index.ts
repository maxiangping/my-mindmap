/** @format */

import { isEmpty, isNull } from '@/apps_modules/functor'
import { addTask } from '@/apps_modules/task-manager'
import Tab from '@/components/Tab.vue'
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { Location } from 'vue-router'

const NSClient = namespace('Client')

@Component({
  components: { Tab },
  name: 'RouteTab', // bad name, "ArrowTab" is better?
})
export default class RouteTab extends Vue {
  public counter = 0

  @Prop({ type: Number })
  public routeIndex!: number

  @Prop({ type: Array, default: () => [] })
  public tabs!: string[]

  @Prop({ type: String })
  public taskName!: string

  @NSClient.State(status => status.isAutoPlay)
  public isAutoPlay!: string

  private get routeQuery() {
    return this.$route.query
  }

  private get tabSize(): number {
    return this.tabs.length
  }

  @Watch('routeIndex')
  public onIndex(v: number, pv: number) {
    if (v === pv) return
    this.counter += 1
  }

  public async tabIndent(e: MouseEvent) {
    const srcEl = e.srcElement as HTMLElement
    if (!isNull(srcEl)) {
      const className = srcEl.className
      if (!/tab-wrap/.test(className)) {
        const _index = this.tabs.indexOf(srcEl.innerText)
        this.counter += 1
        this.routeTo(_index)
      }
    }
  }

  public async mounted() {
    this.autoPlayTask()
  }

  public beforeDestroy() {
    this.counter = 0
  }

  private async routeTo(index: number) {
    await this.$router.replace({
      name: this.$route.name as string,
      params: { index: `${index}` },
      query: this.routeQuery,
    } as Location)
  }

  private async autoPlayTask() {
    if (isEmpty(this.isAutoPlay)) return
    let next_index = this.routeIndex

    await addTask(this.taskName, () => {
      if (this.counter > 0) {
        this.counter -= 1
        return
      }
      if (next_index >= this.tabSize - 1) {
        next_index = 0
      } else {
        next_index += 1
      }
      this.routeTo(next_index)
    })
  }
}
