<!-- @format -->

<template>
  <dyn-element
    :is="tagName"
    :target="isBlankLink ? '_blank' : '_self'"
    replace
    :to="clearUrl"
    :href="clearUrl"
    class="flex y-axis-center leaf -tap"
    :class="{ cur: matchUrl }"
    v-text="name"
  ></dyn-element>
</template>
<script lang="ts">
export { default } from './script.link'
</script>
