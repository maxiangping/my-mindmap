<!-- @format -->

<template>
  <header class="flex y-axis-center title">
    <img class="ic-logo" :src="logourl" alt />
    <div class="txc capt" v-text="caption"></div>
  </header>
</template>
<script lang="ts">
export { default } from './script.header'
</script>
<style src="./style.header.less" lang="less" scoped />
