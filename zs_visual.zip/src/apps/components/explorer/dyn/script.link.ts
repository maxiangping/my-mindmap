/** @format */

import DynElement from '@/components/dynElement'
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component({
  components: {
    DynElement,
  },
  name: 'DynLink',
})
export default class DynLink extends Vue {
  @Prop({ type: String, default: '' })
  public routePath!: string

  @Prop({ type: String, default: '' })
  public url!: string

  @Prop({ type: String, default: '' })
  public name!: string

  public get clearUrl() {
    return this.url.replace(/(\?|&)target=_blank/, '')
  }

  public get matchUrl() {
    return this.routePath === this.url || this.$route.path.startsWith(this.url)
  }

  public get isBlankLink() {
    return /^http(s)?:\/\/|(\?|&)target=_blank/.test(this.url)
  }

  public get tagName() {
    return this.isBlankLink ? 'a' : 'router-link'
  }
}
