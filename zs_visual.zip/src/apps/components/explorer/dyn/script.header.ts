/** @format */

import { PROJECT } from '@/apps_modules/toolbox/runtime'
import { Component, Inject, Prop, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSNavigator = namespace('Navigator')

@Component({ name: 'DynHeader' })
export default class DynHeader extends Vue {
  @Prop({ type: String, default: '' })
  public title!: string

  @NSNavigator.Getter
  public caption!: string

  @Inject() private process!: IProcess

  public get logourl() {
    // analysis 与 dashboard共用同一个logo
    const appname = this.process.name
    const logoName = appname === PROJECT.ANALYSIS ? PROJECT.DASHBOARD : appname
    return `${this.process.publicPath}navlogo/${logoName}.svg`
  }
}
