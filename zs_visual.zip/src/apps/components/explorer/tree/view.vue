<!-- @format -->

<template>
  <section>
    <div v-for="menu in menus" :key="menu.menuId" class="prefix_menu">
      <dyn-link v-if="menu.menuType === 'C'" :url="menu.url" :name="menu.menuName" :route-path="routePath" />
      <wrap
        v-else-if="menu.menuType === 'M' && hasReleasedChildren(menu)"
        :menu="menu"
        :current-wrap-name="currentWrapName"
        :route-path="routePath"
        class="tree_wrap third_menu"
        @tapedWrap="tapedWrap"
      >
        <template v-slot:default>
          <Tree
            class="sub-wrap"
            :current-wrap-name="currentWrapName"
            :route-path="routePath"
            :menus="menuFilter(menu)"
          />
        </template>
      </wrap>
    </div>
  </section>
</template>
<script lang="ts">
export { default } from './script'
</script>
<style src="./style.less" lang="less" />
