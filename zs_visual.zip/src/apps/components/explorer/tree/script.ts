/** @format */

import iconbutton from '@/components/IconButton.vue'
import { IApiMenuEntity } from '@/store/model/base/explorer'
import { Component, Inject, Prop, Vue } from 'vue-property-decorator'
import { DynLink } from './../dyn'
import { Wrap } from './../wrap'

@Component({
  components: {
    DynLink,
    iconbutton,
    Wrap,
  },
  name: 'Tree',
})
export default class Tree extends Vue {
  @Prop([Array])
  public menus!: IApiMenuEntity

  @Prop({ type: String, default: '' })
  public routePath!: string

  @Prop({ type: String, default: '' })
  public currentWrapName!: string

  public baseUrl = process.env.BASE_URL

  @Inject() private process!: IProcess

  public hasChildren(menu: IApiMenuEntity) {
    return Array.isArray(menu.children) && menu.children.length > 0
  }

  public isHttpLink(url: string) {
    return url.startsWith('http://') || url.startsWith('https://')
  }

  public hasReleasedChildren(menu: IApiMenuEntity) {
    const hasChildren = this.hasChildren(menu)

    if (hasChildren && this.process.isProduction) {
      return menu.children.some((item: IApiMenuEntity) => item.visible === '0')
    }
    return hasChildren
  }

  public menuFilter(menu: IApiMenuEntity) {
    return this.process.isProduction
      ? menu.children.filter((item: IApiMenuEntity) => item.visible === '0')
      : menu.children
  }

  public tapedWrap(name: string) {
    this.$emit('tapedWrap', name)
  }
}
