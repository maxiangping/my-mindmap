/** @format */

export { default as Tree } from './view.vue'
