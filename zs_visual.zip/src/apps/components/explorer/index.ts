/** @format */

export { default as Explorer } from './view.vue'
