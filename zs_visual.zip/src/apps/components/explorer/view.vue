<!-- @format -->

<template>
  <!-- <nav class="explorer" :class="visable"> -->
  <nav class="explorer" :class="{ explorer_brg: statue }">
    <section class="flex -column container">
      <div class="-mid-first nav-wrap">
        <dyn-header :class="{ header_capt: statue }" />
      </div>
      <section class="-mid menu-wrap" :class="{ show: statue }">
        <tree :menus="menus" :current-wrap-name="currentWrapName" :route-path="routePath" @tapedWrap="tapedWrap" />
      </section>
    </section>
    <material-icon class="flex xy-axis-center tools txc" inactive theme="md-light" :name="iconName" @tap="toggleMenu" />
  </nav>
</template>
<script lang="ts">
export { default } from './script'
</script>
<style src="./style.less" lang="less" scoped />
