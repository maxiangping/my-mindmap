/** @format */

import { freezeFactory, rawProp } from '@/apps_modules/functor'
import { Icon } from '@/apps_modules/toolbox/assets'
import icon from '@/components/Icon.vue'
import iconbutton from '@/components/IconButton.vue'
import { IApiMenuEntity } from '@/store/model/base/explorer'
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'

@Component({
  components: { icon, iconbutton },
  name: 'Wrap',
})
export default class Wrap extends Vue {
  @Prop({ type: Object, default: freezeFactory({}) })
  public menu!: IApiMenuEntity

  @Prop({ type: String, default: '' })
  public currentWrapName!: string

  @Prop({ type: String, default: '' })
  public routePath!: string

  // @Prop({ type: Boolean, default: false })
  public third_menu!: boolean

  public iconAngle = 0
  public hasMatch = false

  public iconName = Icon.md_ic_arrow_down

  public get menuName() {
    return rawProp<string>(this.menu, 'menuName', '')
  }

  public get children() {
    return this.menu.children
  }

  @Watch('routePath')
  public currentChanged(rp: string) {
    this.hasMatch = this.children.some(item => {
      const __ch = item.children
      let __match = item.url === rp
      if (!__match) {
        if (Array.isArray(__ch) && __ch.length > 0) {
          __match = __ch.some(_item => _item.url === rp)
        }

        if (!__match) __match = rp.startsWith(item.url)
      }

      return __match
    })
    this.boolToAngle(this.hasMatch)
  }

  @Watch('currentWrapName')
  public currentNameChanged(newName: string, oldName: string) {
    if (newName !== oldName) {
      // console.log(newName)
      const eq = newName === this.menuName
      this.hasMatch = eq
      this.boolToAngle(eq)
    }
  }

  public toggleWrap() {
    this.hasMatch = !this.hasMatch
    this.boolToAngle(this.hasMatch)
    this.$emit('tapedWrap', this.menuName)
  }

  public mounted() {
    this.currentChanged(this.routePath)
  }

  private boolToAngle(res: boolean) {
    this.iconAngle = res ? -180 : 0
  }
}
