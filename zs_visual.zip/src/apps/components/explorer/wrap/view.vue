<!-- @format -->

<template>
  <section>
    <iconbutton
      class="limb"
      :class="{ hide: !hasMatch }"
      :icon-name="iconName"
      :icon-angle="iconAngle"
      :text="menu.menuName"
      @tap="toggleWrap"
    >
      <!--<icon slot="prefixIcon" name="ic_menu_open" :size="`16,16`"></icon>-->
    </iconbutton>
    <slot />
  </section>
</template>

<script lang="ts">
export { default } from './script'
</script>
