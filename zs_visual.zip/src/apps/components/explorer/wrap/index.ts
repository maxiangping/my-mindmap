/** @format */

export { default as Wrap } from './view.vue'
