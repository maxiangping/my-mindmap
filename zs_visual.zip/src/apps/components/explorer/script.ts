/** @format */

import { MixinsFunctor } from '@/apps/mixins/functor'
import { isNull } from '@/apps_modules/functor'
import { Icon } from '@/apps_modules/toolbox/assets'
import { MaterialIcon } from '@/components/material_icon'
import icon from '@/components/Icon.vue'
import { IApiMenu, IApiMenuEntity } from '@/store/model/base/explorer'
import { Component, Inject, Mixins, Prop, Watch } from 'vue-property-decorator'
import { DynHeader } from './dyn'
import { Tree } from './tree'

let timer: number | undefined

const clearTimer = () => {
  if (!isNull(timer)) {
    window.clearTimeout(timer)
    timer = undefined
  }
}

@Component({
  components: { Tree, icon, DynHeader, MaterialIcon },
  name: 'Explorer',
})
export default class Explorer extends Mixins(MixinsFunctor) {
  // public get visable() {
  //   return this.transformStyle ? 'unvisable' : ''
  // }

  public get menus() {
    const _menus = this.propData

    if (!this.process.isProduction) return _menus
    return _menus.filter((item: IApiMenuEntity) => {
      return Array.isArray(item.children.filter((child: IApiMenuEntity) => child.visible === '0'))
    })
  }

  public get routePath(): string {
    if (this.statue) {
      this.iconName = 'close'
    } else {
      this.iconName = 'menu'
    }

    return this.$route.path
  }

  @Prop({ type: Array, default: () => Object.freeze([]) })
  public propData!: Readonly<IApiMenu>

  public currentWrapName = ''

  public statue = false

  public iconName = 'menu'
  public logo = Icon.logo_nav

  @Inject() private process!: IProcess

  @Watch('$route')
  public on$routeChange() {
    this.statue = false
  }

  public toggleMenu() {
    clearTimer()
    this.statue = !this.statue
    if (this.statue) {
      this.iconName = 'close'
      timer = window.setTimeout(() => {
        this.statue = false
        this.iconName = 'menu'
      }, 5e5)
    } else {
      this.iconName = 'menu'
    }
  }

  public tapedWrap(name: string) {
    this.currentWrapName = name
  }

  public async mounted() {
    const viewLayer = document.querySelector('.view-layer')
    if (!isNull(viewLayer)) {
      viewLayer.addEventListener('scroll', () => {
        this.statue = false
      })
    }
  }
}
