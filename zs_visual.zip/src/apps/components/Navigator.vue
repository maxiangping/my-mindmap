<!-- @format -->

<template>
  <section>
    <div v-for="(tab, index) in tabs" :key="index" v-text="tab"></div>
  </section>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'

import { namespace } from 'vuex-class'

const NSNavigator = namespace('Navigator')

@Component({ name: 'Navigator' })
export default class Navigator extends Vue {
  @NSNavigator.Getter
  public tabs!: string[]
}
</script>
