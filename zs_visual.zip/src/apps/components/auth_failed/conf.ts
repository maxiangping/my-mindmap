/** @format */

import { getUuid } from '@/apps_modules/toolbox/math'
/**
 * 二维码样式--覆盖默认样式  需用base64加密
 * .impowerBox .title{font-size: 18px;position: relative;bottom: -20px;}
 * .impowerBox .wrp_code {margin-top: 6px;}
 * .impowerBox .qrcode {width: 230px;}
 * .impowerBox .status {margin-top: 0;}
 * .impowerBox .icon38_msg.succ {width: 20px; height: 20px;background-size: 100%;}
 * .impowerBox .status_succ .status_txt h4, .impowerBox .status_fail .status_txt h4 {font-size:14px;line-height:20px;}
 */
const base64Href =
  'data:text/css;base64,LmltcG93ZXJCb3ggLnRpdGxle2ZvbnQtc2l6ZTogMThweDtwb3NpdGlvbjogcmVsYXRpdmU7Ym90dG9tOiAtMjBweDt9Ci5pbXBvd2VyQm94IC53cnBfY29kZSB7bWFyZ2luLXRvcDogNnB4O30KLmltcG93ZXJCb3ggLnFyY29kZSB7d2lkdGg6IDIzMHB4O30KLmltcG93ZXJCb3ggLnN0YXR1cyB7bWFyZ2luLXRvcDogMDt9Ci5pbXBvd2VyQm94IC5pY29uMzhfbXNnLnN1Y2Mge3dpZHRoOiAyMHB4OyBoZWlnaHQ6IDIwcHg7YmFja2dyb3VuZC1zaXplOiAxMDAlO30KLmltcG93ZXJCb3ggLnN0YXR1c19zdWNjIC5zdGF0dXNfdHh0IGg0LCAuaW1wb3dlckJveCAuc3RhdHVzX2ZhaWwgLnN0YXR1c190eHQgaDQge2ZvbnQtc2l6ZToxNHB4O2xpbmUtaGVpZ2h0OjIwcHg7fQ=='

const wwConf =
  process.env.VUE_APP_NODE_ENV === 'development'
    ? {
        // 企业微信ID
        CORP_ID: 'ww8e033a26be886631',
        // 应用ID
        AGENT_ID: '1000112',
        // 请求地址
        HOST: 'http://103.160.52.66:13082',
        STATE: getUuid(),
      }
    : {
        CORP_ID: 'wwcb3d9bd1ed3b0560',
        AGENT_ID: '1000083',
        HOST: '',
        STATE: getUuid(),
      }
// const CORP_ID = process.env.VUE_APP_103.160.52.66:13082NODE_ENV === 'development' ? 'ww8e033a26be886631' : 'wwcb3d9bd1ed3b0560'
// const AGENT_ID = process.env.VUE_APP_NODE_ENV === 'development' ? '1000112' : '1000083'
// const STATE = getUuid()
// const HOST = process.env.VUE_APP_NODE_ENV === 'development' ? '103.160.52.66:13082' : '102.105.254.72:13082'

export { base64Href, wwConf }
