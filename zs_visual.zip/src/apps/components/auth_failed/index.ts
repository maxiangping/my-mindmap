/** @format */

export { default } from './view.vue'
