<!-- @format -->

<template>
  <section class="page-box">
    <section class="auth-container flex xy-axis-center">
      <!-- <div class="page-bg">
        <img :src="pageBg" alt="" />
      </div> -->
      <section class="auth-content flex">
        <div class="logo-wrap content-part">
          <div class="logo"></div>
        </div>
        <div class="content-part flex xy-axis-center">
          <div
            v-show="loginType === 1"
            ref="form"
            action=""
            class="auth-form"
            autocomplete="off"
            @keypress.enter="submit"
          >
            <div class="banner-box">
              <h1>登录</h1>
            </div>
            <div class="input-box">
              <!-- <label for="uname" class="input_field"> -->
              <div class="input-item">
                <div class="user-name-img input-img"></div>
                <input
                  v-model="username"
                  class="input-part user-name"
                  placeholder="账户名"
                  autocapitalize="off"
                  autocorrect="off"
                  :maxlength="20"
                />
              </div>
              <div class="input-item">
                <div class="password-img input-img"></div>
                <input
                  v-model="password"
                  class="input-part password"
                  type="password"
                  placeholder="密码"
                  autocapitalize="off"
                  autocorrect="off"
                />
              </div>
            </div>
            <div class="bn-wrap flex xy-axis-center">
              <button class="button -tap apply" @click="submit">登录</button>
            </div>
            <div class="text-wrap">
              <span class="type-text" @click="changeLoginType(2)">扫码登陆</span>
            </div>
          </div>
          <div v-show="loginType === 2" class="auth-code">
            <div id="wxReg" class="code-wrap"></div>
            <div class="text-wrap account-login">
              <span class="type-text" @click="changeLoginType(1)">账号登陆</span>
            </div>
          </div>
        </div>
      </section>
    </section>
  </section>
</template>

<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" scoped />
