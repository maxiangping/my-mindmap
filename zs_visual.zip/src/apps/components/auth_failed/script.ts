/** @format */

import { MixinsLoading } from '@/apps/mixins/loading'
import { MixinsDialog } from '@/apps/mixins/dialog'
import Field from '@/components/Field.vue'
import Loading from '@/components/Loading.vue'
import { User } from '@/store/model/base/auth'
import { Component, Mixins, Prop, Provide } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { IApiMenu } from '@/store/model/base/explorer'
import { freezeFactory, isNull } from '@/apps_modules/functor'
import { ExplorerControl } from '@/apps/mixins/explorerControl'
import { WwLogin } from './wwLogin'
import { SpecialValueMap } from '@/store/model/common'
import { base64Href, wwConf } from './conf'

const NSAuth = namespace('Auth')
const NSExplorer = namespace('Explorer')
const NSClient = namespace('Client')

@Component({
  components: { field: Field, loading: Loading },
  name: 'AuthFailed',
})
export default class AuthFailed extends Mixins(MixinsLoading, MixinsDialog, ExplorerControl) {
  public username = ''
  public password = ''
  public errorUserNameText = ''
  public errorPasswordText = ''
  // 登录方式 1账号密码 2扫码登录
  public loginType = 1

  private isInRequest = false

  @Prop({ type: Boolean, default: false })
  public isTemp!: boolean

  @Provide() public process = freezeFactory<IProcess>({
    isProduction: process.env.VUE_APP_NODE_ENV === 'production',
    name: process.env.VUE_APP_PROJECT_NAME as string,
    publicPath: process.env.VUE_APP_PUBLIC_PATH as string,
  })

  @NSExplorer.Getter('explorer')
  public explorer!: Readonly<IApiMenu> | undefined

  @NSExplorer.Getter('defUrl')
  public explorerDefUrl!: Readonly<string> | undefined

  @NSAuth.Action
  private auth!: (param?: JSONType) => User

  @NSAuth.Action
  private cleanup!: () => Promise<void>

  @NSExplorer.Action('syncExplorer')
  public syncExplorer!: (params: { projectName: string; sync: boolean }) => Promise<IApiMenu>

  @NSClient.Action('setIsFixTouch')
  public setIsFixTouch!: (isFixTouch: boolean) => void

  private async initExplorer() {
    return this.syncExplorer({
      projectName: this.process.name,
      sync: true,
    })
  }

  private resetForm() {
    this.username = ''
    this.password = ''
  }

  public verifyValue() {
    if (this.username !== '' && this.username.length < 2) {
      this.errorUserNameText = '请输入2~20个字之内的账户名'
      return
    }

    if (this.username === '') {
      this.errorUserNameText = '请输入账户名'
      return
    }

    if (!/^\w+$/g.test(this.username)) {
      this.errorUserNameText = '请输入数字、英文字母、下划线组合的账户名'
      return
    }
    this.errorUserNameText = ''
    if (this.password === '') {
      this.errorPasswordText = '请输入密码'
      return
    }
    if (!/^\S{6,20}$/.test(this.password)) {
      this.errorPasswordText = '请输入6-20个字之内的密码'
      return
    }
    this.errorPasswordText = ''
  }

  public submit() {
    this.verifyValue()
    if (this.isTemp) return
    if (this.errorPasswordText || this.errorUserNameText) return
    this.authLogin({
      username: this.username,
      password: this.password,
      loginType: `${this.loginType}`,
    })
  }

  private resetQuery() {
    this.$router.replace('/auth_failed')
  }

  private noAccess() {
    this.confim({
      msg: '检测到您没有菜单访问权限！请联系管理员或切换其它用户登录。',
      title: '访问权限提示',
      confirm: '切换用户',
      onConfirm: () => this.resetForm(),
    })
  }

  public changeLoginType(type: number) {
    this.loginType = type
    this.getWechatCode()
  }

  public getWechatCode() {
    const redirectUri = `${location.origin}${location.pathname}`
    WwLogin({
      host: wwConf.HOST,
      id: 'wxReg',
      appid: wwConf.CORP_ID,
      agentid: wwConf.AGENT_ID,
      redirect_uri: `${encodeURIComponent(redirectUri)}`,
      state: wwConf.STATE,
      href: base64Href,
    })
  }

  public async authLogin(params: SpecialValueMap<string>) {
    if (this.isInRequest) return
    this.isInRequest = true
    const res = await this.auth(params)
    this.isInRequest = false
    if (isNull(res)) return this.resetQuery()
    if (typeof res === 'string') return this.resetQuery()

    this.abortLoading(true)
    await this.initExplorer()
    if (this.explorer?.length === 0) {
      await this.cleanup()
      this.resetQuery()
      return this.noAccess()
    }
    this.setIsFixTouch(this.isTemp)
    await this.$router.replace(this.explorerDefUrl ?? '/')
  }

  public async mounted() {
    // const a = [1, 2]
    this.abortLoading(true)
    if (this.isTemp) {
      this.username = 'controlcenter'
      this.password = '123456'
      window.document.body.classList.add('is-touch-screen')
    }
    const { code, state } = this.$route.query
    if (isNull(code) || isNull(state)) return
    this.changeLoginType(2)
    await this.authLogin({ code: code as string, loginType: `${this.loginType}` })
  }

  public beforeDestroy() {
    this.$emit('destroyCaptor')
  }
}
