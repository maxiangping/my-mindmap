/** @format */

type WwLoginParams = {
  host: string
  id: string
  appid: string
  agentid: string
  redirect_uri: string
  state: string
  href?: string
  style?: string
}

const WwLogin = (data: WwLoginParams) => {
  const frame = document.createElement('iframe')
  const { host, id, agentid, appid, redirect_uri, state, style = '', href = '' } = data
  let url = `${host}/wwopen/sso/qrConnect?appid=${appid}&agentid=${agentid}&redirect_uri=${redirect_uri}&state=${state}&login_type=jssdk`
  url += style ? `&style=${style}` : ''
  url += href ? `&href=${href}` : ''
  frame.src = url
  frame.frameBorder = '0'
  // frame.allowTransparency = 'true'
  frame.scrolling = 'no'
  frame.width = '300px'
  frame.height = '360px'
  const el = document.getElementById(id)
  if (el) {
    el.innerHTML = ''
    el.appendChild(frame)
  }

  frame.onload = function () {
    if (frame.contentWindow?.postMessage && window.addEventListener) {
      window.addEventListener('message', function (event) {
        let hostTemp = host
        const hostArr = hostTemp.split(':')
        if (hostArr?.[1] === '80') {
          hostTemp = hostArr[0]
        }
        if (event.data && event.origin.indexOf(hostTemp) > -1) {
          window.location.href = event.data
        }
      })
      frame.contentWindow.postMessage('ask_usePostMessage', '*')
    }
  }
}

export { WwLogin }
