/** @format */

export { default } from './route_tab/view.vue'
