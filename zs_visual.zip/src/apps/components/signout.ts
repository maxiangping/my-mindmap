/** @format */

export { default } from './signout/view.vue'
