/** @format */

export { default } from './send_sms/view.vue'
