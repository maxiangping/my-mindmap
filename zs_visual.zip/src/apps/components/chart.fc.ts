/** @format */

export { default } from './chart/view.fc.vue'
