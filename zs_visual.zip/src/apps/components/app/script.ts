/** @format */

import { Explorer } from '@/apps/components/explorer'
import { AuthComponent } from '@/apps/interceptor/auth'
import { MixinsDialog } from '@/apps/mixins/dialog'
import { MixinsFunctor } from '@/apps/mixins/functor'
import { MixinsLoading } from '@/apps/mixins/loading'
import { isTouch } from '@/apps_modules/dom'
import { IApiMenu } from '@/store/model/base/explorer'
import { Component, Mixins, Provide, Watch } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { GlobalVariable } from '@/apps/common/constant'
import { WebsocketComponent } from '@/apps/mixins/socket'
import { project, projectUrl } from './config'
import { isEmpty } from '@/apps_modules/functor'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
const SocketStore = namespace('Socket')

const NSClient = namespace('Client')
const NSExplorer = namespace('Explorer')

@Component({
  components: { Explorer },
  name: 'App',
})
export default class App extends Mixins(AuthComponent, MixinsFunctor, MixinsDialog, MixinsLoading, WebsocketComponent) {
  @SocketStore.Getter('currentKey')
  public currentKey!: string

  @SocketStore.Getter('pointType')
  public buriedPointType!: string

  public pointDic!: string

  public project = project

  public buriedPointTimer = -1

  public initWebSocketSocket() {
    if (!isEmpty(this.$route.query.isControl as string)) {
      this.initSocketInitiative(PROJECT.CONTROLCENTER)
    }
  }

  @Watch('currentKey')
  public changeRouter(val: string) {
    if (val === 'empty') return
    if (val === 'controlcenter') {
      window.location.href = `${window.location.origin}/${projectUrl[val]}?isControl=1`
    } else if (typeof val === 'string' && val.startsWith('video-')) {
      window.location.href = `${window.location.origin}/${projectUrl.controlcenter}?video=${val.split('-')[1]}`
    } else {
      if (!project.includes(val as PROJECT)) return
      window.location.href = `${window.location.origin}/${projectUrl[val]}${GlobalVariable.AUTH_FAILED_TEMP_URL}?isControl=1`
    }
  }

  /*
  public get hideExplorer() {
    return searchArgs().explorer === 'hide';
  } */

  public get scrollEl() {
    return this.$refs.view as HTMLElement
  }

  public get criticalPoint() {
    return (this.scrollEl.clientHeight - this.scrollEl.scrollTop) / 2
  }

  private get realScroll() {
    return this.scrollEl.scrollHeight - this.scrollEl.clientHeight
  }

  public dynExplorer = ''

  private hideExploreProject = ['home']

  @Provide() public process = this.freeze<IProcess>({
    isProduction: process.env.VUE_APP_NODE_ENV === 'production',
    name: process.env.VUE_APP_PROJECT_NAME as string,
    publicPath: process.env.VUE_APP_PUBLIC_PATH as string,
  })

  // @Prop({ type: Array, default: () => [] })
  // public explorer!: ReadonlyArray<any>

  @NSExplorer.Getter('explorer')
  public explorer!: Readonly<IApiMenu> | undefined

  @NSExplorer.Getter('defUrl')
  public explorerDefUrl!: Readonly<string> | undefined

  @NSExplorer.Getter('showExplorer')
  public showExplorer!: boolean

  @NSClient.Getter
  public viewScrollAble!: boolean

  @NSClient.Action('updatePlayState')
  public updatePlayState!: (value: string) => void

  protected transformStyle = false

  private scrollHandler = this.throttle(() => {
    const scrollTop = this.scrollEl.scrollTop

    if (this.realScroll > 400) {
      return this.setTransformStyle(scrollTop > this.criticalPoint)
    }
    this.setTransformStyle(scrollTop <= this.criticalPoint)
  }, 200)

  @Watch('explorerDefUrl', { immediate: true })
  public onDefaultChanged(defUrl?: string) {
    if (!this.isEmpty(defUrl)) {
      this.$router.addRoutes([
        {
          path: '*',
          redirect: defUrl,
        },
      ])
    }
  }

  public setTransformStyle(statue = false) {
    this.transformStyle = statue
  }

  public async created() {
    this.abortLoading(true)
  }

  public async mounted() {
    this.initWebSocketSocket()

    if (this.$router.currentRoute.path !== GlobalVariable.AUTH_FAILED_URL) {
      if (this.explorer?.length === 0) {
        this.noAccess()
        return
      }
    }

    const view = this.scrollEl
    view.addEventListener('scroll', this.scrollHandler, false)
    if (!isTouch) {
      view.addEventListener('mousewheel', this.scrollAreaHandle, false)
    }
    this.updatePlayState(process?.env?.VUE_APP_AUTOPLAY ?? '')

    /* window.setTimeout(() => {
      this.onRouted(this.$route.query);
    }, 1e2); */
  }

  public beforeDestroy() {
    const view = this.scrollEl
    view.removeEventListener('scroll', this.scrollHandler, false)
    if (!isTouch) {
      view.removeEventListener('mousewheel', this.scrollAreaHandle, false)
    }
  }

  // private syncExplorerState(query: Dictionary<string | Array<string | null>>) {
  //   if (this.explorer?.length ?? -1 > 0) {
  //     this.dynExplorer = this.safeRaw<string>(query, 'explorer', '') === 'hide' ? '' : 'explorer'
  //   }
  // }

  //特殊界面隐藏菜单栏
  private get isHideExploreByPath() {
    const pathList: string[] = [GlobalVariable.AUTH_FAILED_URL, GlobalVariable.AUTH_FAILED_TEMP_URL]
    return pathList.includes(this.$route.path)
  }

  //地址栏有explorer=hide的参数时隐藏菜单栏
  private get isHideExploreByquery() {
    return this.safeRaw<string>(this.$route.query, 'explorer', '') === 'hide'
  }

  //未登陆时隐藏菜单栏
  private get isHideExploreByAuth() {
    if (!this.requireAuth) {
      if (this.$router.currentRoute.path !== GlobalVariable.AUTH_FAILED_URL) {
        const res = this.explorer
        if (res?.length === 0) {
          this.noAccess()
        }
      }
      return false
    } else {
      if (this.$route.path !== GlobalVariable.AUTH_FAILED_URL) {
        this.$router.replace(GlobalVariable.AUTH_FAILED_URL)
      }
    }
    return true
    // return false
  }

  //特殊的项目，隐藏菜单栏 如 home
  private get isHideExploreByProject() {
    return this.hideExploreProject.includes(process.env.VUE_APP_PROJECT_NAME ?? '')
  }

  public get hideExplore() {
    return (
      this.isHideExploreByProject ||
      this.isHideExploreByAuth ||
      this.isHideExploreByquery ||
      this.isHideExploreByPath ||
      !this.showExplorer
    )
  }

  public get hideExploreMargin() {
    return this.isHideExploreByquery || this.isHideExploreByProject
  }

  private noAccess() {
    this.confim({
      msg: '检测到您没有菜单访问权限！请联系管理员或切换其它用户登录。',
      title: '访问权限提示',
      confirm: '切换用户',
      onConfirm: this.signout,
    })
  }

  private scrollAreaHandle(e: Event) {
    if (!this.viewScrollAble) {
      e.preventDefault()
    }
  }
}
