/** @format */

import { PROJECT } from '@/apps_modules/toolbox/runtime'
import { SpecialValueMap } from '@/store/model/common'

const project: PROJECT[] = [
  PROJECT.REPORTPLAT,
  PROJECT.BI,
  PROJECT.DATAGRIP,
  PROJECT.CONTROLCENTER,
  PROJECT.CRM,
  PROJECT.DASHBOARD,
  PROJECT.SYSTEM,
]
const projectUrl: SpecialValueMap<string> = {
  reportplat: 'reportplat',
  datagrip: 'datagrip',
  controlcenter: 'controlcenter/content',
}
export { project, projectUrl }
