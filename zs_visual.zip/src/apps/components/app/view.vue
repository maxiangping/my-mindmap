<!-- @format -->

<template>
  <section id="app" class="flex" :class="[process.name]">
    <!-- <component :is="hideExplore ? '' : 'explorer'" :prop-data="explorer" :transform-style="transformStyle" /> -->
    <article ref="view" class="-mid view-layer" :class="{ 'hide-explore': hideExploreMargin }">
      <router-view />
      <!-- <home></home> -->
    </article>
  </section>
</template>

<script lang="ts">
export { default } from './script'
</script>

<style src="./style.less" lang="less" />
