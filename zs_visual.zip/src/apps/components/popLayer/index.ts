/** @format */

import Navigator from '@/apps/components/Navigator.vue'
import { isEmpty } from '@/apps_modules/functor'
import Dialog from '@/components/Dialog.vue'
import Loading from '@/components/Loading.vue'
import { Component, Vue, Watch } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSLoading = namespace('Loading')
const NSDialog = namespace('Dialog')
const NSNavigator = namespace('Navigator')

@Component({
  components: { Loading, Dialog, Navigator },
  name: 'PopLayer',
})
export default class PopLayer extends Vue {
  @NSLoading.Getter
  public showLoading!: boolean

  @NSDialog.Getter
  public showDialog!: boolean

  @NSNavigator.Getter('expand')
  public expandNavigator!: boolean

  public componentName = ''

  public showLayer = ''

  public renderCaptor() {
    this.showLayer = 'popup'
  }

  public destroyCaptor() {
    this.showLayer = ''
  }

  @Watch('showLoading')
  public onLoadingChange(v: boolean) {
    if (v) {
      this.componentName = 'Loading'
      return
    }
    this.cleanComponent()
  }

  @Watch('showDialog')
  public onDialogChange(v: boolean) {
    if (v) {
      this.componentName = 'Dialog'
      return
    }
    this.cleanComponent()
  }

  @Watch('expandNavigator')
  public onExpandChange(v: boolean) {
    if (v) {
      this.componentName = 'Navigator'
      return
    }
    this.cleanComponent()
  }

  private cleanComponent() {
    // 优先级高于其它
    if (!isEmpty(this.componentName) && !this.showDialog) this.componentName = ''
  }
}
