<!-- @format -->

<template>
  <section id="poplayer" class="poplayer" :class="showLayer">
    <!-- 组件会在 `currentTabComponent` 改变时改变 -->
    <component
      :is="componentName"
      ref="subcomponent"
      class="comp-pop"
      @renderCaptor="renderCaptor"
      @destroyCaptor="destroyCaptor"
    ></component>
  </section>
</template>

<script lang="ts">
export { default } from './index'
</script>

<style src="./style.less" lang="less" scoped></style>
