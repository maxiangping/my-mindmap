/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { GlobalVariable } from '../common/constant'

const NSAuth = namespace('Auth')

@Component({ name: 'AuthComponent' })
export class AuthComponent extends Vue {
  @NSAuth.Getter
  public authed!: boolean

  @NSAuth.Getter
  public requireAuth!: boolean

  @NSAuth.Action('cleanup')
  public cleanup!: () => Promise<void>

  public async signout() {
    await this.cleanup()
    if (this.$route.path !== GlobalVariable.AUTH_FAILED_URL) {
      await this.$router.replace(GlobalVariable.AUTH_FAILED_URL)
    }
  }
}
