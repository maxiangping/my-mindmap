/** @format */

export default [
  {
    component: async () =>
      import(
        /* webpackChunkName: "router_auth_failed" */
        '@/apps/components/auth_failed'
      ),
    name: 'AuthFailed',
    path: '/auth_failed',
  },
  {
    component: async () =>
      import(
        /* webpackChunkName: "signout" */
        '@/apps/components/signout'
      ),
    name: 'Signout',
    path: '/signout',
  },
  {
    component: async () =>
      import(
        /* webpackChunkName: "router_auth_failed" */
        '@/apps/components/auth_failed'
      ),
    name: 'AuthFailedTemp',
    path: '/auth_failed_temp',
    props: () => {
      const isTemp = true
      return { isTemp }
    },
  },
]
