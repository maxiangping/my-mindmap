/** @format */

import { DirectiveOptions } from 'vue'
import { DirectiveBinding } from 'vue/types/options'
const setImg = async (el: HTMLElement, binding: DirectiveBinding) => {
  const value: string = binding.value
  const v = await Promise.resolve<string>(require(`@/assets/${value}`))

  el.setAttribute(binding.arg ?? '', v)
}
export const VAsset: DirectiveOptions = {
  bind: setImg,
  update: setImg,
}
