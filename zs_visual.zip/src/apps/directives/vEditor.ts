/** @format */

import { isNull } from '@/apps_modules/functor'
import { DirectiveOptions } from 'vue'
import { DirectiveBinding } from 'vue/types/options'
const updatePosition = async (el: HTMLElement, binding: DirectiveBinding) => {
  let containerEle!: HTMLElement
  let currentStyles = {
    left: '100vw',
    top: '100vh',
    display: 'none',
  }
  if (!isNull(el.parentElement) && binding.value) {
    containerEle = el.parentElement
    const parentPosition = containerEle.getBoundingClientRect()
    currentStyles = {
      left: `${parentPosition.left}px`,
      top: `${parentPosition.top - el.clientHeight}px`,
      display: 'block',
    }
  }
  el.style.top = `${currentStyles.top}`
  el.style.left = `${currentStyles.left}`
  el.style.display = `${currentStyles.display}`
}
export const VEditor: DirectiveOptions = {
  inserted: updatePosition,
  update: updatePosition,
}
