/** @format */

import { DirectiveOptions } from 'vue'
import { isNull, hasKey } from '@/apps_modules/functor'
const bindEvent = async (el: HTMLElement) => {
  const dataTransfer = new DataTransfer()
  dataTransfer.dropEffect = 'all'
  let timer = -1
  let copyEle: HTMLElement | null = null
  // if ('ontouchstart' in document) {
  el.addEventListener(
    'touchstart',
    (e: TouchEvent) => {
      e.stopPropagation()
      timer = window.setTimeout(() => {
        const clickEvent = new Event('click')
        el.querySelector('.empty-dropdown')?.dispatchEvent(clickEvent)
      }, 2 * 1e3)
      dataTransfer.effectAllowed = 'move'
      dataTransfer.setDragImage(el, el.clientWidth / 2, el.clientHeight / 2)
      const dragstartEvent = new DragEvent('dragstart', {
        dataTransfer,
      })
      copyEle = el.cloneNode(true) as HTMLElement
      document.body.appendChild(copyEle)
      el.dispatchEvent(dragstartEvent)
    },
    false
  )
  el.addEventListener('touchmove', (e: TouchEvent) => {
    // e.preventDefault()
    window.clearTimeout(timer)
    e.stopPropagation()
    const touch = e.changedTouches[0]
    if (isNull(copyEle)) return
    copyEle.style.position = 'fixed'
    copyEle.style.left = `${touch.clientX}px`
    copyEle.style.top = `${touch.clientY}px`
  })
  el.addEventListener('touchend', (e: TouchEvent) => {
    clearEle()
    e.stopPropagation()
    const touch = e.changedTouches[0]
    const target = document.elementFromPoint(touch.pageX, touch.pageY)
    if (isNull(target)) return
    const dragEvent = new DragEvent('drop', {
      dataTransfer,
      bubbles: true,
      clientX: e.changedTouches[0].clientX,
      clientY: e.changedTouches[0].clientY,
    })
    target.dispatchEvent(dragEvent)
  })
  const clearEle = () => {
    window.clearTimeout(timer)
    if (isNull(copyEle)) return
    document.body.removeChild(copyEle)
    copyEle = null
  }
  el.addEventListener('touchcancel', clearEle)
  // }
}

const unbindEvent = (el: HTMLElement) => {
  if (hasKey<Document>(window.document, 'ontouchstart')) {
    el.ontouchstart = null
    el.ontouchend = null
  }
}
export const VTouch: DirectiveOptions = {
  inserted: bindEvent,
  unbind: unbindEvent,
}
