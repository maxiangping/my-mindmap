/** @format */

import { DirectiveOptions } from 'vue'
import { DirectiveBinding } from 'vue/types/options'
import { isEmpty, isNull } from '@/apps_modules/functor'
const updateSelectCondition = async (el: HTMLElement, binding: DirectiveBinding) => {
  if (isNull(binding.value)) return
  if (binding.value === binding.oldValue) return
  const searchEvent = new KeyboardEvent('keyup', {
    bubbles: false,
    key: 'Enter',
  })
  const valueList = binding.value.split('-')
  const triggerType = valueList[1]
  switch (triggerType) {
    case 'clear':
      if (!isEmpty(valueList[0])) return
      el.dispatchEvent(searchEvent)
      break
    case 'input':
      el.dispatchEvent(searchEvent)
      break
    default:
  }
}
export const VInput: DirectiveOptions = {
  componentUpdated: updateSelectCondition,
}
