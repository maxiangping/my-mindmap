/** @format */

import { DirectiveOptions } from 'vue'
import { hasKey } from '@/apps_modules/functor'

const tapHandler = (e: Event | TouchEvent) => {
  const src = (e.srcElement || e.currentTarget) as HTMLElement
  e.stopImmediatePropagation()
  // fix bug
  // Ignored attempt to cancel a touchend event with cancelable=false,
  // for example because scrolling is in progress and cannot be interrupted.
  if (e.preventDefault) {
    e.preventDefault()
  }
  e.stopPropagation()
  const evt = document.createEvent('HTMLEvents')
  evt.initEvent('click', true, true)

  src.dispatchEvent(evt)
}

export const VTap: DirectiveOptions = {
  bind: (el: HTMLElement) => {
    // if ('ontouchend' in document) {
    if (hasKey<Document>(window.document, 'ontouchend')) {
      el.addEventListener('touchend', tapHandler, false)
    }
  },
  unbind: (el: HTMLElement) => {
    // if ('ontouchend' in document) {
    if (hasKey<Document>(window.document, 'ontouchend')) {
      el.removeEventListener('touchend', tapHandler, false)
    }
  },
}
