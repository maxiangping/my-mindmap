/** @format */

import { DirectiveOptions } from 'vue'
import { isNull } from '@/apps_modules/functor'
const handle = async (el: HTMLElement) => {
  const inner = el.querySelector('.el-input__inner') as HTMLInputElement
  if (isNull(inner)) return
  Promise.resolve().then(() => {
    inner.focus()
  })
}
export const VFoucs: DirectiveOptions = {
  inserted: handle,
}
