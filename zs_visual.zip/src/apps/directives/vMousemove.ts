/** @format */

import { DirectiveOptions } from 'vue'
import { isNull, hasKey } from '@/apps_modules/functor'
const bindEvent = async (el: HTMLElement) => {
  const dataTransfer = new DataTransfer()
  dataTransfer.dropEffect = 'all'
  // if ('ontouchstart' in document) {
  el.addEventListener(
    'touchstart',
    (e: TouchEvent) => {
      e.stopPropagation()
      const clickEvent = new MouseEvent('mousedown', {
        ...((e.changedTouches[0] as unknown) as EventInit),
        bubbles: true,
        screenX: e.changedTouches[0].screenX,
        screenY: e.changedTouches[0].screenY,
      })
      el.dispatchEvent(clickEvent)
    },
    false
  )
  el.addEventListener('touchmove', (e: TouchEvent) => {
    // e.preventDefault()
    e.stopPropagation()
    const clickEvent = new MouseEvent('mousemove', {
      ...((e.changedTouches[0] as unknown) as EventInit),
      bubbles: true,
      screenX: e.changedTouches[0].screenX,
      screenY: e.changedTouches[0].screenY,
    })
    el.dispatchEvent(clickEvent)
  })
  el.addEventListener('touchend', (e: TouchEvent) => {
    e.stopPropagation()
    const touch = e.changedTouches[0]
    const target = document.elementFromPoint(touch.pageX, touch.pageY)
    if (isNull(target)) return
    const clickEvent = new MouseEvent('mouseup', {
      ...((e.changedTouches[0] as unknown) as EventInit),
      bubbles: true,
      screenX: e.changedTouches[0].screenX,
      screenY: e.changedTouches[0].screenY,
    })
    target.dispatchEvent(clickEvent)
  })
  el.addEventListener('touchcancel', () => {
    /** void function */
  })
  // }
}
const unbindEvent = (el: HTMLElement) => {
  if (hasKey<Document>(window.document, 'ontouchstart')) {
    el.ontouchstart = null
    el.ontouchend = null
  }
}
export const VMouse: DirectiveOptions = {
  inserted: bindEvent,
  unbind: unbindEvent,
}
