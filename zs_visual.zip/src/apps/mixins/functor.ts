/** @format */

import { deepCopy, isEmpty, isNull, random, rawProp, throttle } from '@/apps_modules/functor'
import { timestampHHMMSS } from '@/apps_modules/toolbox/timestamp'
import { Component, Vue } from 'vue-property-decorator'

@Component
export class MixinsFunctor extends Vue {
  public keepOneDecimal(data: string | number, count = 1): string {
    if (this.isEmpty(`${data}`)) return ''
    const r = Number(data).toFixed(count)

    return Number(r) === 0 ? '0' : r
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public safeRaw<T>(source: any, field: string | null, def: T): T {
    return rawProp<T>(source, field, def)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public isNull(arg: any): arg is null | undefined {
    return isNull(arg)
  }

  public isEmpty(arg?: string | null): arg is null | undefined | '' {
    return isEmpty(arg)
  }

  public freeze<T>(v: T): Readonly<T> {
    return Object.freeze<T>(v)
  }

  public deepCopy<T>(target: T): T {
    return deepCopy<T>(target)
  }

  public hexRnd() {
    return `${random()}`.replace(/\./, 'x').substr(0, 8)
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  public throttle(fn: (...args: any) => void | Promise<void>, wait = 100) {
    return throttle(fn, wait)
  }

  public timestampHHMMSS(sep?: string, timeStamp?: number): string {
    return timestampHHMMSS(sep, timeStamp)
  }
}
