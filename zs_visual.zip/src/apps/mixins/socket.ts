/** @format */

import { isEmpty, isNull } from '@/apps_modules/functor'
import { ZoneData } from '@/store/model/base/socket'
import { SocketParams } from '@/store/model/common'
import getWebsocketInstance from '@/store/net/io'

import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'
import { PROJECT } from '@/apps_modules/toolbox/runtime'
import { getUuid } from '@/apps_modules/toolbox/math'
const SocketStore = namespace('Socket')

@Component
export class WebsocketComponent extends Vue {
  public ws!: WebSocket

  public messageIdList: string[] = []

  // 通知已完成对应的请求
  @SocketStore.Action('setData')
  public setSocketData!: (params: ZoneData) => void

  // 清除当前组件的数据
  @SocketStore.Action('clearSocketData')
  public clearSocketData!: (params: string[]) => void

  public async wsSendRequest(params: SocketParams[], project: PROJECT) {
    this.messageIdList = params.map((item: SocketParams) => item.id) as string[]
    await this.wsSendMessage(
      params.map((item: SocketParams) => JSON.stringify(item)),
      project
    )
  }

  // 发送请求
  public async wsSendMessage(keys: string[], project: PROJECT) {
    // if (isNull(this.ws)) {
    await this.initSocket(project)
    // }
    keys.forEach((item: string) => {
      this.ws.send(item)
    })
    // keys.map(this.ws.send)
  }

  // 初始化连接
  public initSocket(project: PROJECT) {
    return new Promise((resolve: () => void, reject: () => void) => {
      const socket = getWebsocketInstance(project)
      if (isNull(socket)) {
        return
      }
      this.ws = socket
      if (project === 'crm') {
        this.ws.onmessage = this.wsOnMessageFlow.bind(this)
      } else {
        this.ws.onmessage = this.wsOnMessage.bind(this)
      }
      if (this.ws.readyState === 1) {
        resolve()
      } else {
        this.ws.onopen = resolve
      }
      this.ws.onerror = reject
    })
  }

  // 返回数据 crm项目
  public wsOnMessageFlow(event: MessageEvent) {
    const messageData = JSON.parse(event.data)
    const { data, code } = messageData
    if (code !== 0 && code !== 500) return
    if (code === 500) {
      // this.$message(messageData.msg)
    }
    if (!isNull(data)) {
      this.setSocketData({
        id: !isNull(data.nodeBoxId) ? data.nodeBoxId : getUuid(),
        data,
      })
    }
  }

  // 返回数据
  public wsOnMessage(event: MessageEvent) {
    const messageData = JSON.parse(event.data.replace(/\\/g, ''))
    if (isEmpty(messageData)) return
    const { data, id, code } = messageData
    if (isNull(id)) {
      if (isNull(code)) {
        this.setSocketData({
          id: messageData,
          data: messageData,
        })
        return
      }
    }
    if (code === 0) {
      this.setSocketData({
        id: !isNull(id) ? id : getUuid(),
        data,
      })
      return
    }
  }

  // 清除数据
  public clearZone(ids: string[]) {
    this.clearSocketData(ids)
  }

  public beforeDestroy() {
    this.clearZone(this.messageIdList)
  }

  public async initSocketInitiative(project: PROJECT) {
    await this.initSocket(project)
  }

  public wsOnClose() {
    this.ws?.close()
  }
}
