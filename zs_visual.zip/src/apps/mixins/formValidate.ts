/** @format */
import { Component, Vue } from 'vue-property-decorator'
import { isEmpty } from '@/apps_modules/functor'
import { SendSmsParams } from '@/store/model/common'
@Component({
  name: 'formValidate',
})
export default class FormValidate extends Vue {
  public get formData(): SendSmsParams | { smsType: number } {
    return { smsType: 0 }
  }
  public createValidate(smsType: number, msg: string) {
    return (_: Record<string, unknown>, value: string, callback: (errorMsg?: Error) => void) => {
      if (this.formData.smsType === smsType && isEmpty(value)) {
        callback(new Error(msg))
      }
      callback()
    }
  }

  public validateDesc(_: Record<string, unknown>, value: string, callback: (errorMsg?: Error) => void) {
    const descReg = /[【】]/
    if (descReg.test(value)) {
      callback(new Error('不支持【】，可能会与签名混淆'))
    }
    callback()
  }
}
