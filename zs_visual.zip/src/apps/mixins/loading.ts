/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSLoading = namespace('Loading')

@Component
export class MixinsLoading extends Vue {
  @NSLoading.Action('abort')
  public abortLoading!: (unsafeClean: boolean) => void
}
