/** @format */

import { IApiFlatMenu } from '@/store/model/base/explorer'
import { Component, Vue } from 'vue-property-decorator'
import { RawLocation, Route } from 'vue-router'
import { namespace } from 'vuex-class'
import { GlobalVariable } from '../common/constant'

const NSExplorer = namespace('Explorer')

@Component
export class MixinsRouteHooks extends Vue {
  @NSExplorer.Getter('filter')
  protected explorerFilter!: ReadonlyArray<IApiFlatMenu>

  public afterEnter: (from: Route) => void = () => {}

  public beforeRouteLeave(
    to: Route,
    from: Route,
    next: (to?: RawLocation | false | ((vm: Vue) => unknown) | void) => void
  ) {
    const auth_extends: string | string[] = [].concat(to.meta.auth_extends)
    const auth_extends_name: string[] = [].concat(to.meta.auth_extends_name)
    if (auth_extends.includes(from.path) || auth_extends_name.includes(from.name ?? '')) {
      return next()
    }
    if (
      to.path !== GlobalVariable.AUTH_FAILED_URL &&
      this.explorerFilter.filter((item: IApiFlatMenu) => item.url === to.path).length <= 0
    ) {
      return next(false)
    }

    next()
  }

  public async beforeRouteEnter(
    _: Route,
    __: Route,
    next: (to?: RawLocation | false | ((vm: Vue) => unknown) | void) => void
  ) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    next((vm: any) => {
      vm.$watch('explorerFilter', (a: ReadonlyArray<IApiFlatMenu>) => {
        if (a.length === 0) {
          next(GlobalVariable.AUTH_FAILED_URL)
        }
      })
      vm?.afterEnter(__)
    })
  }
}
