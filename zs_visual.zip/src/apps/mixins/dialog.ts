/** @format */

import { DialogState } from '@/store/model/base/dialog'
import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSDialog = namespace('Dialog')

@Component
export class MixinsDialog extends Vue {
  @NSDialog.Action('showDialog')
  private showDialog!: (data: DialogState) => void

  public confim({
    title = '',
    cancel = '',
    confirm = '确定',
    msg = '',
    onConfirm,
    onCancel,
  }: {
    title: string
    cancel?: string
    confirm?: string
    msg: string
    onConfirm?: VoidFunction
    onCancel?: VoidFunction
  }) {
    this.showDialog({
      cancel,
      confirm,
      onConfirm,
      onCancel,
      msg,
      title,
    })
  }
}
