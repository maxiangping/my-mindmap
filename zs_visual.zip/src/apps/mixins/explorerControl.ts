/** @format */

import { Component, Vue } from 'vue-property-decorator'
import { namespace } from 'vuex-class'

const NSExplorer = namespace('Explorer')

@Component
export class ExplorerControl extends Vue {
  @NSExplorer.Action('changeExplorerStatus')
  public changeExplorerStatus!: (status: boolean) => void

  public mounted() {
    this.$nextTick(() => {
      this.changeExplorerStatus(false)
    })
  }

  public beforeDestroy() {
    this.changeExplorerStatus(true)
  }
}
