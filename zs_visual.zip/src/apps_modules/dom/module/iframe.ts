/** @format */

import { isEmpty, isNull } from '@/apps_modules/functor'
import { raw, save } from '@/store/sync'

let _iframe!: HTMLIFrameElement

const getIframe = (): HTMLIFrameElement => {
  if (isNull(_iframe)) {
    _iframe = document.createElement('iframe')
    _iframe.setAttribute('width', '100%')
    _iframe.setAttribute('height', '100%')
    _iframe.setAttribute('scrolling', 'yes')
    _iframe.setAttribute('frameborder', '0')
    _iframe.setAttribute('marginheight', '0')
    _iframe.setAttribute('marginwidth', '0')
    _iframe.setAttribute('class', 'frame')
    _iframe.setAttribute('vspace', '0')
    _iframe.setAttribute('target', '_parent')
    _iframe.setAttribute('src', 'about:blank')
  }
  return _iframe
}

export const createIframe = async (
  id = -1,
  url = 'about:blank',
  loadHandle: VoidFunction,
  { width = 0, height = 0, zoom = 0, xAxis = 0 }
): Promise<HTMLIFrameElement> => {
  const key = `iframe${id}`
  const iframe = getIframe()
  iframe.setAttribute('id', key)
  iframe.setAttribute('name', key)

  // android polyfill

  width = Math.floor(width)
  height = Math.floor(height)

  let style = await raw<string>(key, { local: true })
  if (isNull(style)) {
    style = `
            width:${width}px;
            height:${height}px;
            transform-origin: 0 top 0;
            transform: scale3D(${zoom},${zoom},1) translateX(${xAxis}px);
        `
    save(key, style, { local: true })
  }

  iframe.setAttribute('style', style)

  const frameUrl = iframe.src

  if (!isEmpty(frameUrl) && frameUrl !== 'about:blank') {
    const contentWindow = iframe.contentWindow
    if (!isNull(contentWindow)) {
      window.setTimeout(() => {
        contentWindow.location.replace(url)
      }, 6e2)
    }
  } else {
    iframe.setAttribute('src', url)
  }

  iframe.addEventListener('load', loadHandle, false)

  return iframe
}

export const destroyIframe = (iframe: HTMLIFrameElement, loadHandle: VoidFunction) => {
  iframe.removeEventListener('load', loadHandle, false)
  iframe.setAttribute('src', 'about:blank')
  if (iframe.parentElement instanceof Element) {
    iframe.parentElement.removeChild(iframe)
  }
}
