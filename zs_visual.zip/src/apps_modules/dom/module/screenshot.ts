/** @format */

import { isEmpty } from '@/apps_modules/functor'
import { DomToImgParams } from '@/store/model/common'

/**
 * 图片转换为base64地址
 * @param img 要转换的图片元素
 */

function getImgAsBase64(img: HTMLImageElement) {
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')
  canvas.width = img.width
  canvas.height = img.height
  ctx?.drawImage(img, 0, 0)
  return canvas.toDataURL()
}

/**
 *  根据dom生成svg图片
 * @param target 需要绘制成缩略图的元素
 * @param imgSelector 可选，需要特殊处理的Img元素的选择器
 * @param filterSelector 可选，需要不显示的元素的选择器
 * @param specialHandle
 */
async function getImgsrcByDom(params: DomToImgParams): Promise<string> {
  const { target, imgSelector, filterSelector, specialHandle, style = '', canvasSelect } = params
  const cloneDom = target.cloneNode(true) as HTMLElement
  cloneDom.setAttribute('xmlns', 'http://www.w3.org/1999/xhtml')

  //过滤不显示的元素
  handleFilterEle(cloneDom, filterSelector)
  //单独处理img元素
  handleImgEle(cloneDom, target, imgSelector)
  //单独处理canvas元素
  handleCanvasEle(canvasSelect ?? '', cloneDom, target)
  //执行需要的其他特殊操作
  specialHandle?.(cloneDom)

  const width = target.offsetWidth
  const height = target.offsetHeight
  const xmlContent = new XMLSerializer().serializeToString(cloneDom).replace(/#/g, '%23').replace(/\n/g, '%0A')
  const xmlStyle = style.replace(/#/g, '%23').replace(/\n/g, '%0A')
  return `data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" ><foreignObject x="0" y="0" width="100%" height="100%">${xmlContent}${xmlStyle}</foreignObject></svg>`

  //
}

/**
 *
 * @param cloneDom 根节点
 * @param targetDom 源根节点
 * @param imgSelector 图片元素的选择器
 */
function handleImgEle(cloneDom: HTMLElement, targetDom: HTMLElement, imgSelector = '') {
  if (isEmpty(imgSelector)) return
  const imgList = cloneDom.querySelectorAll(imgSelector)
  const realImgList = targetDom.querySelectorAll(imgSelector)
  for (let i = 0; i < imgList.length; i++) {
    const currentImg = imgList[i] as HTMLImageElement
    const realImg = realImgList[i] as HTMLImageElement
    currentImg.src = getImgAsBase64(realImg)
  }
}

/**
 * 过滤不需要显示的元素
 * @param cloneDom 根节点
 * @param filterSelector 要隐藏的元素的选择器
 */
function handleFilterEle(cloneDom: HTMLElement, filterSelector = '') {
  if (isEmpty(filterSelector)) return
  const filterDomList = cloneDom.querySelectorAll(filterSelector)
  for (const filterDom of filterDomList) {
    ;(<HTMLElement>filterDom).style.display = 'none'
  }
}

/**
 * 处理canvas元素
 * @param canvasSelect
 * @param cloneDom
 * @param target
 */
async function handleCanvasEle(canvasSelect: string, cloneDom: HTMLElement, target: HTMLElement) {
  //单独处理canvas元素
  if (isEmpty(canvasSelect)) return
  const excelList = target.querySelectorAll(canvasSelect)
  const cloneExcelList = cloneDom.querySelectorAll(canvasSelect)
  if (!excelList.length) return
  ;[...excelList].forEach((item, index) => {
    const currentCanvas = item.querySelector('.x-spreadsheet-table') as HTMLCanvasElement
    const src = currentCanvas.toDataURL('image/png', 0.5)
    // image.onload = () => {
    cloneExcelList[index].innerHTML = `<img alt="" src=${src} width="${Number.parseInt(
      currentCanvas.style.width
    )}" height="${Number.parseInt(currentCanvas.style.height)}" />`
    // }
  })
}
/**
 *  将base64位的图片地址绘制到canvas
 * @param src 图片资源的src
 * @param canvas 绘制图片的canvas元素
 * return 生成的base64位图片的src
 */
function drawImageBySrc(src: string, canvas: HTMLCanvasElement) {
  const img = new Image()
  const ctx = canvas?.getContext('2d')
  img.src = src
  img.onload = function () {
    ctx?.clearRect(0, 0, canvas.width, canvas.height)
    ctx?.drawImage(img, 0, 0, img.width, img.height, 0, 0, canvas.width, canvas.height)
  }
}

export { getImgsrcByDom, drawImageBySrc, getImgAsBase64 }
