/** @format */

import { hasKey } from '@/apps_modules/functor'

let documentHiddenName = ''
let visibilityChange = ''

if (typeof document.hidden !== 'undefined') {
  // Opera 12.10 and Firefox 18 and later support
  documentHiddenName = 'hidden'
  visibilityChange = 'visibilitychange'
  // } else if ('msHidden' in document) {
} else if (hasKey<Document>(window.document, 'msHidden' as 'hidden')) {
  documentHiddenName = 'msHidden'
  visibilityChange = 'msvisibilitychange'
  // } else if ('webkitHidden' in document) {
} else if (hasKey<Document>(window.document, 'webkitHidden' as 'hidden')) {
  documentHiddenName = 'webkitHidden'
  visibilityChange = 'webkitvisibilitychange'
}

// 设备判断
export enum DeviceType {
  IOS,
  ANDROID,
  OTHER,
}
let device: DeviceType
const witchDevice = (): DeviceType => {
  if (!device) {
    device = DeviceType.OTHER
    const ua: string = navigator.userAgent
    if (/(iPhone|iPad|iPod|iOS)/i.test(ua)) {
      return (device = DeviceType.IOS)
    }
    if (/(Android)/i.test(ua)) {
      return (device = DeviceType.ANDROID)
    }
  }
  return device
}

const searchArgs = (): SearchType => {
  const _search: SearchType = {}

  location.search
    .substr(1)
    .split('&')
    .forEach(kv => {
      const pointer = kv.indexOf('=')
      const key = kv.substr(0, pointer)
      const value = kv.substr(pointer + 1)
      _search[key] = value
    })

  return _search
}

const requestFullScreen = () => {
  const docEl = document.documentElement

  docEl.requestFullscreen()
}
declare type TouchEventName = 'touchstar' | 'touchmove' | 'touchend'
const eventList: TouchEventName[] = ['touchstar', 'touchmove', 'touchend']
// const isTouch = ['touchstar', 'touchmove', 'touchend'].every(eventName => eventName in document)
const isTouch = eventList.every(eventName => hasKey<Document>(window.document, eventName as 'hidden'))

export { documentHiddenName, visibilityChange, witchDevice, searchArgs, isTouch, requestFullScreen }
