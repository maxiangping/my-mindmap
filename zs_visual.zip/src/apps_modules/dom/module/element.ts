/** @format */

import { isNull } from '@/apps_modules/functor'

export const enum Event {
  CLICK = 'click',
  CHANGE = 'change',
  TOUCHEND = 'touchend',
}

export const createElement = (tagName: string, attrs?: KV, parent?: Element | DocumentFragment) => {
  const el = document.createElement(tagName)
  if (!isNull(attrs)) {
    Object.keys(attrs).forEach((key: string) => el.setAttribute(key, attrs[key]))
  }
  if (!isNull(parent)) {
    parent.appendChild(el)
  }
  return el
}

export const dispatchEvent = (element: HTMLElement, event: Event) => {
  const evt = new MouseEvent(event)
  element.dispatchEvent(evt)
}

export const dispachTouchEvent = (element: HTMLElement, event: Event) => {
  const evt = new TouchEvent(event)
  element.dispatchEvent(evt)
}
