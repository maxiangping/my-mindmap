/** @format */

type CallBackFunction = (msg: string) => void

enum Func {
  REFRESH_SESSION = 'rs',
}
class JSBridgeSdk {
  private static _instance: JSBridgeSdk
  private fns: Map<Func, CallBackFunction>
  private constructor() {
    // do nothing here
    this.fns = new Map<Func, CallBackFunction>()
  }

  public static init() {
    if (!JSBridgeSdk._instance) {
      JSBridgeSdk._instance = new JSBridgeSdk()
    }
    return JSBridgeSdk._instance
  }

  public registCallback(key: Func, callback: CallBackFunction) {
    this.fns.set(key, callback)
  }

  public callFunc(key: Func, data: string) {
    this.fns.get(key)?.call(this, data)
  }
}

const sigJSBridgeSdk = JSBridgeSdk.init()

// for webview
const syncSession = (sessionId: string) => {
  sigJSBridgeSdk.callFunc(Func.REFRESH_SESSION, sessionId)
}

// for client
const wvNativeSession = (msg: string) => {
  if (window.NativeSession !== undefined) {
    NativeSession.postMessage(msg)
  }
}

const registCallback = (key: Func, callback: CallBackFunction) => {
  sigJSBridgeSdk.registCallback(key, callback)
}

export default { version: '0.1.0', Func, registCallback, syncSession, wvNativeSession }
