/** @format */
import FusionCharts from 'fusioncharts'
import { VueConstructor } from 'vue'
import Dashboard from './theme/dashboard'
import { VueFusionchart } from './vue-fusionchart'

const cdnPath = process.env.VUE_APP_CDN_PATH
const install = (Vue: VueConstructor<Vue>) => {
  FusionCharts.setScriptBaseURI(`${cdnPath}fusioncharts/`)

  FusionCharts.addDep(Dashboard)
  Vue.component('fusioncharts', VueFusionchart)
}

export default install
