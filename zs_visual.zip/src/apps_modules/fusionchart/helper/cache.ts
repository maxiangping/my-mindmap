/** @format */

import { FusionCharts } from 'fusioncharts'
import { isNull } from '../../functor'
const fcInstanceMap: Map<string, FusionCharts> = new Map()

export function disposeCachedFusionchart(id: string) {
  const instance = fcInstanceMap.get(id)
  if (!isNull(instance)) {
    if (instance.dispose) {
      instance.dispose()
    }
    fcInstanceMap.delete(id)
  }
}

export function cacheFusionchart(id: string, instance: FusionCharts) {
  if (fcInstanceMap.has(id)) {
    disposeCachedFusionchart(id)
  }
  fcInstanceMap.set(id, instance)
}

export const getCachedFusionchart = fcInstanceMap.get
