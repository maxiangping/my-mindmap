/** @format */

import { FusionChartStatic } from 'fusioncharts'
import { isNull } from '../functor'
import { DataSource, DataSourceType, DataTableSourceType, ModuleFun, ModuleType } from './fusionchart.type'

export const addDep = <T extends FusionChartStatic>(FC: T, _module: ModuleType & ModuleFun) => {
  if (isNull(FC)) return
  if ((_module.getName && _module.getType) || (_module.name && _module.type)) {
    FC.addDep(_module)
  } else {
    _module<T>(FC)
  }
}

export function checkIfDataTableExists(dataSource: DataSource): boolean {
  // return dataSource && dataSource.data && dataSource.data._dataStore
  return (
    !isNull(dataSource) &&
    !isNull((dataSource as DataSourceType).data) &&
    !isNull((dataSource as DataTableSourceType).data._dataStore)
  )
}

export function cloneDataSource<T extends DataSource | U, U = { [K in keyof T]: T[K] }>(
  obj: T,
  purpose = 'clone'
): T | T[] {
  const type = typeof obj
  if (isNull(obj) || ['string', 'number', 'function', 'boolean'].includes(type)) {
    return obj as T
  }
  if (Array.isArray(obj)) {
    const arr: T[] = []
    obj.forEach((data: T) => arr.push(cloneDataSource(data) as T))
    return arr
  }
  if (obj instanceof Object) {
    const clonedObj = {} as { [R in keyof T]: T[R] }
    for (const key of Object.keys(obj) as (keyof T)[]) {
      // Edge case handling for DataTable
      if (key === 'data') {
        const data = obj[key]
        if (data && (data as DataTableSourceType['data'])?._dataStore && ['clone', 'diff'].includes(purpose)) {
          if (purpose === 'clone') {
            clonedObj[key] = obj[key]
            // eslint-disable-next-line no-underscore-dangle
          } else if (purpose === 'diff') {
            clonedObj[key] = '-' as T[keyof T]
          }
        } else {
          clonedObj[key] = cloneDataSource(obj[key]) as T[keyof T]
        }
        continue
      }
      clonedObj[key] = cloneDataSource(obj[key]) as T[keyof T]
    }
    return clonedObj
  }
  return undefined as T
}
