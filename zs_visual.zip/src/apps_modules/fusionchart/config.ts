/** @format */

import { SpecialValueMap } from '@/store/model/common'

export const optionsMap = {
  type: 'type',
  id: 'id',
  width: 'width',
  height: 'height',
  dataFormat: 'dataFormat',
  dataSource: 'dataSource',
  events: 'events',
  link: 'link',
  showDataLoadingMessage: 'showDataLoadingMessage',
  showChartLoadingMessage: 'showChartLoadingMessage',
  baseChartMessageFont: 'baseChartMessageFont',
  baseChartMessageFontSize: 'baseChartMessageFontSize',
  baseChartMessageColor: 'baseChartMessageColor',
  dataLoadStartMessage: 'dataLoadStartMessage',
  dataLoadErrorMessage: 'dataLoadErrorMessage',
  dataInvalidMessage: 'dataInvalidMessage',
  dataEmptyMessage: 'dataEmptyMessage',
  typeNotSupportedMessage: 'typeNotSupportedMessage',
  loadMessage: 'loadMessage',
  renderErrorMessage: 'renderErrorMessage',
  containerBackgroundColor: 'containerBackgroundColor',
  containerBackgroundOpacity: 'containerBackgroundOpacity',
  containerClassName: 'containerClassName',
  baseChartMessageImageHAlign: 'baseChartMessageImageHAlign',
  baseChartMessageImageVAlign: 'baseChartMessageImageVAlign',
  baseChartMessageImageAlpha: 'baseChartMessageImageAlpha',
  baseChartMessageImageScale: 'baseChartMessageImageScale',
  typeNotSupportedMessageImageHAlign: 'typeNotSupportedMessageImageHAlign',
  typeNotSupportedMessageImageVAlign: 'typeNotSupportedMessageImageVAlign',
  typeNotSupportedMessageImageAlpha: 'typeNotSupportedMessageImageAlpha',
  typeNotSupportedMessageImageScale: 'typeNotSupportedMessageImageScale',
  dataLoadErrorMessageImageHAlign: 'dataLoadErrorMessageImageHAlign',
  dataLoadErrorMessageImageVAlign: 'dataLoadErrorMessageImageVAlign',
  dataLoadErrorMessageImageAlpha: 'dataLoadErrorMessageImageAlpha',
  dataLoadErrorMessageImageScale: 'dataLoadErrorMessageImageScale',
  dataLoadStartMessageImageHAlign: 'dataLoadStartMessageImageHAlign',
  dataLoadStartMessageImageVAlign: 'dataLoadStartMessageImageVAlign',
  dataLoadStartMessageImageAlpha: 'dataLoadStartMessageImageAlpha',
  dataLoadStartMessageImageScale: 'dataLoadStartMessageImageScale',
  dataInvalidMessageImageHAlign: 'dataInvalidMessageImageHAlign',
  dataInvalidMessageImageVAlign: 'dataInvalidMessageImageVAlign',
  dataInvalidMessageImageAlpha: 'dataInvalidMessageImageAlpha',
  dataInvalidMessageImageScale: 'dataInvalidMessageImageScale',
  dataEmptyMessageImageHAlign: 'dataEmptyMessageImageHAlign',
  dataEmptyMessageImageVAlign: 'dataEmptyMessageImageVAlign',
  dataEmptyMessageImageAlpha: 'dataEmptyMessageImageAlpha',
  dataEmptyMessageImageScale: 'dataEmptyMessageImageScale',
  renderErrorMessageImageHAlign: 'renderErrorMessageImageHAlign',
  renderErrorMessageImageVAlign: 'renderErrorMessageImageVAlign',
  renderErrorMessageImageAlpha: 'renderErrorMessageImageAlpha',
  renderErrorMessageImageScale: 'renderErrorMessageImageScale',
  loadMessageImageHAlign: 'loadMessageImageHAlign',
  loadMessageImageVAlign: 'loadMessageImageVAlign',
  loadMessageImageAlpha: 'loadMessageImageAlpha',
  loadMessageImageScale: 'loadMessageImageScale',
  /// ////////////////////////////////////////////////////
  dataformat: 'dataFormat',
  datasource: 'dataSource',
  showdataloadingmessage: 'showDataLoadingMessage',
  showchartloadingmessage: 'showChartLoadingMessage',
  basechartmessagefont: 'baseChartMessageFont',
  basechartmessagefontsize: 'baseChartMessageFontSize',
  basechartmessagecolor: 'baseChartMessageColor',
  dataloadstartmessage: 'dataLoadStartMessage',
  dataloaderrormessage: 'dataLoadErrorMessage',
  datainvalidmessage: 'dataInvalidMessage',
  dataemptymessage: 'dataEmptyMessage',
  typenotsupportedmessage: 'typeNotSupportedMessage',
  loadmessage: 'loadMessage',
  rendererrormessage: 'renderErrorMessage',
  containerbackgroundcolor: 'containerBackgroundColor',
  containerbackgroundopacity: 'containerBackgroundOpacity',
  containerclassname: 'containerClassName',
  basechartmessageimagehalign: 'baseChartMessageImageHAlign',
  basechartmessageimagevalign: 'baseChartMessageImageVAlign',
  basechartmessageimagealpha: 'baseChartMessageImageAlpha',
  basechartmessageimagescale: 'baseChartMessageImageScale',
  typenotsupportedmessageimagehalign: 'typeNotSupportedMessageImageHAlign',
  typenotsupportedmessageimagevalign: 'typeNotSupportedMessageImageVAlign',
  typenotsupportedmessageimagealpha: 'typeNotSupportedMessageImageAlpha',
  typenotsupportedmessageimagescale: 'typeNotSupportedMessageImageScale',
  dataloaderrormessageimagehalign: 'dataLoadErrorMessageImageHAlign',
  dataloaderrormessageimagevalign: 'dataLoadErrorMessageImageVAlign',
  dataloaderrormessageimagealpha: 'dataLoadErrorMessageImageAlpha',
  dataloaderrormessageimagescale: 'dataLoadErrorMessageImageScale',
  dataloadstartmessageimagehalign: 'dataLoadStartMessageImageHAlign',
  dataloadstartmessageimagevalign: 'dataLoadStartMessageImageVAlign',
  dataloadstartmessageimagealpha: 'dataLoadStartMessageImageAlpha',
  dataloadstartmessageimagescale: 'dataLoadStartMessageImageScale',
  datainvalidmessageimagehalign: 'dataInvalidMessageImageHAlign',
  datainvalidmessageimagevalign: 'dataInvalidMessageImageVAlign',
  datainvalidmessageimagealpha: 'dataInvalidMessageImageAlpha',
  datainvalidmessageimagescale: 'dataInvalidMessageImageScale',
  dataemptymessageimagehalign: 'dataEmptyMessageImageHAlign',
  dataemptymessageimagevalign: 'dataEmptyMessageImageVAlign',
  dataemptymessageimagealpha: 'dataEmptyMessageImageAlpha',
  dataemptymessageimagescale: 'dataEmptyMessageImageScale',
  rendererrormessageimagehalign: 'renderErrorMessageImageHAlign',
  rendererrormessageimagevalign: 'renderErrorMessageImageVAlign',
  rendererrormessageimagealpha: 'renderErrorMessageImageAlpha',
  rendererrormessageimagescale: 'renderErrorMessageImageScale',
  loadmessageimagehalign: 'loadMessageImageHAlign',
  loadmessageimagevalign: 'loadMessageImageVAlign',
  loadmessageimagealpha: 'loadMessageImageAlpha',
  loadmessageimagescale: 'loadMessageImageScale',
}

export const props = {
  options: Object,
  type: String,
  id: String,
  width: String,
  height: String,
  dataFormat: String,
  dataSource: Object,
  events: Object,
  link: Object,
  showDataLoadingMessage: Boolean,
  showChartLoadingMessage: Boolean,
  baseChartMessageFont: String,
  baseChartMessageFontSize: String,
  baseChartMessageColor: String,
  dataLoadStartMessage: String,
  dataLoadErrorMessage: String,
  dataInvalidMessage: String,
  dataEmptyMessage: String,
  typeNotSupportedMessage: String,
  loadMessage: String,
  renderErrorMessage: String,
  containerBackgroundColor: String,
  containerBackgroundOpacity: Number,
  containerClassName: String,
  baseChartMessageImageHAlign: String,
  baseChartMessageImageVAlign: String,
  baseChartMessageImageAlpha: Number,
  baseChartMessageImageScale: Number,
  typeNotSupportedMessageImageHAlign: String,
  typeNotSupportedMessageImageVAlign: String,
  typeNotSupportedMessageImageAlpha: Number,
  typeNotSupportedMessageImageScale: Number,
  dataLoadErrorMessageImageHAlign: String,
  dataLoadErrorMessageImageVAlign: String,
  dataLoadErrorMessageImageAlpha: Number,
  dataLoadErrorMessageImageScale: Number,
  dataLoadStartMessageImageHAlign: String,
  dataLoadStartMessageImageVAlign: String,
  dataLoadStartMessageImageAlpha: Number,
  dataLoadStartMessageImageScale: Number,
  dataInvalidMessageImageHAlign: String,
  dataInvalidMessageImageVAlign: String,
  dataInvalidMessageImageAlpha: Number,
  dataInvalidMessageImageScale: Number,
  dataEmptyMessageImageHAlign: String,
  dataEmptyMessageImageVAlign: String,
  dataEmptyMessageImageAlpha: Number,
  dataEmptyMessageImageScale: Number,
  renderErrorMessageImageHAlign: String,
  renderErrorMessageImageVAlign: String,
  renderErrorMessageImageAlpha: Number,
  renderErrorMessageImageScale: Number,
  loadMessageImageHAlign: String,
  loadMessageImageVAlign: String,
  loadMessageImageAlpha: Number,
  loadMessageImageScale: Number,
  /// ////////////////////////////////////////////
  dataformat: String,
  datasource: String,
  showdataloadingmessage: Boolean,
  showchartloadingmessage: Boolean,
  basechartmessagefont: String,
  basechartmessagefontsize: String,
  basechartmessagecolor: String,
  dataloadstartmessage: String,
  dataloaderrormessage: String,
  datainvalidmessage: String,
  dataemptymessage: String,
  typenotsupportedmessage: String,
  loadmessage: String,
  rendererrormessage: String,
  containerbackgroundcolor: String,
  containerbackgroundopacity: Number,
  containerclassname: String,
  basechartmessageimagehalign: String,
  basechartmessageimagevalign: String,
  basechartmessageimagealpha: Number,
  basechartmessageimagescale: Number,
  typenotsupportedmessageimagehalign: String,
  typenotsupportedmessageimagevalign: String,
  typenotsupportedmessageimagealpha: Number,
  typenotsupportedmessageimagescale: Number,
  dataloaderrormessageimagehalign: String,
  dataloaderrormessageimagevalign: String,
  dataloaderrormessageimagealpha: Number,
  dataloaderrormessageimagescale: Number,
  dataloadstartmessageimagehalign: String,
  dataloadstartmessageimagevalign: String,
  dataloadstartmessageimagealpha: Number,
  dataloadstartmessageimagescale: Number,
  datainvalidmessageimagehalign: String,
  datainvalidmessageimagevalign: String,
  datainvalidmessageimagealpha: Number,
  datainvalidmessageimagescale: Number,
  dataemptymessageimagehalign: String,
  dataemptymessageimagevalign: String,
  dataemptymessageimagealpha: Number,
  dataemptymessageimagescale: Number,
  rendererrormessageimagehalign: String,
  rendererrormessageimagevalign: String,
  rendererrormessageimagealpha: Number,
  rendererrormessageimagescale: Number,
  loadmessageimagehalign: String,
  loadmessageimagevalign: String,
  loadmessageimagealpha: Number,
  loadmessageimagescale: Number,
}

export const ZHCN_PROVINCE_SET = {
  BJ: '北京',
  GD: '广东',
  SD: '山东',
  JS: '江苏',
  HE: '河南',
  SH: '上海',
  HB: '河北',
  ZJ: '浙江',
  HK: '香港',
  SA: '陕西',
  HN: '湖南',
  CQ: '重庆',
  FJ: '福建',
  TJ: '天津',
  YN: '云南',
  SC: '四川',
  GX: '广西',
  AH: '安徽',
  HA: '海南',
  JX: '江西',
  HU: '湖北',
  SX: '山西',
  LN: '辽宁',
  TA: '台湾',
  HL: '黑龙',
  NM: '内蒙',
  MA: '澳门',
  GZ: '贵州',
  GS: '甘肃',
  QH: '青海',
  XJ: '新疆',
  XZ: '西藏',
  JL: '吉林',
  NX: '宁夏',
}

export const ZHCN_PROVINCE: SpecialValueMap<IFCMapProvinceConfig> = {
  TA: {
    label: '台湾省',
    id: 'taiwan',
    position: [0, 0],
    cities: {},
  },
  XZ: {
    label: '西藏藏族自治区',
    id: 'xizang',
    position: [0, 0],
    cities: {},
  },
  BJ: {
    label: '北京市',
    id: 'beijing',
    position: [635.1, 278.4],
    cities: {
      11: {
        label: '昌平区',
        posisiton: [186.5, 261.2],
      },
      3: {
        label: '朝阳区',
        posisiton: [274.1, 350.2],
      },
      12: {
        label: '大兴区',
        posisiton: [240.3, 450.4],
      },
      1: {
        label: '东城区',
        posisiton: [245, 360.9],
      },
      8: {
        label: '房山区',
        posisiton: [105.4, 424],
      },
      5: {
        label: '丰台区',
        posisiton: [208.9, 378.1],
      },
      4: {
        label: '海淀区',
        posisiton: [205.5, 326.8],
      },
      14: {
        label: '怀柔区',
        posisiton: [297.5, 130.9],
      },
      7: {
        label: '门头沟区',
        posisiton: [95.6, 331.7],
      },
      15: {
        label: '密云区',
        posisiton: [387.5, 175.5],
      },
      13: {
        label: '平谷区',
        posisiton: [429, 272.8],
      },
      6: {
        label: '石景山区',
        posisiton: [186.2, 355.2],
      },
      10: {
        label: '顺义区',
        posisiton: [323.3, 290.1],
      },
      9: {
        label: '通州区',
        posisiton: [325.1, 396],
      },
      2: {
        label: '西城区',
        posisiton: [232.4, 360.7],
      },
      16: {
        label: '延庆区',
        posisiton: [181.9, 172.9],
      },
    },
  },
  GD: {
    label: '广东省',
    id: 'guangdong',
    position: [602.1, 596.6],
    cities: {
      '0768': {
        label: '潮州市',
        posisiton: [469.8, 114.6],
      },
      '0769': {
        label: '东莞市',
        posisiton: [281, 180.8],
      },
      '0757': {
        label: '佛山市',
        posisiton: [224.1, 169.9],
      },
      '020': {
        label: '广州市',
        posisiton: [258.3, 156.5],
      },
      '0762': {
        label: '河源市',
        posisiton: [348.9, 106.6],
      },
      '0752': {
        label: '惠州市',
        posisiton: [317, 159.8],
      },
      '0750': {
        label: '江门市',
        posisiton: [205.1, 232.8],
      },
      '0663': {
        label: '揭阳市',
        posisiton: [429.3, 148.7],
      },
      '0668': {
        label: '茂名市',
        posisiton: [92, 241.5],
      },
      '0753': {
        label: '梅州市',
        posisiton: [427.1, 93.1],
      },
      '0763': {
        label: '清远市',
        posisiton: [218.1, 84],
      },
      '0754': {
        label: '汕头市',
        posisiton: [451.7, 149.5],
      },
      '0660': {
        label: '汕尾市',
        posisiton: [394.1, 169.1],
      },
      '0751': {
        label: '韶关市',
        posisiton: [276.8, 57.4],
      },
      '0755': {
        label: '深圳市',
        posisiton: [301.2, 201.1],
      },
      '0662': {
        label: '阳江市',
        posisiton: [144.6, 241.1],
      },
      '0766': {
        label: '云浮市',
        posisiton: [145, 185.6],
      },
      '0759': {
        label: '湛江市',
        posisiton: [35.7, 289.6],
      },
      '0758': {
        label: '肇庆市',
        posisiton: [166.9, 135.6],
      },
      '0760': {
        label: '中山市',
        posisiton: [247.2, 206.2],
      },
      '0756': {
        label: '珠海市',
        posisiton: [244.8, 231],
      },
    },
  },
  SD: {
    label: '山东省',
    id: 'shandong',
    position: [661.4, 353.6],
    cities: {
      3: {
        label: '滨州市',
        posisiton: [192.7, 47.2],
      },
      4: {
        label: '德州市',
        posisiton: [113.1, 80.5],
      },
      5: {
        label: '东营市',
        posisiton: [237.3, 56.1],
      },
      6: {
        label: '菏泽市',
        posisiton: [51.9, 237.5],
      },
      1: {
        label: '济南市',
        posisiton: [153.9, 114.1],
      },
      7: {
        label: '济宁市',
        posisiton: [111.5, 237.2],
      },
      8: {
        label: '莱芜市',
        posisiton: [181.7, 155.2],
      },
      9: {
        label: '聊城市',
        posisiton: [73.1, 143.6],
      },
      10: {
        label: '临沂市',
        posisiton: [221.6, 233.5],
      },
      2: {
        label: '青岛市',
        posisiton: [342.2, 125.5],
      },
      11: {
        label: '日照市',
        posisiton: [273.6, 207.7],
      },
      12: {
        label: '泰安市',
        posisiton: [142.2, 171.1],
      },
      13: {
        label: '潍坊市',
        posisiton: [271.3, 137.4],
      },
      14: {
        label: '威海市',
        posisiton: [456.8, 79.2],
      },
      15: {
        label: '烟台市',
        posisiton: [371.7, 68.3],
      },
      16: {
        label: '枣庄市',
        posisiton: [167.5, 263.3],
      },
      17: {
        label: '淄博市',
        posisiton: [199.9, 129.2],
      },
    },
  },
  JS: {
    label: '江苏省',
    id: 'jiangsu',
    position: [699, 408.2],
    cities: {
      2: {
        label: '常州市',
        posisiton: [309.6, 397.6],
      },
      3: {
        label: '淮安市',
        posisiton: [258.5, 168.8],
      },
      4: {
        label: '连云港市',
        posisiton: [257.4, 66.7],
      },
      1: {
        label: '南京市',
        posisiton: [225.6, 370],
      },
      5: {
        label: '南通市',
        posisiton: [446, 336.9],
      },
      6: {
        label: '宿迁市',
        posisiton: [204.9, 154.6],
      },
      7: {
        label: '苏州市',
        posisiton: [403.9, 430.6],
      },
      8: {
        label: '台州市',
        posisiton: [341.7, 248.9],
      },
      9: {
        label: '无锡市',
        posisiton: [371.9, 395.2],
      },
      10: {
        label: '徐州市',
        posisiton: [125.7, 97.5],
      },
      11: {
        label: '盐城市',
        posisiton: [362.2, 184.5],
      },
      12: {
        label: '扬州市',
        posisiton: [291.2, 266.3],
      },
      13: {
        label: '镇江市',
        posisiton: [291.4, 363.3],
      },
    },
  },
  HE: {
    label: '河南省',
    id: 'henan',
    position: [596.8, 400.9],
    cities: {
      2: {
        label: '安阳市',
        posisiton: [333.1, 30.7],
      },
      3: {
        label: '鹤壁市',
        posisiton: [325.2, 68.5],
      },
      4: {
        label: '焦作市',
        posisiton: [226.4, 124.5],
      },
      18: {
        label: '济源市',
        posisiton: [171.9, 130.6],
      },
      5: {
        label: '开封市',
        posisiton: [350.6, 179.5],
      },
      6: {
        label: '漯河市',
        posisiton: [293.2, 272.1],
      },
      7: {
        label: '洛阳市',
        posisiton: [141.8, 208.3],
      },
      8: {
        label: '南阳市',
        posisiton: [170.3, 339],
      },
      9: {
        label: '平顶山市',
        posisiton: [217, 254.7],
      },
      10: {
        label: '濮阳市',
        posisiton: [397.9, 60.7],
      },
      11: {
        label: '三门峡市',
        posisiton: [45.5, 208.7],
      },
      12: {
        label: '商丘市',
        posisiton: [447.3, 211.2],
      },
      13: {
        label: '新乡市',
        posisiton: [299.3, 103.6],
      },
      14: {
        label: '信阳市',
        posisiton: [372.4, 440.8],
      },
      15: {
        label: '许昌市',
        posisiton: [277.5, 237.1],
      },
      1: {
        label: '郑州市',
        posisiton: [259.7, 177.9],
      },
      16: {
        label: '周口市',
        posisiton: [375.5, 272.1],
      },
      17: {
        label: '驻马店市',
        posisiton: [316.4, 352.2],
      },
    },
  },
  SH: {
    label: '上海市',
    id: 'shanghai',
    position: [749.5, 421.4],
    cities: {
      10: {
        label: '宝山区',
        posisiton: [247.5, 258.6],
      },
      3: {
        label: '长宁区',
        posisiton: [240, 358.9],
      },
      17: {
        label: '崇明区',
        posisiton: [320.7, 131.4],
      },
      16: {
        label: '奉贤区',
        posisiton: [329.7, 527.9],
      },
      7: {
        label: '虹口区',
        posisiton: [286.1, 320],
      },
      1: {
        label: '黄浦区',
        posisiton: [290.7, 351.9],
      },
      12: {
        label: '嘉定区',
        posisiton: [170.9, 272.8],
      },
      4: {
        label: '静安区',
        posisiton: [270.1, 347.9],
      },
      13: {
        label: '金山区',
        posisiton: [164.4, 558.8],
      },
      11: {
        label: '闵行区',
        posisiton: [271.7, 441.6],
      },
      9: {
        label: '浦东区',
        posisiton: [386.7, 406.7],
      },
      5: {
        label: '普陀区',
        posisiton: [248.5, 337.3],
      },
      15: {
        label: '青浦区',
        posisiton: [135.4, 360.5],
      },
      14: {
        label: '松江区',
        posisiton: [158.9, 454.1],
      },
      2: {
        label: '徐汇区',
        posisiton: [266.7, 383.9],
      },
      8: {
        label: '杨浦区',
        posisiton: [309.5, 310.3],
      },
      6: {
        label: '闸北区',
        posisiton: [269.1, 319.9],
      },
    },
  },
  HB: {
    label: '河北省',
    id: 'hebei',
    position: [623, 307.5],
    cities: {
      2: {
        label: '保定市',
        posisiton: [127.9, 331.8],
      },
      3: {
        label: '沧州市',
        posisiton: [253.9, 413.5],
      },
      4: {
        label: '承德市',
        posisiton: [313.6, 115.4],
      },
      5: {
        label: '邯郸市',
        posisiton: [81.1, 573.8],
      },
      6: {
        label: '衡水市',
        posisiton: [189.4, 463.3],
      },
      7: {
        label: '廊坊市',
        posisiton: [237.3, 314.8],
      },
      8: {
        label: '秦皇岛市',
        posisiton: [433.7, 241.2],
      },
      1: {
        label: '石家庄市',
        posisiton: [85, 422.3],
      },
      9: {
        label: '唐山市',
        posisiton: [372.3, 270],
      },
      10: {
        label: '邢台市',
        posisiton: [106.6, 504],
      },
      11: {
        label: '张家口市',
        posisiton: [136.5, 166],
      },
    },
  },
  ZJ: {
    label: '浙江省',
    id: 'zhejiang',
    position: [709.7, 484.2],
    cities: {
      1: {
        label: '杭州市',
        posisiton: [117.7, 121.3],
      },
      3: {
        label: '湖州市',
        posisiton: [146.7, 38.6],
      },
      4: {
        label: '嘉兴市',
        posisiton: [216.8, 49.1],
      },
      5: {
        label: '金华市',
        posisiton: [155.1, 193.5],
      },
      6: {
        label: '丽水市',
        posisiton: [120.6, 278.8],
      },
      2: {
        label: '宁波市',
        posisiton: [259.1, 140.8],
      },
      7: {
        label: '衢州市',
        posisiton: [53.1, 213.9],
      },
      8: {
        label: '绍兴市',
        posisiton: [198.8, 136.6],
      },
      9: {
        label: '台州市',
        posisiton: [233.7, 219],
      },
      10: {
        label: '温州市',
        posisiton: [188.5, 311.5],
      },
      11: {
        label: '舟山市',
        posisiton: [316.3, 104.8],
      },
    },
  },
  HK: {
    label: '香港特别行政区',
    id: 'hongkong',
    position: [639.4, 623.4],
    cities: {
      'HK.CW': {
        label: '中西区',
        posisiton: [418.5, 409.9],
      },
      'HK.EA': {
        label: '东区',
        posisiton: [507.3, 417.1],
      },
      'HK.IS': {
        label: '离岛区',
        posisiton: [173.5, 425.4],
      },
      'HK.KC': {
        label: '九龙城区',
        posisiton: [461, 340.6],
      },
      'HK.KI': {
        label: '葵青区',
        posisiton: [395.2, 296.1],
      },
      'HK.KU': {
        label: '观塘区',
        posisiton: [512.1, 349.6],
      },
      'HK.NO': {
        label: '北区',
        posisiton: [433.7, 83.4],
      },
      'HK.SK': {
        label: '西贡区',
        posisiton: [538.1, 321.2],
      },
      'HK.ST': {
        label: '沙田区',
        posisiton: [460.1, 249],
      },
      'HK.SS': {
        label: '深水埗区',
        posisiton: [426.9, 323.1],
      },
      'HK.SO': {
        label: '南区',
        posisiton: [476.5, 446.4],
      },
      'HK.TP': {
        label: '大浦区',
        posisiton: [415.5, 168.8],
      },
      'HK.TW': {
        label: '荃湾区',
        posisiton: [355.6, 263.3],
      },
      'HK.TM': {
        label: '屯门区',
        posisiton: [233.1, 248],
      },
      'HK.WC': {
        label: '湾仔区',
        posisiton: [462.8, 417.7],
      },
      'HK.WT': {
        label: '黄大仙区',
        posisiton: [482.9, 313.9],
      },
      'HK.YT': {
        label: '油尖旺区',
        posisiton: [442.7, 362],
      },
      'HK.YL': {
        label: '元朗区',
        posisiton: [299.4, 173.4],
      },
    },
  },
  SA: {
    label: '陕西省',
    id: 'shaanxi',
    position: [517.3, 403.1],
    cities: {
      2: {
        label: '安康市',
        posisiton: [165.4, 416.9],
      },
      3: {
        label: '宝鸡市',
        posisiton: [89.1, 317.8],
      },
      4: {
        label: '汉中市',
        posisiton: [71.1, 389.4],
      },
      5: {
        label: '商洛市',
        posisiton: [214.3, 364.4],
      },
      6: {
        label: '铜川市',
        posisiton: [178, 267.5],
      },
      7: {
        label: '渭南市',
        posisiton: [214.9, 287.5],
      },
      1: {
        label: '西安市',
        posisiton: [162.9, 336.5],
      },
      8: {
        label: '咸阳市',
        posisiton: [144.8, 289.3],
      },
      9: {
        label: '延安市',
        posisiton: [200.6, 194.5],
      },
      10: {
        label: '榆林市',
        posisiton: [215.9, 86.3],
      },
    },
  },
  HN: {
    label: '湖南省',
    id: 'hunan',
    position: [567.5, 527.5],
    cities: {
      14: {
        label: '湘西土家族苗族自治州',
        posisiton: [87.9, 134],
      },
      2: {
        label: '常德市',
        posisiton: [245.8, 88.1],
      },
      1: {
        label: '长沙市',
        posisiton: [360.8, 171.4],
      },
      3: {
        label: '郴州市',
        posisiton: [375.5, 389.6],
      },
      4: {
        label: '衡阳市',
        posisiton: [330.3, 303.5],
      },
      5: {
        label: '怀化市',
        posisiton: [100.7, 245.9],
      },
      6: {
        label: '娄底市',
        posisiton: [243.1, 220.4],
      },
      7: {
        label: '邵阳市',
        posisiton: [169.9, 282.8],
      },
      8: {
        label: '湘潭市',
        posisiton: [318.6, 219.3],
      },
      9: {
        label: '益阳市',
        posisiton: [256.9, 158.9],
      },
      10: {
        label: '永州市',
        posisiton: [246.6, 399.9],
      },
      11: {
        label: '岳阳市',
        posisiton: [375, 89.8],
      },
      12: {
        label: '张家界市',
        posisiton: [149.6, 74.8],
      },
      13: {
        label: '株洲市',
        posisiton: [401.8, 281.4],
      },
    },
  },
  CQ: {
    label: '重庆市',
    id: 'chongqing',
    position: [503.2, 479.6],
    cities: {
      7: {
        label: '巴南区',
        posisiton: [183.3, 411],
      },
      8: {
        label: '北碚区',
        posisiton: [151.1, 341.9],
      },
      10: {
        label: '璧山区',
        posisiton: [110, 375.5],
      },
      11: {
        label: '长寿区',
        posisiton: [237.7, 320.6],
      },
      28: {
        label: '城口县',
        posisiton: [424.4, 45.8],
      },
      2: {
        label: '大渡口区',
        posisiton: [147.5, 403.6],
      },
      17: {
        label: '大足区',
        posisiton: [59.5, 364],
      },
      24: {
        label: '垫江县',
        posisiton: [273.3, 284.7],
      },
      25: {
        label: '丰都县',
        posisiton: [319.3, 333.7],
      },
      29: {
        label: '奉节县',
        posisiton: [512.1, 188.5],
      },
      22: {
        label: '涪陵区',
        posisiton: [257.7, 365.6],
      },
      12: {
        label: '合川区',
        posisiton: [132.9, 307.6],
      },
      3: {
        label: '江北区',
        posisiton: [177.2, 376.6],
      },
      13: {
        label: '江津区',
        posisiton: [115.9, 447],
      },
      5: {
        label: '九龙坡区',
        posisiton: [131.1, 404.3],
      },
      30: {
        label: '开州区',
        posisiton: [386.5, 141.6],
      },
      31: {
        label: '梁平县',
        posisiton: [311.3, 226.2],
      },
      6: {
        label: '南岸区',
        posisiton: [168.9, 385.5],
      },
      23: {
        label: '南川区',
        posisiton: [236.5, 440.8],
      },
      37: {
        label: '彭水县',
        posisiton: [375.7, 406.4],
      },
      36: {
        label: '黔江区',
        posisiton: [170.1, 485.2],
      },
      18: {
        label: '綦江区',
        posisiton: [429.7, 397.7],
      },
      19: {
        label: '荣昌区',
        posisiton: [24.9, 387],
      },
      4: {
        label: '沙坪坝区',
        posisiton: [135.4, 374.9],
      },
      38: {
        label: '石柱土家族自治县',
        posisiton: [377, 308.2],
      },
      14: {
        label: '双桥区',
        posisiton: [59.9, 390.3],
      },
      20: {
        label: '铜梁区',
        posisiton: [92.5, 335.8],
      },
      21: {
        label: '潼南区',
        posisiton: [66.1, 292.4],
      },
      15: {
        label: '万盛区',
        posisiton: [207.7, 472.3],
      },
      27: {
        label: '万州区',
        posisiton: [391, 219.8],
      },
      26: {
        label: '武隆县',
        posisiton: [298.9, 410.6],
      },
      32: {
        label: '巫山县',
        posisiton: [578.7, 162.1],
      },
      33: {
        label: '巫溪县',
        posisiton: [505.2, 109.8],
      },
      39: {
        label: '秀山土家族苗族自治县',
        posisiton: [466.7, 538.4],
      },
      16: {
        label: '永川区',
        posisiton: [70.9, 422.1],
      },
      40: {
        label: '有氧土家族苗族自治县',
        posisiton: [441.7, 481.5],
      },
      9: {
        label: '渝北区',
        posisiton: [189.6, 341.1],
      },
      34: {
        label: '云阳县',
        posisiton: [444.9, 176.9],
      },
      1: {
        label: '渝中区',
        posisiton: [156.6, 384.9],
      },
      35: {
        label: '忠县',
        posisiton: [328.4, 275],
      },
    },
  },
  FJ: {
    label: '福建省',
    id: 'fujian',
    position: [677.3, 544.6],
    cities: {
      1: {
        label: '福州市',
        posisiton: [322.7, 243.7],
      },
      3: {
        label: '龙岩市',
        posisiton: [94.3, 326.9],
      },
      4: {
        label: '南平市',
        posisiton: [224, 108.7],
      },
      5: {
        label: '宁德市',
        posisiton: [353.1, 139.2],
      },
      6: {
        label: '莆田市',
        posisiton: [292.6, 298.1],
      },
      7: {
        label: '泉州市',
        posisiton: [240.1, 325.3],
      },
      8: {
        label: '三明市',
        posisiton: [167.2, 209.5],
      },
      2: {
        label: '厦门市',
        posisiton: [220.6, 372.6],
      },
      9: {
        label: '漳州市',
        posisiton: [164.2, 412.1],
      },
    },
  },
  TJ: {
    label: '天津市',
    id: 'tianjin',
    position: [681, 307.4],
    cities: {
      12: {
        label: '宝坻区',
        posisiton: [205.1, 239.9],
      },
      11: {
        label: '北辰区',
        posisiton: [134.3, 359.5],
      },
      7: {
        label: '滨海区',
        posisiton: [267.4, 455],
      },
      9: {
        label: '东丽区',
        posisiton: [197.1, 405.9],
      },
      3: {
        label: '河北区',
        posisiton: [146.2, 390.6],
      },
      5: {
        label: '河东区',
        posisiton: [154.9, 407.1],
      },
      1: {
        label: '和平区',
        posisiton: [140.3, 407.8],
      },
      2: {
        label: '河西区',
        posisiton: [147.5, 420.7],
      },
      6: {
        label: '红桥区',
        posisiton: [127.8, 391.3],
      },
      14: {
        label: '蓟州区',
        posisiton: [195.4, 91.8],
      },
      15: {
        label: '静海区',
        posisiton: [80.3, 498.9],
      },
      8: {
        label: '津南区',
        posisiton: [194.8, 464],
      },
      4: {
        label: '南开区',
        posisiton: [128.5, 412],
      },
      16: {
        label: '宁河区',
        posisiton: [268.7, 312.5],
      },
      13: {
        label: '武清区',
        posisiton: [102, 290.8],
      },
      10: {
        label: '西青区',
        posisiton: [116.9, 437.9],
      },
    },
  },
  YN: {
    label: '云南省',
    id: 'yunnan',
    position: [397.4, 573],
    cities: {
      4: {
        label: '保山市',
        posisiton: [67.1, 197.5],
      },
      13: {
        label: '楚雄彝族自治州',
        posisiton: [173.8, 182.2],
      },
      12: {
        label: '大理白族自治州',
        posisiton: [106.5, 163.1],
      },
      9: {
        label: '德宏傣族景颇族自治州',
        posisiton: [28.7, 214],
      },
      11: {
        label: '迪庆藏族自治州',
        posisiton: [88.8, 64.7],
      },
      14: {
        label: '红河哈尼族彝族自治州',
        posisiton: [233.1, 275.5],
      },
      1: {
        label: '昆明市',
        posisiton: [227.1, 177.9],
      },
      6: {
        label: '丽江市',
        posisiton: [135.6, 109.6],
      },
      8: {
        label: '临沧市',
        posisiton: [90.4, 253.4],
      },
      10: {
        label: '怒江傈僳族自治州',
        posisiton: [72.5, 122.7],
      },
      7: {
        label: '普洱市',
        posisiton: [136.2, 286.2],
      },
      2: {
        label: '曲靖市',
        posisiton: [266.5, 167.4],
      },
      15: {
        label: '文山壮族苗族自治州',
        posisiton: [308.3, 258.2],
      },
      16: {
        label: '西双版纳傣族自治州',
        posisiton: [141.7, 336.8],
      },
      3: {
        label: '玉溪市',
        posisiton: [190.4, 240.5],
      },
      5: {
        label: '昭通市',
        posisiton: [270.8, 69.1],
      },
    },
  },
  SC: {
    label: '四川省',
    id: 'sichuan',
    position: [421, 460.1],
    cities: {
      6: {
        label: '巴中市',
        posisiton: [358, 127.8],
      },
      9: {
        label: '成都市',
        posisiton: [234.3, 176.2],
      },
      7: {
        label: '达州市',
        posisiton: [375.2, 159.2],
      },
      10: {
        label: '德阳市',
        posisiton: [260.4, 162.4],
      },
      1: {
        label: '甘孜藏族自治州',
        posisiton: [94.5, 147],
      },
      12: {
        label: '广安市',
        posisiton: [338.2, 194.4],
      },
      4: {
        label: '广元市',
        posisiton: [314.4, 114.2],
      },
      15: {
        label: '乐山市',
        posisiton: [222.6, 247.4],
      },
      20: {
        label: '凉山黎族自治州',
        posisiton: [156.6, 302.2],
      },
      19: {
        label: '泸州市',
        posisiton: [298.2, 306.2],
      },
      13: {
        label: '眉山市',
        posisiton: [234.5, 207.8],
      },
      3: {
        label: '绵阳市',
        posisiton: [267.7, 127.4],
      },
      5: {
        label: '南充市',
        posisiton: [324.6, 164.1],
      },
      16: {
        label: '内江市',
        posisiton: [271, 228.5],
      },
      2: {
        label: '阿坝藏族羌族自治州',
        posisiton: [189, 96.1],
      },
      21: {
        label: '攀枝花市',
        posisiton: [140.1, 352.8],
      },
      11: {
        label: '遂宁市',
        posisiton: [297.3, 189.1],
      },
      8: {
        label: '雅安市',
        posisiton: [188.6, 212.6],
      },
      18: {
        label: '宜宾市',
        posisiton: [262.7, 277.4],
      },
      17: {
        label: '自贡市',
        posisiton: [262.1, 245.3],
      },
      14: {
        label: '资阳市',
        posisiton: [276.1, 206.5],
      },
    },
  },
  GX: {
    label: '广西省',
    id: 'guangxi',
    position: [526.8, 594.2],
    cities: {
      1: {
        label: '百色市',
        posisiton: [188.3, 247.6],
      },
      13: {
        label: '北海市',
        posisiton: [449.9, 484.5],
      },
      6: {
        label: '崇左市',
        posisiton: [264.3, 402.1],
      },
      11: {
        label: '防城港市',
        posisiton: [321.6, 457.4],
      },
      9: {
        label: '贵港市',
        posisiton: [505.5, 320.9],
      },
      4: {
        label: '桂林市',
        posisiton: [553.1, 111.2],
      },
      2: {
        label: '河池市',
        posisiton: [313.6, 187],
      },
      5: {
        label: '贺州市',
        posisiton: [641, 203.8],
      },
      8: {
        label: '来宾市',
        posisiton: [458.3, 275.7],
      },
      3: {
        label: '柳州市',
        posisiton: [454.3, 147.8],
      },
      7: {
        label: '南宁市',
        posisiton: [370.4, 335.9],
      },
      12: {
        label: '钦州市',
        posisiton: [422.4, 436.3],
      },
      10: {
        label: '梧州市',
        posisiton: [604.8, 307.4],
      },
      14: {
        label: '玉林市',
        posisiton: [533.6, 401.1],
      },
    },
  },
  AH: {
    label: '安徽省',
    id: 'anhui',
    position: [659.4, 434.3],
    cities: {
      2: {
        label: '安庆市',
        posisiton: [138.7, 384.6],
      },
      3: {
        label: '蚌埠市',
        posisiton: [213.1, 152.9],
      },
      4: {
        label: '亳州市',
        posisiton: [112.9, 117.4],
      },
      5: {
        label: '巢湖市',
        posisiton: [244.9, 307.8],
      },
      6: {
        label: '池州市',
        posisiton: [210.9, 435.8],
      },
      7: {
        label: '滁州市',
        posisiton: [254.8, 204],
      },
      8: {
        label: '阜阳市',
        posisiton: [61.8, 171.2],
      },
      1: {
        label: '合肥市',
        posisiton: [203, 257.5],
      },
      9: {
        label: '淮北市',
        posisiton: [156.7, 89.6],
      },
      10: {
        label: '淮南市',
        posisiton: [160.8, 186.1],
      },
      11: {
        label: '黄山市',
        posisiton: [267.6, 459.4],
      },
      12: {
        label: '六安市',
        posisiton: [119.6, 278.2],
      },
      13: {
        label: '马鞍山市',
        posisiton: [316.5, 303.6],
      },
      14: {
        label: '宿州市',
        posisiton: [207.8, 89.4],
      },
      15: {
        label: '铜陵市',
        posisiton: [257.5, 362.9],
      },
      16: {
        label: '芜湖市',
        posisiton: [293.7, 350],
      },
      17: {
        label: '宣城市',
        posisiton: [331.1, 392.3],
      },
    },
  },
  HA: {
    label: '海南省',
    id: 'hainan',
    position: [537.6, 686.8],
    cities: {
      14: {
        label: '白沙黎族自治县',
        posisiton: [197.6, 258.5],
      },
      17: {
        label: '保亭黎族苗族自治县',
        posisiton: [261.1, 421.9],
      },
      13: {
        label: '昌江黎族自治县',
        posisiton: [77.4, 219],
      },
      10: {
        label: '澄迈县',
        posisiton: [356.9, 129.5],
      },
      8: {
        label: '儋州市',
        posisiton: [193.4, 168.8],
      },
      11: {
        label: '定安县',
        posisiton: [444.7, 189.5],
      },
      7: {
        label: '东方市',
        posisiton: [68.6, 310.9],
      },
      1: {
        label: '海口市',
        posisiton: [467.5, 100.1],
      },
      18: {
        label: '乐东黎族自治县',
        posisiton: [110.9, 404.3],
      },
      9: {
        label: '临高县',
        posisiton: [273.2, 103.3],
      },
      16: {
        label: '陵水黎族自治县',
        posisiton: [350.7, 427.2],
      },
      4: {
        label: '琼海市',
        posisiton: [463.6, 258.5],
      },
      15: {
        label: '琼中黎族苗族自治县',
        posisiton: [318.6, 298.3],
      },
      2: {
        label: '三亚市',
        posisiton: [200.6, 479.9],
      },
      12: {
        label: '屯昌县',
        posisiton: [365.3, 219.9],
      },
      5: {
        label: '万宁市',
        posisiton: [436.1, 357.7],
      },
      3: {
        label: '文昌市',
        posisiton: [553.4, 112.3],
      },
      6: {
        label: '五指山市',
        posisiton: [240.2, 360.9],
      },
    },
  },
  JX: {
    label: '江西省',
    id: 'jiangxi',
    position: [633.1, 526.3],
    cities: {
      2: {
        label: '抚州市',
        posisiton: [240.1, 240.4],
      },
      3: {
        label: '赣州市',
        posisiton: [142.2, 389.7],
      },
      4: {
        label: '吉安市',
        posisiton: [109.3, 284.4],
      },
      5: {
        label: '景德镇市',
        posisiton: [312.2, 53.8],
      },
      6: {
        label: '九江市',
        posisiton: [154.9, 64.4],
      },
      1: {
        label: '南昌市',
        posisiton: [203, 131.2],
      },
      7: {
        label: '萍乡市',
        posisiton: [30.5, 228.8],
      },
      8: {
        label: '上饶市',
        posisiton: [351.1, 134.9],
      },
      9: {
        label: '新余市',
        posisiton: [102.3, 208],
      },
      10: {
        label: '宜春市',
        posisiton: [122, 160.9],
      },
      11: {
        label: '鹰潭市',
        posisiton: [291, 170],
      },
    },
  },
  HU: {
    label: '湖北省',
    id: 'hubei',
    position: [578.9, 453.7],
    cities: {
      13: {
        label: '恩施土家族苗族自治州',
        posisiton: [104, 318.8],
      },
      2: {
        label: '鄂州市',
        posisiton: [582.4, 304.6],
      },
      3: {
        label: '黄冈市',
        posisiton: [626.3, 273.1],
      },
      4: {
        label: '黄石市',
        posisiton: [605.4, 352],
      },
      5: {
        label: '荆门市',
        posisiton: [377.3, 230.3],
      },
      6: {
        label: '荆州市',
        posisiton: [373.8, 351.9],
      },
      15: {
        label: '潜江市',
        posisiton: [401.7, 311.9],
      },
      17: {
        label: '神农架市',
        posisiton: [191.1, 183.1],
      },
      7: {
        label: '十堰市',
        posisiton: [195.6, 96],
      },
      8: {
        label: '随州市',
        posisiton: [459.3, 151],
      },
      14: {
        label: '天门市',
        posisiton: [426, 279.4],
      },
      1: {
        label: '武汉市',
        posisiton: [544.9, 276.3],
      },
      9: {
        label: '襄樊市',
        posisiton: [325.1, 146.4],
      },
      10: {
        label: '咸宁市',
        posisiton: [537.1, 380.3],
      },
      16: {
        label: '仙桃市',
        posisiton: [457.5, 315.4],
      },
      11: {
        label: '孝感市',
        posisiton: [506.2, 230.3],
      },
      12: {
        label: '宜昌市',
        posisiton: [253.4, 267.5],
      },
    },
  },
  SX: {
    label: '山西省',
    id: 'shanxi',
    position: [576.6, 329.9],
    cities: {
      2: {
        label: '长治市',
        posisiton: [156.5, 294.8],
      },
      3: {
        label: '大同市',
        posisiton: [188.4, 59.6],
      },
      4: {
        label: '晋城市',
        posisiton: [145.9, 353.3],
      },
      5: {
        label: '晋中市',
        posisiton: [159.4, 234],
      },
      6: {
        label: '临汾市',
        posisiton: [72.5, 317.9],
      },
      7: {
        label: '吕梁市',
        posisiton: [55.1, 209.9],
      },
      8: {
        label: '朔州市',
        posisiton: [129.1, 85.1],
      },
      1: {
        label: '太原市',
        posisiton: [116.4, 197.1],
      },
      9: {
        label: '忻州市',
        posisiton: [122.7, 139.3],
      },
      10: {
        label: '阳泉市',
        posisiton: [179.9, 182.9],
      },
      11: {
        label: '运城市',
        posisiton: [55.5, 385.8],
      },
    },
  },
  LN: {
    label: '辽宁省',
    id: 'liaoning',
    position: [733.3, 239.5],
    cities: {
      3: {
        label: '鞍山市',
        posisiton: [255, 234.8],
      },
      4: {
        label: '本溪市',
        posisiton: [321.7, 197.5],
      },
      5: {
        label: '朝阳市',
        posisiton: [81.3, 178.2],
      },
      2: {
        label: '大连市',
        posisiton: [221.5, 328.3],
      },
      6: {
        label: '丹东市',
        posisiton: [348.5, 260.2],
      },
      7: {
        label: '抚顺市',
        posisiton: [365.9, 149.1],
      },
      8: {
        label: '阜新市',
        posisiton: [204.7, 108],
      },
      9: {
        label: '葫芦岛市',
        posisiton: [84.1, 248.7],
      },
      10: {
        label: '锦州市',
        posisiton: [181.5, 169.6],
      },
      11: {
        label: '辽阳市',
        posisiton: [274.4, 186.1],
      },
      12: {
        label: '盘锦市',
        posisiton: [204.2, 204.5],
      },
      1: {
        label: '沈阳市',
        posisiton: [273.5, 121.9],
      },
      13: {
        label: '铁岭市',
        posisiton: [334.7, 66.8],
      },
      14: {
        label: '营口市',
        posisiton: [234.3, 273.6],
      },
    },
  },
  HL: {
    label: '黑龙江省',
    id: 'heilongjiang',
    position: [782.2, 129.4],
    cities: {
      2: {
        label: '大庆市',
        posisiton: [92.3, 354.1],
      },
      13: {
        label: '大兴安岭市',
        posisiton: [91, 71.5],
      },
      1: {
        label: '哈尔滨市',
        posisiton: [208.9, 410],
      },
      3: {
        label: '鹤岗市',
        posisiton: [290.4, 284.9],
      },
      4: {
        label: '黑河市',
        posisiton: [181.8, 217],
      },
      5: {
        label: '佳木斯市',
        posisiton: [353.1, 315.3],
      },
      6: {
        label: '鸡西市',
        posisiton: [355.1, 398.6],
      },
      7: {
        label: '牡丹江市',
        posisiton: [274, 440],
      },
      8: {
        label: '齐齐哈尔市',
        posisiton: [94, 287.3],
      },
      9: {
        label: '七台河市',
        posisiton: [314.5, 382.8],
      },
      10: {
        label: '双鸭山市',
        posisiton: [349.2, 355.3],
      },
      11: {
        label: '绥化市',
        posisiton: [168.4, 328.2],
      },
      12: {
        label: '伊春市',
        posisiton: [251.7, 283.5],
      },
    },
  },
  NM: {
    label: '内蒙古自治区',
    id: 'neimongol',
    position: [553.2, 264.6],
    cities: {
      1: {
        label: '阿拉善盟',
        posisiton: [86.5, 273.2],
      },
      5: {
        label: '包头市',
        posisiton: [238.1, 274.8],
      },
      2: {
        label: '巴彦淖尔市',
        posisiton: [186.8, 273.7],
      },
      9: {
        label: '赤峰市',
        posisiton: [407.9, 262.4],
      },
      11: {
        label: '兴安盟',
        posisiton: [451.1, 194.8],
      },
      6: {
        label: '呼和浩特市',
        posisiton: [257.4, 315.6],
      },
      12: {
        label: '呼伦贝尔市',
        posisiton: [459, 104.5],
      },
      4: {
        label: '鄂尔多斯市',
        posisiton: [204.9, 328.9],
      },
      10: {
        label: '通辽市',
        posisiton: [465.2, 264.1],
      },
      7: {
        label: '乌兰察布市',
        posisiton: [286, 296],
      },
      3: {
        label: '乌海市',
        posisiton: [149.5, 364.2],
      },
      8: {
        label: '锡林郭勒盟',
        posisiton: [340.3, 234.7],
      },
    },
  },
  MA: {
    label: '澳门特别行政区',
    id: 'macau',
    position: [606.9, 652.2],
    cities: {
      'MO.IL.CO': {
        label: '圣方济各堂区',
        posisiton: [249, 638.2],
      },
      'MO.IL.CT': {
        label: '路氹城区',
        posisiton: [196.2, 531.4],
      },
      'MO.MA.NF': {
        label: '花地码堂区',
        posisiton: [148.9, 67.7],
      },
      'MO.MA.SA': {
        label: '圣安多尼堂区',
        posisiton: [98.3, 124.4],
      },
      'MO.MA.SC': {
        label: '圣老楞佐堂区',
        posisiton: [49.3, 210.3],
      },
      'MO.MA.SZ': {
        label: '望德堂区',
        posisiton: [147.1, 144.4],
      },
      'MO.MA.SE': {
        label: '大堂区',
        posisiton: [140.2, 201.7],
      },
      'MO.IL.TA': {
        label: '嘉模堂区',
        posisiton: [202.1, 419.1],
      },
    },
  },
  GZ: {
    label: '贵州省',
    id: 'guizhou',
    position: [482.2, 535.7],
    cities: {
      5: {
        label: '安顺市',
        posisiton: [227.8, 359.8],
      },
      1: {
        label: '毕节市',
        posisiton: [155.3, 238.5],
      },
      6: {
        label: '贵阳市',
        posisiton: [305.7, 269.7],
      },
      4: {
        label: '六盘水市',
        posisiton: [137.6, 309.8],
      },
      9: {
        label: '黔东南苗族侗族自治州',
        posisiton: [475.9, 307.8],
      },
      8: {
        label: '黔南布依族苗族自治州',
        posisiton: [360.3, 360.6],
      },
      7: {
        label: '黔西南布依族苗族自治州',
        posisiton: [190.2, 421.3],
      },
      3: {
        label: '铜仁市',
        posisiton: [491, 122.2],
      },
      2: {
        label: '遵义市',
        posisiton: [324.9, 116.1],
      },
    },
  },
  GS: {
    label: '甘肃省',
    id: 'gansu',
    position: [346.2, 270.5],
    cities: {
      0: {
        label: '全省',
        posisiton: [485.4, 52.4],
      },
      943: {
        label: '白银市',
        posisiton: [506.4, 284.9],
      },
      932: {
        label: '定西市',
        posisiton: [511.7, 369.5],
      },
      941: {
        label: '甘南藏族自治州',
        posisiton: [453.6, 402.1],
      },
      947: {
        label: '嘉峪关市',
        posisiton: [221.7, 159.3],
      },
      945: {
        label: '金昌市',
        posisiton: [387.5, 210.2],
      },
      937: {
        label: '酒泉市',
        posisiton: [142.4, 128],
      },
      931: {
        label: '兰州市',
        posisiton: [471.4, 307.1],
      },
      930: {
        label: '临夏回族自治州',
        posisiton: [461, 353],
      },
      939: {
        label: '陇南市',
        posisiton: [563, 447.5],
      },
      933: {
        label: '平凉市',
        posisiton: [628.8, 341.7],
      },
      934: {
        label: '庆阳市',
        posisiton: [644.3, 290.3],
      },
      938: {
        label: '天水市',
        posisiton: [575.9, 383.7],
      },
      935: {
        label: '武威市',
        posisiton: [429.1, 234.5],
      },
      936: {
        label: '张掖市',
        posisiton: [310.8, 198.3],
      },
    },
  },
  QH: {
    label: '青海省',
    id: 'qinghai',
    position: [329.2, 356.5],
    cities: {
      8: {
        label: '格尔木市',
        posisiton: [268.5, 195.4],
      },
      2: {
        label: '海北藏族自治州',
        posisiton: [305.2, 75.1],
      },
      4: {
        label: '海东市',
        posisiton: [351.3, 126],
      },
      5: {
        label: '海南藏族自治州',
        posisiton: [296.2, 135.7],
      },
      1: {
        label: '海西蒙古族藏族自治州',
        posisiton: [165.4, 74.4],
      },
      6: {
        label: '黄南藏族自治州',
        posisiton: [322.6, 177.1],
      },
      3: {
        label: '西宁市',
        posisiton: [327.5, 113.7],
      },
      7: {
        label: '玉树市',
        posisiton: [145.8, 176.6],
      },
    },
  },
  XJ: {
    label: '新疆维吾尔自治区',
    id: 'xinjiang',
    position: [181.5, 204.8],
    cities: {
      15: {
        label: '阿克苏地区',
        posisiton: [193.5, 212.4],
      },
      1: {
        label: '阿勒泰市',
        posisiton: [397.4, 76.7],
      },
      16: {
        label: '阿拉尔市',
        posisiton: [193.9, 241],
      },
      18: {
        label: '巴音郭楞蒙古自治州',
        posisiton: [331.7, 307.3],
      },
      2: {
        label: '博尔塔拉蒙古自治州',
        posisiton: [253.5, 121.1],
      },
      6: {
        label: '昌吉回族自治州',
        posisiton: [409.4, 170.4],
      },
      10: {
        label: '哈密市',
        posisiton: [489.8, 224],
      },
      17: {
        label: '和田市',
        posisiton: [151.7, 343.9],
      },
      11: {
        label: '伊犁哈萨克自治州',
        posisiton: [229.2, 154.9],
      },
      4: {
        label: '克拉玛依市',
        posisiton: [315.8, 111.6],
      },
      13: {
        label: '喀什地区',
        posisiton: [80.5, 285],
      },
      12: {
        label: '克孜勒苏柯尔克孜自治州',
        posisiton: [30.8, 242.7],
      },
      5: {
        label: '石河子市',
        posisiton: [330, 152.7],
      },
      3: {
        label: '塔城地区',
        posisiton: [294, 85.9],
      },
      14: {
        label: '图木舒克市',
        posisiton: [193.5, 212.4],
      },
      9: {
        label: '吐鲁番市',
        posisiton: [398.6, 232.2],
      },
      7: {
        label: '五家渠市',
        posisiton: [364.1, 157.2],
      },
      8: {
        label: '乌鲁木齐市',
        posisiton: [359.7, 180.8],
      },
    },
  },
  JL: {
    label: '吉林省',
    id: 'jilin',
    position: [763.2, 197.8],
    cities: {
      2: {
        label: '白城市',
        posisiton: [64.3, 71.1],
      },
      3: {
        label: '白山市',
        posisiton: [264.3, 285.4],
      },
      1: {
        label: '长春市',
        posisiton: [179.7, 143.3],
      },
      4: {
        label: '吉林市',
        posisiton: [243.7, 185.9],
      },
      5: {
        label: '辽源市',
        posisiton: [171.3, 243.6],
      },
      6: {
        label: '四平市',
        posisiton: [134.8, 191.4],
      },
      7: {
        label: '松原市',
        posisiton: [121.9, 105.9],
      },
      8: {
        label: '通化市',
        posisiton: [193.6, 299.9],
      },
      9: {
        label: '延边朝鲜族自治州',
        posisiton: [368.6, 208.5],
      },
    },
  },
  NX: {
    label: '宁夏回族自治区',
    id: 'ningxiahui',
    position: [480.2, 336.4],
    cities: {
      5: {
        label: '固原市',
        posisiton: [174.9, 399],
      },
      2: {
        label: '石嘴山市',
        posisiton: [219.2, 45.7],
      },
      3: {
        label: '吴忠市',
        posisiton: [227.5, 235.3],
      },
      1: {
        label: '银川市',
        posisiton: [203.6, 140.9],
      },
      4: {
        label: '中卫市',
        posisiton: [116.7, 281.5],
      },
    },
  },
}
