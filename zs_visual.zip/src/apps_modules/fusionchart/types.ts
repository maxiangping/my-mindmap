/** @format */

import { ChartObject } from 'fusioncharts'

/**
 * # FusionCharts XT
 * ## Single Series Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum SINGLE_SERIES_CHARTS {
  COLUMN_2D = 'column2d',
  COLUMN_3D = 'column3d',
  LINE_BREAKPOINT_2D = 'line', // 折点曲线
  LINE_2D = 'spline', // 平滑曲线
  AREA_2D = 'area2d',
  BAR_2D = 'bar2d',
  BAR_3D = 'bar3d',
  PIE_2D = 'pie2d',
  PIE_3D = 'pie3d',
  DOUGHNUT_2D = 'doughnut2d',
  DOUGHNUT_3D = 'doughnut3d',
  PARETO_2D = 'pareto2d',
  PARETO_3D = 'pareto3d',
}

/**
 * # FusionCharts XT
 * ## Multi-series Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum MULTI_SERIES_CHARTS {
  MULTI_SERIES_COLUMN_2D = 'mscolumn2d',
  MULTI_SERIES_COLUMN_3D = 'mscolumn3d',
  MULTI_SERIES_LINE_2D = 'msline',
  MULTI_SERIES_BAR_2D = 'msbar2d',
  MULTI_SERIES_BAR_3D = 'msbar3d',
  OVERLAPPED_COLUMN_2D = 'overlappedcolumn2d',
  OVERLAPPED_BAR_2D = 'overlappedbar2d',
  MULTI_SERIES_AREA_2D = 'msarea',
  MARIMEKKO = 'marimekko',
  ZOOM_LINE = 'zoomline',
  ZOOM_LINE_DY = 'zoomlinedy',
}

/**
 * # FusionCharts XT
 * ## Stacked Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum STACKED_CHARTS {
  STACKED_COLUMN_2D = 'stackedcolumn2d',
  STACKED_COLUMN_3D = 'stackedcolumn3d',
  STACKED_BAR_2D = 'stackedbar2d',
  STACKED_BAR_3D = 'stackedbar3d',
  STACKED_AREA_2D = 'stackedarea2d',
  MULTI_SERIES_STACKED_COLUMN_2D = 'msstackedcolumn2d',
}

/**
 * # FusionCharts XT
 * ## Combination Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum COMBINATION_CHARTS {
  MULTI_SERIES_2D_SINGLE_Y_COMBINATION_CHART_COLUMN_AND_LINE_AND_AREA = 'mscombi2d',
  MULTI_SERIES_3D_SINGLE_Y_COMBINATION_CHART_COLUMN_AND_LINE_AND_AREA = 'mscombi3d',
  MULTI_SERIES_COLUMN_3D_AND_LINE___SINGLE_Y_AXIS = 'mscolumnline3d',
  STACKED_COLUMN2D_AND_LINE_SINGLE_Y_AXIS = 'stackedcolumn2dline',
  STACKED_COLUMN3D_AND_LINE_SINGLE_Y_AXIS = 'stackedcolumn3dline',
  MULTI_SERIES_2D_DUAL_Y_COMBINATION_CHART_COLUMN_AND_LINE_AND_AREA = 'mscombidy2d',
  MULTI_SERIES_COLUMN_3D_AND_LINE___DUAL_Y_AXIS = 'mscolumn3dlinedy',
  STACKED_COLUMN_3D_AND_LINE_DUAL_Y_AXIS = 'stackedcolumn3dlinedy',
  MULTI_SERIES_STACKED_COLUMN_2D_AND_LINE_DUAL_Y_AXIS = 'msstackedcolumn2dlinedy',
}

/**
 * # FusionCharts XT
 * ## XY Plot Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum XY_PLOT_CHARTS {
  SCATTER_CHART = 'scatter',
  ZOOM_SCATTER_CHART = 'zoomscatter',
  BUBBLE_CHART = 'bubble',
}

/**
 * # FusionCharts XT
 * ## Scroll Charts
 *
 * It offers all the general-purpose charts like column, bar, line, area, pie, combination and
 * stacked charts to advanced charts like combination, scroll, zoom line, XY Plot,
 * Marimekko and Pareto charts.
 */
export enum SCROLL_CHARTS {
  SCROLL_COLUMN_2D = 'scrollcolumn2d',
  SCROLL_LINE_2D = 'scrollline2d',
  SCROLL_AREA_2D = 'scrollarea2d',
  SCROLL_STACKED_COLUMN_2D = 'scrollstackedcolumn2d',
  SCROLL_COMBINATION_2D_SINGLE_Y = 'scrollcombi2d',
  SCROLL_COMBINATION_2D_DUAL_Y = 'scrollcombidy2d',
}

/**
 * # FusionWidgets XT
 * ## Gauges
 *
 * It renders a variety of gauges and charts including speedometer charts (also called
 * angular gauge and dial chart), linear gauges, bulb gauge, Gantt charts, funnel and
 * pyramid charts. In addition, it also offers sparklines and bullet graphs that can be
 * embedded within content to show a lot of KPIs in a compact space.
 */
export enum GAUGES_CHARTS {
  REAL_TIME_ANGULAR = 'angulargauge',
  REAL_TIME_BULB = 'bulb',
  REAL_TIME_CYLINDER = 'cylinder',
  REAL_TIME_HORIZONTAL_LED = 'hled',
  REAL_TIME_HORIZONTAL_LINEAR = 'hlineargauge',
  REAL_TIME_THERMOMETER = 'thermometer',
  REAL_TIME_VERTICAL_LED = 'vled',
}

/**
 * # FusionWidgets XT
 * ## Real-time Data-streaming charts
 *
 *
 * It renders a variety of gauges and charts including speedometer charts (also called
 * angular gauge and dial chart), linear gauges, bulb gauge, Gantt charts, funnel and
 * pyramid charts. In addition, it also offers sparklines and bullet graphs that can be
 * embedded within content to show a lot of KPIs in a compact space.
 */
export enum REAL_TIME_DATA_STREAMING_CHARTS {
  REAL_TIME_AREA = 'realtimearea',
  REAL_TIME_COLUMN = 'realtimecolumn',
  REAL_TIME_LINE = 'realtimeline',
  REAL_TIME_STACKED_AREA = 'realtimestackedarea',
  REAL_TIME_STACKED_COLUMN = 'realtimestackedcolumn',
  REAL_TIME_LINE_DUAL_Y = 'realtimelinedy',
}

/**
 * # FusionWidgets XT
 * ## Spark Charts
 *
 * It renders a variety of gauges and charts including speedometer charts (also called
 * angular gauge and dial chart), linear gauges, bulb gauge, Gantt charts, funnel and
 * pyramid charts. In addition, it also offers sparklines and bullet graphs that can be
 * embedded within content to show a lot of KPIs in a compact space.
 */
export enum SPARK_CHARTS {
  SPARK_LINE = 'sparkline',
  SPARK_COLUMN = 'sparkcolumn',
  SPARK_WIN_OR_LOSS = 'sparkwinloss',
}

/**
 * # FusionWidgets XT
 * ## Bullet Graphs
 *
 * It renders a variety of gauges and charts including speedometer charts (also called
 * angular gauge and dial chart), linear gauges, bulb gauge, Gantt charts, funnel and
 * pyramid charts. In addition, it also offers sparklines and bullet graphs that can be
 * embedded within content to show a lot of KPIs in a compact space.
 */
export enum BULLET_GRAPHS_CHARTS {
  HORIZONTAL_BULLET_GRAPH = 'hbullet',
  VERTICAL_BULLET_GRAPH = 'vbullet',
}

/**
 * # FusionWidgets XT
 * ## Other charts
 *
 * It renders a variety of gauges and charts including speedometer charts (also called
 * angular gauge and dial chart), linear gauges, bulb gauge, Gantt charts, funnel and
 * pyramid charts. In addition, it also offers sparklines and bullet graphs that can be
 * embedded within content to show a lot of KPIs in a compact space.
 */
export enum OTHER_CHARTS {
  FUNNEL_CHART = 'funnel',
  PYRAMID_CHART = 'pyramid',
  GANTT_CHART = 'gantt',
  SUNBURST = 'sunburst',
}

/**
 * # PowerCharts XT
 * ## Logarithmic Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum LOGARITHMIC_CHARTS {
  LOGARITHMIC_COLUMN_2D_CHART = 'logmscolumn2d',
  LOGARITHMIC_LINE_2D_CHART = 'logmsline',
}

/**
 * # PowerCharts XT
 * ## Spline Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum SPLINE_CHARTS {
  SINGLE_SERIES_SPLINE_2D = 'spline',
  SINGLE_SERIES_SPLINE_AREA_2D = 'splinearea',
  MULTI_SERIES_SPLINE_2D = 'msspline',
  MULTI_SERIES_SPLINE_AREA_2D = 'mssplinearea',
}

/**
 * # PowerCharts XT
 * ## Error Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum ERROR_CHARTS {
  ERROR_BAR_CHART = 'errorbar2d',
  ERROR_LINE_2D_CHART = 'errorline',
  ERROR_SCATTER_CHART = 'errorscatter',
}

/**
 * # PowerCharts XT
 * ## Inverse Y Axis Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum INVERSE_Y_AXIS_CHARTS {
  INVERSE_Y_AXIS_AREA_2D_CHART = 'inversemsarea',
  INVERSE_Y_AXIS_COLUMN_2D_CHART = 'inversemscolumn2d',
  INVERSE_Y_AXIS_LINE_2D_CHART = 'inversemsline',
}

/**
 * # PowerCharts XT
 * ## Drag-able Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum DRAG_ABLE_CHARTS {
  DRAG_ABLE_COLUMN_2D_CHART = 'dragcolumn2d',
  DRAG_ABLE_LINE_2D_CHART = 'dragline',
  DRAG_ABLE_AREA_2D_CHART = 'dragarea',
}

/**
 * # PowerCharts XT
 * ## Miscellaneous Power Charts
 *
 * It offers a set of advanced charts for domain-specific usage like network diagrams, profit-loss
 * analysis, financial planning, stock price plotting and hierarchical structures. It also offers visually
 * editable charts to simulate what-if scenarios and radar (spider) charts to compare multiple entities
 * on multiple parameters.
 */
export enum MISCELLANEOUS_POWER_CHARTS {
  TREEMAP_CHART = 'treemap',
  RADAR_CHART = 'radar',
  HEAT_MAP_CHART = 'heatmap',
  BOX_AND_WHISKER_CHART = 'boxandwhisker2d',
  CANDLE_STICK_CHART = 'candlestick',
  DRAG_NODE_CHART = 'dragnode',
  STEP_LINE_CHARTS = 'msstepLine',
  MULTI_AXIS_LINE_CHART = 'multiaxisline',
  MULTI_LEVEL_PIE_CHART = 'multilevelpie',
  SELECT_SCATTER_CHART = 'selectscatter',
  WATERFALL__OR__CASCADE_CHART = 'waterfall2d',
  KAGI_CHART = 'kagi',
  SANKEY_DIAGRAM_CHART = 'sankey',
}

export enum MAP_CHARTS {
  CHINA = 'maps',
  CHINA2 = '/maps/china2',
  ASIA = '/maps/asia',
  ASIA3 = '/maps/asia3',
  WORLD = '/maps/world',
  WORLD8 = '/maps/World8',
  WORLD8WITHANTARCTICA = '/maps/World8withantarctica',
  WORLDWITHANTARCTICA = '/maps/Worldwithantarctica',
  WORLDWITHCOUNTRIES = '/maps/Worldwithcountries',
}

// 增加amchart_type类型
export enum AMCHART_TREEMAP {
  FORCE_DIRECTED_TREE = 'ForceDirectedTree',
}

export enum AMCHART_SANKEY_DIAGRAM {
  SANKEY_DIAGRAM = 'SankeyDiagram',
}

/*
export enum ChartType {
  AREA_2D = 'area2d',
  BAR_2D = 'bar2d',
  BAR_3D = 'bar3d',
  BUBBLE_CHART = 'bubble',
  COLUMN_2D = 'column2d',
  DOUGHNUT_2D = 'doughnut2d',
  ERROR_BAR_CHART = 'errorbar2d',
  FUNNEL_CHART = 'funnel',
  GANTT_CHART = 'gantt',
  HEAT_MAP_CHART = 'heatmap',
  LINE_2D = 'line',
  MS2D_DUAL_Y_COMB_CHART = 'mscombidy2d',
  PIE_2D = 'pie2d',
  REALTIME_ANGULAR = 'angulargauge',
  REALTIME_AREA = 'realtimearea',
  REALTIME_COLUMN = 'realtimecolumn',
  REALTIME_LINE = 'realtimeline',
  REALTIME_LINE_DUAL_Y = 'realtimelinedy',
  MSLTI_SERIES_BAR_2D = 'msbar2d',
  ZOOM_LINE_DUAL_Y_AXIS = 'zoomlinedy',
  MULTI_LEVEL_PIE_CHART = 'multilevelpie',
  // 新添加用户注册用户数分男女类型的柱状图
  Scroll_Stacked_Column_2D = 'scrollstackedcolumn2d',
  CHINA = 'maps',
  Ms_Stacked_Column_2D='msstackedcolumn2d'
}
*/

export enum SizeOf {
  SMALLER_SINGLE = 'ssingle',
  SINGLE = 'single',
  HALF_OF_WIDTH = 'half',
  NORMAL = '',
  Third_OF_WIDTH = 'third',
  HALF_OF_HALF = 'hhalf',
  FIFTH_OF_WIDTH = 'fifth',
}

export enum SizeZh {
  SMALLER_SINGLE = '全尺寸-半高',
  SINGLE = '全尺寸-全高',
  HALF_OF_WIDTH = '半尺寸',
  NORMAL = '标准尺寸',
  Third_OF_WIDTH = '1/3尺寸',
  HALF_OF_HALF = '1/4尺寸',
  FIFTH_OF_WIDTH = '1/5尺寸',
}

export type ChartsType =
  | SINGLE_SERIES_CHARTS
  | MULTI_SERIES_CHARTS
  | STACKED_CHARTS
  | COMBINATION_CHARTS
  | XY_PLOT_CHARTS
  | SCROLL_CHARTS
  | GAUGES_CHARTS
  | REAL_TIME_DATA_STREAMING_CHARTS
  | SPARK_CHARTS
  | BULLET_GRAPHS_CHARTS
  | OTHER_CHARTS
  | LOGARITHMIC_CHARTS
  | SPLINE_CHARTS
  | ERROR_CHARTS
  | INVERSE_Y_AXIS_CHARTS
  | DRAG_ABLE_CHARTS
  | MISCELLANEOUS_POWER_CHARTS
  | AMCHART_TREEMAP
  | AMCHART_SANKEY_DIAGRAM
  | MAP_CHARTS

const toObj = <T>(ks: string[], v: T[]) =>
  ks.reduce((o: { [propName: string]: T }, k, i) => {
    o[k] = v[i]
    return o
  }, {})

export const sizeKV = toObj<string>(Object.values(SizeOf), Object.values(SizeZh))

const baseType = {
  dataFormat: 'json',
  height: '100%',
  maxHeight: '100%',
  width: '100%',
}

export const confCreator = (type: ChartsType): ChartObject => {
  return { type, ...baseType } as ChartObject
}
