/** @format */

import { ChartObject, FusionChartStatic, Handler } from 'fusioncharts'
export interface IEvents {
  events: {
    [propNames: string]: Handler
  }
}

export type DataSourceType = {
  [propName: string]: PrimitiveType | ReferenceType<PrimitiveType | ObjectConstructor | ArrayConstructor>
}
export interface DataTableSourceType {
  data: {
    _dataStore: DataSourceType
  }
}
export type DataSource = PrimitiveType | DataSourceType | DataTableSourceType | ChartObject
export interface ModuleType extends FusionChartStatic {
  getName: () => string
  getType: () => string
  name: string
  type: string
}
export type ModuleFun = <T>(params: T) => void
