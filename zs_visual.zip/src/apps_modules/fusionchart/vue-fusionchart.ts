/** @format */

import FC, { ChartDataFormats, ChartObject, Handler } from 'fusioncharts'
import { CreateElement } from 'vue'
import { Component, Vue, Watch } from 'vue-property-decorator'
import { deepCopy, isNull } from '../functor'
import { optionsMap, props } from './config'
import { cacheFusionchart, disposeCachedFusionchart, getCachedFusionchart } from './helper/cache'
import { checkIfDataTableExists, cloneDataSource } from './utils'
import { DataSourceType, IEvents } from './fusionchart.type'

@Component({
  props,
  name: 'VueFusionchart',
  template: '<div v-pre></div>',
})
export class VueFusionchart extends Vue {
  public mountedDomId!: string
  public _uid!: string | number
  public prevDataSource!: Readonly<string | Record<string, unknown>>
  public options!: ChartObject
  public _oldOptions!: Readonly<ChartObject>

  public dataSource!: DataSourceType
  public dataFormat!: FC.ChartDataFormats

  @Watch('type')
  public onTypeChanged(type: string) {
    const fcInstance = getCachedFusionchart(this.mountedDomId)
    if (!isNull(fcInstance)) {
      fcInstance.chartType(type)
    }
  }

  @Watch('options', { deep: true })
  public onOptionsChanged() {
    this.updateChart()
  }

  @Watch('dataSource', { deep: true })
  public onDataSourceChanged() {
    const fcInstance = getCachedFusionchart(this.mountedDomId)
    if (!isNull(fcInstance) && !checkIfDataTableExists(this.dataSource)) {
      fcInstance.setChartData(this.dataSource, this.dataFormat)
    }
  }

  @Watch('dataSource.data', { deep: false })
  public onDataSourceDataChanged(newVal: DataSourceType, prevVal: DataSourceType) {
    const fcInstance = getCachedFusionchart(this.mountedDomId)

    if (isNull(fcInstance) || fcInstance?.setChartData === undefined) return
    if (newVal !== prevVal) {
      let cloneDataSource = this.dataSource
      if (this.dataSource.series) {
        cloneDataSource = deepCopy(this.dataSource)
      }
      fcInstance.setChartData(cloneDataSource, this.dataFormat)
    }
  }

  public render(h: CreateElement) {
    this.mountedDomId = 'fc-' + this._uid
    return h('div', {
      attrs: {
        id: this.mountedDomId,
      },
    })
  }

  public attachListeners() {
    if (this.$listeners && typeof this.$listeners === 'object') {
      const fcInstance = getCachedFusionchart(this.mountedDomId)
      Object.keys(this.$listeners).forEach(event => {
        if (!isNull(fcInstance)) {
          fcInstance.addEventListener(event, e => {
            this.$emit(event, e)
          })
        }
      })
    }
  }

  public createEvents() {
    const ret: IEvents = { events: {} }
    if (this.$listeners && typeof this.$listeners === 'object') {
      Object.keys(this.$listeners).forEach((event: string) => {
        ret.events[event] = (e: Handler) => {
          this.$emit(event, e)
        }
      })
    }
    return ret
  }

  public setLastOptions(config: ChartObject) {
    this._oldOptions = Object.freeze(Object.assign({}, config))
  }

  public getLastOptions(): ChartObject {
    return this._oldOptions
  }

  public getOptions(): ChartObject {
    const config: { [propName: string]: string } = {}

    Object.values(optionsMap).forEach((key: string) => {
      config[key] = this[key as keyof VueFusionchart]
    })

    return {
      ...this.options,
      ...config,
      ...{
        containerBackgroundOpacity: 0,
        containerClassName: 'fc-container',
        creditLabel: false,
        showDataLoadingMessage: true,
      },
    }
  }

  public renderChart() {
    const config = this.getOptions()

    config.renderAt = this.mountedDomId
    this.setLastOptions(config)

    disposeCachedFusionchart(this.mountedDomId)

    const events = this.createEvents()
    config.events = Object.assign({}, config.events, events.events)

    const ds = config.dataSource

    this.prevDataSource = Object.freeze(cloneDataSource(ds, checkIfDataTableExists(ds) ? 'diff' : 'clone')) as Readonly<
      string | Record<string, unknown>
    >

    const fc = new FC(config)

    // console.log('renderAt:', this.containerID)
    cacheFusionchart(this.mountedDomId, fc.render())
  }

  public updateChart() {
    const config = this.getOptions()
    const prevConfig = this.getLastOptions()
    const fcInstance = getCachedFusionchart(this.mountedDomId)

    if (isNull(fcInstance)) return

    if (config.width !== prevConfig.width || config.height !== prevConfig.height) {
      if (!isNull(config.width) && !isNull(config.height)) {
        fcInstance.resizeTo(config.width, config.height)
      }
    } else if (config.type !== prevConfig.type) {
      fcInstance.chartType(config.type)
    } else {
      if (!isNull(config.dataSource)) {
        if (!checkIfDataTableExists(config.dataSource)) {
          fcInstance.setChartData(config.dataSource, config.dataFormat as ChartDataFormats)
        }
      }
    }

    this.setLastOptions(config)
  }

  public ready() {
    this.renderChart()
  }

  public deactivated() {
    disposeCachedFusionchart(this.mountedDomId)
  }

  public beforeDestroy() {
    disposeCachedFusionchart(this.mountedDomId)
  }

  public async mounted() {
    this.renderChart()
  }

  public beforeUpdate() {
    const fcInstance = getCachedFusionchart(this.mountedDomId)
    if (isNull(fcInstance)) return

    const strPrevClonedDataSource = JSON.stringify(this.prevDataSource)
    let ds = this.dataSource
    const cloneDs = cloneDataSource(ds, 'diff')
    const strCurrClonedDataSource = JSON.stringify(cloneDs)
    if (strPrevClonedDataSource !== strCurrClonedDataSource) {
      this.prevDataSource = Object.freeze(cloneDs) as Readonly<string | Record<string, unknown>>
      if (ds.series) {
        ds = deepCopy(ds)
      }
      fcInstance.setChartData(ds, this.dataFormat)
    }
  }
}
