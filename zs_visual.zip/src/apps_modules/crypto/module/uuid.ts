/** @format */

export const uuid = () => {
  const { platform, hardwareConcurrency } = navigator

  const { colorDepth, width, height } = screen
  /*
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('experimental-webgl') as WebGLRenderingContext
    const debugInfo = gl!.getExtension('WEBGL_debug_renderer_info')

    const gVendor = gl!.getParameter(debugInfo!.UNMASKED_VENDOR_WEBGL)
    const gRenderer = gl!.getParameter(debugInfo!.UNMASKED_RENDERER_WEBGL)

    canvas.remove()
    */
  return `
  ${platform}${hardwareConcurrency}
  ${colorDepth}${width}${height}/+=
  `.replace(/[^0-9a-zA-Z]/g, '')
}
