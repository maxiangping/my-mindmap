/** @format */

import type { SharedPtr, ECB, CBC, RSAPublic, RSAPrivate, EncodingModel } from 'wasm-security'

export type WASMSecurity = typeof import('wasm-security')

class Security {
  constructor(private mod: WASMSecurity) {
    //
  }

  private get priv_rsa() {
    return this.mod.RSAPrivate
  }

  private get pub_rsa() {
    return this.mod.RSAPublic
  }

  private get cbc() {
    return this.mod.CBC
  }

  private get ecb() {
    return this.mod.ECB
  }

  private get aes_bits() {
    return this.mod.AESBits
  }

  private get ENCODE_BASE64() {
    return this.mod.EncodingModel.BASE64
  }

  private get ENCODE_NORMAL() {
    return this.mod.EncodingModel.NORMAL
  }

  private get sharedPtr() {
    return this.mod.SharedPtr
  }

  binary_to_str(shared_ptr: SharedPtr): string {
    return shared_ptr.binary_to_str()
  }

  from_text(text: string, encoding_model: EncodingModel): SharedPtr {
    return this.sharedPtr.from_text(text, encoding_model)
  }

  encode(shared_ptr: SharedPtr, enc: EncodingModel = this.ENCODE_BASE64): string {
    return shared_ptr.encode(enc)
  }

  cbc_from(key: string, iv: string) {
    return this.cbc.from(this.aes_bits.L256, key, iv)
  }

  cbc_encrypt(cbc: CBC, plaintext: string): SharedPtr {
    const ptr = this.from_text(plaintext, this.ENCODE_NORMAL)
    return cbc.encrypt(ptr)
  }

  cbc_decrypt(cbc: CBC, enc_ptr: SharedPtr): SharedPtr {
    return cbc.decrypt(enc_ptr)
  }
  cbc_decrypt_chiptext(cbc: CBC, ciphertext: string): SharedPtr {
    const ptr = this.from_text(ciphertext, this.ENCODE_BASE64)
    return cbc.decrypt(ptr)
  }

  ecb_from(key: string) {
    return this.ecb.from(this.aes_bits.L256, key)
  }

  ecb_encrypt(ecb: ECB, plaintext: string): SharedPtr {
    const ptr = this.from_text(plaintext, this.ENCODE_NORMAL)
    return ecb.encrypt(ptr)
  }

  ecb_decrypt(ecb: ECB, enc_ptr: SharedPtr): SharedPtr {
    return ecb.decrypt(enc_ptr)
  }
  ecb_decrypt_chiptext(ecb: ECB, ciphertext: string): SharedPtr {
    const ptr = this.from_text(ciphertext, this.ENCODE_BASE64)
    return ecb.decrypt(ptr)
  }

  //rsa
  rsapublic_from_pkcs1(key: string) {
    return this.pub_rsa.from_pkcs1(key)
  }
  rsapublic_from_pkcs8(key: string) {
    return this.pub_rsa.from_pkcs8(key)
  }

  rsapublic_encrypt(rsa: RSAPublic, plaintext: string): SharedPtr {
    const ptr = this.from_text(plaintext, this.ENCODE_NORMAL)
    return rsa.encrypt(ptr)
  }

  rsaprivate_from_pkcs1(key: string) {
    return this.priv_rsa.from_pkcs1(key)
  }

  rsaprivate_from_pkcs8(key: string) {
    return this.priv_rsa.from_pkcs8(key)
  }

  rsaprivate_encrypt(rsa: RSAPrivate, plaintext: string): SharedPtr {
    const ptr = this.from_text(plaintext, this.ENCODE_NORMAL)
    return rsa.encrypt(ptr)
  }

  rsaprivate_decrypt(rsa: RSAPrivate, enc_ptr: SharedPtr) {
    return rsa.decrypt(enc_ptr)
  }

  rsaprivate_decrypt_chiptext(rsa: RSAPrivate, ciphertext: string): SharedPtr {
    const ptr = this.from_text(ciphertext, this.ENCODE_BASE64)
    return rsa.decrypt(ptr)
  }
}

let __wasm_instance: WASMSecurity
let __security_instance: Security

export const hook = async <R>(cb: (mod: Security) => R): Promise<R> => {
  if (__wasm_instance === undefined) {
    __wasm_instance = await import('wasm-security')
    __security_instance = new Security(__wasm_instance)
  }

  return cb(__security_instance)
}

export const aesEncrypt = async (params: string, key: string) => {
  return await hook(async crypto => {
    const ecb = crypto.ecb_from(key)
    const enc_ptr = crypto.ecb_encrypt(ecb, params)
    return crypto.encode(enc_ptr)
  })
}
export const aesDecrypt = async (params: string, key: string) => {
  return await hook(async crypto => {
    const ecb = crypto.ecb_from(key)
    const dec_ptr = crypto.ecb_decrypt_chiptext(ecb, params)
    return crypto.binary_to_str(dec_ptr)
  })
}

export const rsaPublicEncrypt_8 = async (params: string, key: string) => {
  return await hook(async crypto => {
    const rsa = crypto.rsapublic_from_pkcs8(key)
    const enc_str = crypto.rsapublic_encrypt(rsa, params)
    return crypto.encode(enc_str)
  })
}
export const rsaPrivateDecrypt_8 = async (params: string, key: string) => {
  return await hook(async crypto => {
    const rsa = crypto.rsaprivate_from_pkcs8(key)
    const dec_ptr = crypto.rsaprivate_decrypt_chiptext(rsa, params)
    return crypto.binary_to_str(dec_ptr)
  })
}
export const rsaPrivateEncrypt_8 = async (params: string, key: string) => {
  return await hook(async crypto => {
    const rsa = crypto.rsaprivate_from_pkcs8(key)
    const enc_str = crypto.rsaprivate_encrypt(rsa, params)
    return crypto.encode(enc_str)
  })
}
