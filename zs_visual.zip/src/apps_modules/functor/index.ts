/** @format */

import { SpecialValueMap } from '@/store/model/common'

const _isNil = <T>(arg: T | NonType): arg is NonType => arg === null || arg === undefined

const _isNumber = <T>(arg: T | number): arg is number => typeof arg === 'number'

const _isStr = <T>(arg: T | string): arg is string => typeof arg === 'string'

const someNull = <T>(...args: (T | NonType)[]): boolean => args.some(_isNil)

const everyNull = <T>(...args: (T | NonType)[]): boolean => args.every(_isNil)

const isEmpty = (arg: string | NonType): arg is NonType | '' => _isNil(arg) || arg === ''
const someEmpty = (...args: string[]): boolean => args.some(isEmpty)
const everyEmpty = (...args: string[]): boolean => args.every(isEmpty)

const trim = (str: string): string => str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '')
const trimLeft = (str: string): string => str.replace(/^[\s\uFEFF\xA0]+/g, '')
const trimRight = (str: string): string => str.replace(/[\s\uFEFF\xA0]+$/g, '')

function prop<T extends ObjectConstructor, K extends keyof T>(obj: T, key: K): T[K] {
  return obj[key]
}

const align = (value: number, length = 2, sep = '0'): string => {
  const fill = new Array(length - `${value}`.length).fill(sep).join('')
  return `${fill}${value}`
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const rawProp = <T>(source: any, field: string | null, def: T): T => {
  if (_isNil(source) || isEmpty(field) || Array.isArray(source) || !(source instanceof Object)) return def
  if (source?.field || field in source) {
    const value = source[field] as unknown
    if (!_isNil(value)) return value as T
  }
  return def
}

/**
 * 功能： 将类型强制转换成泛型（注：此方法仅使用在无法做类型推导时使用，如递归、子类型等）
 *
 * @param arg 待转换参数
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const unsafeAs = <T>(arg: any): T => {
  const typof = typeof arg
  if (!Array.isArray(arg) && typof !== 'object') {
    throw Error(`Cannot convert ${typof}`)
  }

  return arg
}

const freezeFactory = <T>(v: T): Readonly<T> => Object.freeze<T>(v)

const fmtLocale = (value: number | string) => {
  return Number(parseFloat(`${value}`).toFixed(2)).toLocaleString()
}

/**
 * Deep copy function for TypeScript.
 * @param arg
 */
export const deepCopy = <
  T extends PrimitiveType | NativeJSType | U | ObjectConstructor | ArrayConstructor | never,
  U = { [K in keyof T]: T[K] }
>(
  arg: T
): T => {
  const argType = typeof arg
  if (arg === null || arg === undefined || argType === 'string' || argType === 'number' || argType === 'boolean')
    return arg
  if (arg instanceof Date) return new Date(arg.getTime()) as T
  if (arg instanceof RegExp) {
    const source = arg.source
    const flags = arg.flags
    return new RegExp(source, flags) as T
  }

  if (arg instanceof Array) {
    return arg.reduce((cp, v) => {
      cp.push(deepCopy(v))
      return cp
    }, [] as T[])
  }

  if (arg instanceof Object) {
    const keys = Object.keys(arg) as (keyof T)[]
    return keys.reduce((cp, k) => {
      const v = arg[k]
      cp[k] = deepCopy(v)
      return cp
    }, {} as { [R in keyof T]: T[R] })
  }
  return arg
}

/**
 * 对象转换成formData
 * @param model 要转换的对象
 * @param formdata
 * @param namespace
 */
export const convertModelToFormData = <T extends Record<string, StructJSONType | File[]>>(
  model: T,
  formdata: FormData = new FormData(),
  namespace = ''
): FormData => {
  const keys = Object.keys(model) as (keyof T)[]
  keys.forEach(propertyName => {
    const property = model[propertyName]
    if (property === null || property === undefined) return
    const formKey = namespace ? `${namespace}[${propertyName}]` : (propertyName as string)

    if (property instanceof Date) {
      formdata.append(formKey, property.toDateString())
    } else if (property instanceof Array) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      property.forEach((element: any, index: number) => {
        if (typeof element !== 'object') formdata.append(`${formKey}[]`, element as string)
        else if (element instanceof File) {
          formdata.append('file', element)
        } else {
          const tempFormKey = `${formKey}[${index}]`
          if (!_isNil(element) && !Array.isArray(element)) {
            convertModelToFormData(element, formdata, tempFormKey)
          }
        }
      })
    } else if (!(property instanceof File) && property instanceof Object) {
      convertModelToFormData((property as unknown) as T, formdata, formKey)
    } else {
      formdata.append(formKey, ((property as unknown) as string).toString())
    }
  })
  return formdata
}

function shuffle<T>(arr: T[]): T[] {
  for (let i = arr.length - 1; i >= 0; i--) {
    const rIndex = Math.floor(Math.random() * (i + 1))
    // 打印交换值
    const temp = arr[rIndex]
    arr[rIndex] = arr[i]
    arr[i] = temp
  }
  return arr
}

//  字符串转16进制

function toHex(str: string): string {
  if (isEmpty(str)) return ''
  const hexCharCode: string[] = ['0x']
  for (let i = 0; i < str.length; i++) {
    hexCharCode.push((str.charCodeAt(i) + 101).toString(16))
  }
  return hexCharCode.join('')
}

// 16进制转字符串

function hexToString(hex: string) {
  const trimedStr: string = hex.trim()
  const rawStr: string = trimedStr.substr(0, 2).toLowerCase() === '0x' ? trimedStr.substr(2) : trimedStr
  const len = rawStr.length
  if (len % 2 !== 0) {
    alert('Illegal Format ASCII Code!')
    return ''
  }

  const resultStr: string[] = []
  for (let i = 0; i < len; i = i++) {
    const curCharCode: number = parseInt(rawStr.substr(i, 1), 16) // ASCII Code Value
    resultStr.push(String.fromCharCode(curCharCode))
  }
  return resultStr.join('')
}

/**
 * limits your function to be called at most every W milliseconds, where W is wait.
 * Calls over W get dropped.
 * Thanks to Pat Migliaccio.
 * @param fn
 * @param wait
 * @example let throttledFunc = throttle(myFunc,500);
 */
function throttle<T>(fn: (...args: T[]) => void | Promise<void>, wait = 100) {
  let timer = -1

  return async (...args: T[]) => {
    if (timer === -1) {
      await fn(...args)
      timer = window.setTimeout(() => {
        clearTimeout(timer)
        timer = -1
      }, wait)
    }
  }
}

const random = () => {
  if (window?.crypto) {
    return window.crypto.getRandomValues(new Uint32Array(1))[0] / (0xffffffff + 1)
  }
  return Math.random()
}

/**
 *
 * @example let throttledFunc = throttleTimeOut(myFunc,500);
 */
function throttleTimeOut<T>(fn: (...args: T[]) => void | Promise<void>, wait = 100) {
  let timer = -1

  return (...args: T[]) => {
    if (timer > 0) {
      clearTimeout(timer)
      timer = -1
    }
    timer = window.setTimeout(async () => {
      await fn(...args)
      clearTimeout(timer)
      timer = -1
    }, wait)
  }
}

/**
 * 填充第一层的value值
 * @param relationList 客户规则列表
 */
function fillRelationValue<T extends { [K in keyof T]: T[K] }>(relationList: T[]) {
  // const relationTemp = deepCopy(relationList)
  // relationTemp.forEach(item => {
  //   ;((item as unknown) as T).value = rawProp(item, 'tableName', '')
  // })
  return relationList.map(item => {
    return {
      ...item,
      value: item['tableName' as keyof T] ?? '',
    }
  })
}

/**
 * 将unit8二进制转换成字符串
 * @param array array buffer
 */
const u8ArrayToString = (array: Uint8Array) => {
  let out,
    i,
    len = 0,
    c
  let char2, char3

  out = ''
  len = array.length
  i = 0
  while (i < len) {
    c = array[i++]
    switch (c >> 4) {
      case 0:
      case 1:
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:
      case 7:
        // 0xxxxxxx
        out += String.fromCharCode(c)
        break
      case 12:
      case 13:
        // 110x xxxx   10xx xxxx
        char2 = array[i++]
        out += String.fromCharCode(((c & 0x1f) << 6) | (char2 & 0x3f))
        break
      case 14:
        // 1110 xxxx  10xx xxxx  10xx xxxx
        char2 = array[i++]
        char3 = array[i++]
        out += String.fromCharCode(((c & 0x0f) << 12) | ((char2 & 0x3f) << 6) | ((char3 & 0x3f) << 0))
        break
    }
  }

  return out
}

/**
 * 延迟函数
 * @param time 要延迟的时间
 */
const createDelay = (time: number): Promise<void> => {
  return new Promise(res => {
    window.setTimeout(() => {
      res()
    }, time)
  })
}

/**
 *  删除对象的某些属性
 * @param obj 源对象
 * @param key 要删除的属性，多个用,分隔
 * @param isReplaceSource 是否返回一个新的对象，新对象是源对象拷贝之后删除目标属性的结果。true，则不修改源对象，返回新对象 false则修改原对象，无返回值
 */
const deleteUselessKey = <T extends { [K in keyof T]: T[K] }>(obj: T, key: string, isReplaceSource = true): T => {
  const copyObj = isReplaceSource ? deepCopy(obj) : obj
  const keys = key.split(',')
  keys.forEach((item: string) => {
    if (isEmpty(item)) return
    Reflect.deleteProperty(copyObj, item)
  })
  return copyObj
}

/**
 * 对 key in obj 操作符的封装
 * @param item 源对象
 * @param key 判断的属性
 */
const hasKey = <T extends { [K in keyof T]: T[K] }>(item: T | unknown, key: string | number | symbol): item is T => {
  return Reflect.has(<T>item, key)
}

/**
 * 对instanceof 的封装
 * @param value 值
 * @param classType 构造函数
 */
const instanceOf = <T extends BasicClassType>(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  value: any,
  classType: BasicClassType
): value is InstanceType<T> => {
  return value instanceof classType
}
const getItemMapByKes = <T>(data: T[], key: keyof T): SpecialValueMap<T> => {
  return data.reduce((map: SpecialValueMap<T>, item) => {
    map[`${item[key]}`] = item
    return map
  }, {})
}
export {
  align,
  _isNil as isNull,
  _isNumber as isNumber,
  _isStr as isStr,
  isEmpty,
  someEmpty,
  random,
  everyEmpty,
  someNull,
  everyNull,
  prop,
  trim,
  trimLeft,
  trimRight,
  shuffle,
  rawProp,
  fmtLocale,
  toHex,
  hexToString,
  throttle,
  freezeFactory,
  throttleTimeOut,
  unsafeAs,
  fillRelationValue,
  u8ArrayToString,
  createDelay,
  deleteUselessKey,
  hasKey,
  instanceOf,
  getItemMapByKes,
}
