
import { FusionChartStatic } from 'fusioncharts';

declare namespace Powercharts {}
declare var Powercharts: (H: FusionChartStatic) => FusionChartStatic;
export = Powercharts;
export as namespace Powercharts;

