
import { FusionChartStatic } from 'fusioncharts';

declare namespace Henan {}
declare var Henan: (H: FusionChartStatic) => FusionChartStatic;
export = Henan;
export as namespace Henan;

