
import { FusionChartStatic } from 'fusioncharts';

declare namespace Fujian {}
declare var Fujian: (H: FusionChartStatic) => FusionChartStatic;
export = Fujian;
export as namespace Fujian;

