
import { FusionChartStatic } from 'fusioncharts';

declare namespace China3 {}
declare var China3: (H: FusionChartStatic) => FusionChartStatic;
export = China3;
export as namespace China3;

