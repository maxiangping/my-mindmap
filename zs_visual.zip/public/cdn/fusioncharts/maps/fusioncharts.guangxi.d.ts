
import { FusionChartStatic } from 'fusioncharts';

declare namespace Guangxi {}
declare var Guangxi: (H: FusionChartStatic) => FusionChartStatic;
export = Guangxi;
export as namespace Guangxi;

