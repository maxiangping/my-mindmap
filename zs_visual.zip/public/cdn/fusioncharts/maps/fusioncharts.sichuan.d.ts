
import { FusionChartStatic } from 'fusioncharts';

declare namespace Sichuan {}
declare var Sichuan: (H: FusionChartStatic) => FusionChartStatic;
export = Sichuan;
export as namespace Sichuan;

