
import { FusionChartStatic } from 'fusioncharts';

declare namespace Anhui {}
declare var Anhui: (H: FusionChartStatic) => FusionChartStatic;
export = Anhui;
export as namespace Anhui;

