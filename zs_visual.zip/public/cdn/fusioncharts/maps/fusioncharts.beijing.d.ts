
import { FusionChartStatic } from 'fusioncharts';

declare namespace Beijing {}
declare var Beijing: (H: FusionChartStatic) => FusionChartStatic;
export = Beijing;
export as namespace Beijing;

