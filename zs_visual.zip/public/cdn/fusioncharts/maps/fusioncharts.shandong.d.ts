
import { FusionChartStatic } from 'fusioncharts';

declare namespace Shandong {}
declare var Shandong: (H: FusionChartStatic) => FusionChartStatic;
export = Shandong;
export as namespace Shandong;

