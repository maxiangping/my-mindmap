
import { FusionChartStatic } from 'fusioncharts';

declare namespace Shanghai {}
declare var Shanghai: (H: FusionChartStatic) => FusionChartStatic;
export = Shanghai;
export as namespace Shanghai;

