
import { FusionChartStatic } from 'fusioncharts';

declare namespace Hainan {}
declare var Hainan: (H: FusionChartStatic) => FusionChartStatic;
export = Hainan;
export as namespace Hainan;

