
import { FusionChartStatic } from 'fusioncharts';

declare namespace Chongqing {}
declare var Chongqing: (H: FusionChartStatic) => FusionChartStatic;
export = Chongqing;
export as namespace Chongqing;

