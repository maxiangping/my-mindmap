
import { FusionChartStatic } from 'fusioncharts';

declare namespace Hebei {}
declare var Hebei: (H: FusionChartStatic) => FusionChartStatic;
export = Hebei;
export as namespace Hebei;

