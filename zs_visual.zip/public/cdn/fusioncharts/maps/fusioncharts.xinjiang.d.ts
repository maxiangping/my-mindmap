
import { FusionChartStatic } from 'fusioncharts';

declare namespace Xinjiang {}
declare var Xinjiang: (H: FusionChartStatic) => FusionChartStatic;
export = Xinjiang;
export as namespace Xinjiang;

