
import { FusionChartStatic } from 'fusioncharts';

declare namespace World8withantarctica {}
declare var World8withantarctica: (H: FusionChartStatic) => FusionChartStatic;
export = World8withantarctica;
export as namespace World8withantarctica;

