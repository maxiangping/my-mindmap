
import { FusionChartStatic } from 'fusioncharts';

declare namespace Hubei {}
declare var Hubei: (H: FusionChartStatic) => FusionChartStatic;
export = Hubei;
export as namespace Hubei;

