
import { FusionChartStatic } from 'fusioncharts';

declare namespace Liaoning {}
declare var Liaoning: (H: FusionChartStatic) => FusionChartStatic;
export = Liaoning;
export as namespace Liaoning;

