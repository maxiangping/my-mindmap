
import { FusionChartStatic } from 'fusioncharts';

declare namespace Shaanxi {}
declare var Shaanxi: (H: FusionChartStatic) => FusionChartStatic;
export = Shaanxi;
export as namespace Shaanxi;

