
import { FusionChartStatic } from 'fusioncharts';

declare namespace Heilongjiang {}
declare var Heilongjiang: (H: FusionChartStatic) => FusionChartStatic;
export = Heilongjiang;
export as namespace Heilongjiang;

