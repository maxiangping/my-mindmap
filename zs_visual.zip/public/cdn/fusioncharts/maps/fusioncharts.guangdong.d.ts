
import { FusionChartStatic } from 'fusioncharts';

declare namespace Guangdong {}
declare var Guangdong: (H: FusionChartStatic) => FusionChartStatic;
export = Guangdong;
export as namespace Guangdong;

