
import { FusionChartStatic } from 'fusioncharts';

declare namespace Yunnan {}
declare var Yunnan: (H: FusionChartStatic) => FusionChartStatic;
export = Yunnan;
export as namespace Yunnan;

