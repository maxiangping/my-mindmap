
import { FusionChartStatic } from 'fusioncharts';

declare namespace Worldwithantarctica {}
declare var Worldwithantarctica: (H: FusionChartStatic) => FusionChartStatic;
export = Worldwithantarctica;
export as namespace Worldwithantarctica;

