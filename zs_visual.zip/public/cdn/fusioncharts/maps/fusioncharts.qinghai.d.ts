
import { FusionChartStatic } from 'fusioncharts';

declare namespace Qinghai {}
declare var Qinghai: (H: FusionChartStatic) => FusionChartStatic;
export = Qinghai;
export as namespace Qinghai;

