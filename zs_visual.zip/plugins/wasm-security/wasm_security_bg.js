import * as wasm from './wasm_security_bg.wasm';

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

function getObject(idx) { return heap[idx]; }

let heap_next = heap.length;

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

const lTextDecoder = typeof TextDecoder === 'undefined' ? (0, module.require)('util').TextDecoder : TextDecoder;

let cachedTextDecoder = new lTextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachegetUint8Memory0;
}

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

let WASM_VECTOR_LEN = 0;

const lTextEncoder = typeof TextEncoder === 'undefined' ? (0, module.require)('util').TextEncoder : TextEncoder;

let cachedTextEncoder = new lTextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
    return instance.ptr;
}

let cachegetInt32Memory0 = null;
function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== wasm.memory.buffer) {
        cachegetInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachegetInt32Memory0;
}

function getArrayU8FromWasm0(ptr, len) {
    return getUint8Memory0().subarray(ptr / 1, ptr / 1 + len);
}

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}
/**
*/
export const EncodingModel = Object.freeze({ BASE64:0,"0":"BASE64",HEX:1,"1":"HEX",NORMAL:2,"2":"NORMAL", });
/**
*/
export const AESBits = Object.freeze({ L128:0,"0":"L128",L192:1,"1":"L192",L256:2,"2":"L256", });
/**
*/
export class CBC {

    static __wrap(ptr) {
        const obj = Object.create(CBC.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cbc_free(ptr);
    }
    /**
    * @param {number} bits
    * @param {string} key
    * @param {string} iv
    * @returns {CBC}
    */
    static from(bits, key, iv) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ptr1 = passStringToWasm0(iv, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ret = wasm.cbc_from(bits, ptr0, len0, ptr1, len1);
        return CBC.__wrap(ret);
    }
    /**
    * @param {SharedPtr} plaintext_ptr
    * @returns {SharedPtr}
    */
    encrypt(plaintext_ptr) {
        _assertClass(plaintext_ptr, SharedPtr);
        var ret = wasm.cbc_encrypt(this.ptr, plaintext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {SharedPtr} ciphertext_ptr
    * @returns {SharedPtr}
    */
    decrypt(ciphertext_ptr) {
        _assertClass(ciphertext_ptr, SharedPtr);
        var ret = wasm.cbc_decrypt(this.ptr, ciphertext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
}
/**
*/
export class ECB {

    static __wrap(ptr) {
        const obj = Object.create(ECB.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ecb_free(ptr);
    }
    /**
    * @param {number} bits
    * @param {string} key
    * @returns {ECB}
    */
    static from(bits, key) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.ecb_from(bits, ptr0, len0);
        return ECB.__wrap(ret);
    }
    /**
    * @param {SharedPtr} plaintext_ptr
    * @returns {SharedPtr}
    */
    encrypt(plaintext_ptr) {
        _assertClass(plaintext_ptr, SharedPtr);
        var ret = wasm.ecb_encrypt(this.ptr, plaintext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {SharedPtr} ciphertext_ptr
    * @returns {SharedPtr}
    */
    decrypt(ciphertext_ptr) {
        _assertClass(ciphertext_ptr, SharedPtr);
        var ret = wasm.ecb_decrypt(this.ptr, ciphertext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
}
/**
*/
export class RSAPrivate {

    static __wrap(ptr) {
        const obj = Object.create(RSAPrivate.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rsaprivate_free(ptr);
    }
    /**
    * @param {string} key
    * @returns {RSAPrivate}
    */
    static from_pkcs1(key) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.rsaprivate_from_pkcs1(ptr0, len0);
        return RSAPrivate.__wrap(ret);
    }
    /**
    * @param {string} key
    * @returns {RSAPrivate}
    */
    static from_pkcs8(key) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.rsaprivate_from_pkcs8(ptr0, len0);
        return RSAPrivate.__wrap(ret);
    }
    /**
    * @param {SharedPtr} plaintext_ptr
    * @returns {SharedPtr}
    */
    pub_encrypt(plaintext_ptr) {
        _assertClass(plaintext_ptr, SharedPtr);
        var ret = wasm.rsaprivate_pub_encrypt(this.ptr, plaintext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {SharedPtr} plaintext_ptr
    * @returns {SharedPtr}
    */
    encrypt(plaintext_ptr) {
        _assertClass(plaintext_ptr, SharedPtr);
        var ret = wasm.rsaprivate_encrypt(this.ptr, plaintext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {SharedPtr} ciphertext_ptr
    * @returns {SharedPtr}
    */
    decrypt(ciphertext_ptr) {
        _assertClass(ciphertext_ptr, SharedPtr);
        var ret = wasm.rsaprivate_decrypt(this.ptr, ciphertext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
}
/**
*/
export class RSAPublic {

    static __wrap(ptr) {
        const obj = Object.create(RSAPublic.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_rsapublic_free(ptr);
    }
    /**
    * @param {string} key
    * @returns {RSAPublic}
    */
    static from_pkcs1(key) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.rsapublic_from_pkcs1(ptr0, len0);
        return RSAPublic.__wrap(ret);
    }
    /**
    * @param {string} key
    * @returns {RSAPublic}
    */
    static from_pkcs8(key) {
        var ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.rsapublic_from_pkcs8(ptr0, len0);
        return RSAPublic.__wrap(ret);
    }
    /**
    * @param {SharedPtr} plaintext_ptr
    * @returns {SharedPtr}
    */
    encrypt(plaintext_ptr) {
        _assertClass(plaintext_ptr, SharedPtr);
        var ret = wasm.rsapublic_encrypt(this.ptr, plaintext_ptr.ptr);
        return SharedPtr.__wrap(ret);
    }
}
/**
*/
export class SharedPtr {

    static __wrap(ptr) {
        const obj = Object.create(SharedPtr.prototype);
        obj.ptr = ptr;

        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.ptr;
        this.ptr = 0;

        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sharedptr_free(ptr);
    }
    /**
    * @returns {number}
    */
    get at_ptr() {
        var ret = wasm.__wbg_get_sharedptr_at_ptr(this.ptr);
        return ret;
    }
    /**
    * @param {number} arg0
    */
    set at_ptr(arg0) {
        wasm.__wbg_set_sharedptr_at_ptr(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get length() {
        var ret = wasm.__wbg_get_sharedptr_length(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set length(arg0) {
        wasm.__wbg_set_sharedptr_length(this.ptr, arg0);
    }
    /**
    * @returns {number}
    */
    get capacity() {
        var ret = wasm.__wbg_get_sharedptr_capacity(this.ptr);
        return ret >>> 0;
    }
    /**
    * @param {number} arg0
    */
    set capacity(arg0) {
        wasm.__wbg_set_sharedptr_capacity(this.ptr, arg0);
    }
    /**
    * @param {number} capacity
    * @returns {SharedPtr}
    */
    static with_capacity(capacity) {
        var ret = wasm.sharedptr_with_capacity(capacity);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {string} input
    * @param {number} model
    * @returns {SharedPtr}
    */
    static from_text(input, model) {
        var ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        var ret = wasm.sharedptr_from_text(ptr0, len0, model);
        return SharedPtr.__wrap(ret);
    }
    /**
    * @param {number} model
    * @returns {string}
    */
    encode(model) {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sharedptr_encode(retptr, this.ptr, model);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
    /**
    * @returns {string}
    */
    binary_to_str() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sharedptr_binary_to_str(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            return getStringFromWasm0(r0, r1);
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
            wasm.__wbindgen_free(r0, r1);
        }
    }
    /**
    * @returns {Uint8Array}
    */
    to_binary() {
        try {
            const retptr = wasm.__wbindgen_add_to_stack_pointer(-16);
            wasm.sharedptr_to_binary(retptr, this.ptr);
            var r0 = getInt32Memory0()[retptr / 4 + 0];
            var r1 = getInt32Memory0()[retptr / 4 + 1];
            var v0 = getArrayU8FromWasm0(r0, r1).slice();
            wasm.__wbindgen_free(r0, r1 * 1);
            return v0;
        } finally {
            wasm.__wbindgen_add_to_stack_pointer(16);
        }
    }
}

export const __wbg_new_59cb74e423758ede = function() {
    var ret = new Error();
    return addHeapObject(ret);
};

export const __wbg_stack_558ba5917b466edd = function(arg0, arg1) {
    var ret = getObject(arg1).stack;
    var ptr0 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    getInt32Memory0()[arg0 / 4 + 1] = len0;
    getInt32Memory0()[arg0 / 4 + 0] = ptr0;
};

export const __wbg_error_4bb6c2a97407129a = function(arg0, arg1) {
    try {
        console.error(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_free(arg0, arg1);
    }
};

export const __wbindgen_object_drop_ref = function(arg0) {
    takeObject(arg0);
};

export const __wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

export const __wbindgen_rethrow = function(arg0) {
    throw takeObject(arg0);
};

