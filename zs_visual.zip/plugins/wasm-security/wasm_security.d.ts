/* tslint:disable */
/* eslint-disable */
/**
*/
export enum EncodingModel {
  BASE64,
  HEX,
  NORMAL,
}
/**
*/
export enum AESBits {
  L128,
  L192,
  L256,
}
/**
*/
export class CBC {
  free(): void;
/**
* @param {number} bits
* @param {string} key
* @param {string} iv
* @returns {CBC}
*/
  static from(bits: number, key: string, iv: string): CBC;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class ECB {
  free(): void;
/**
* @param {number} bits
* @param {string} key
* @returns {ECB}
*/
  static from(bits: number, key: string): ECB;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class RSAPrivate {
  free(): void;
/**
* @param {string} key
* @returns {RSAPrivate}
*/
  static from_pkcs1(key: string): RSAPrivate;
/**
* @param {string} key
* @returns {RSAPrivate}
*/
  static from_pkcs8(key: string): RSAPrivate;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  pub_encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class RSAPublic {
  free(): void;
/**
* @param {string} key
* @returns {RSAPublic}
*/
  static from_pkcs1(key: string): RSAPublic;
/**
* @param {string} key
* @returns {RSAPublic}
*/
  static from_pkcs8(key: string): RSAPublic;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class SharedPtr {
  free(): void;
/**
* @param {number} capacity
* @returns {SharedPtr}
*/
  static with_capacity(capacity: number): SharedPtr;
/**
* @param {string} input
* @param {number} model
* @returns {SharedPtr}
*/
  static from_text(input: string, model: number): SharedPtr;
/**
* @param {number} model
* @returns {string}
*/
  encode(model: number): string;
/**
* @returns {string}
*/
  binary_to_str(): string;
/**
* @returns {Uint8Array}
*/
  to_binary(): Uint8Array;
/**
* @returns {number}
*/
  at_ptr: number;
/**
* @returns {number}
*/
  capacity: number;
/**
* @returns {number}
*/
  length: number;
}
