/* tslint:disable */
/* eslint-disable */
/**
* @returns {WebAssembly.Memory}
*/
export function shared_memory(): WebAssembly.Memory;
/**
*/
export enum AESBits {
  L128,
  L192,
  L256,
}
/**
*/
export enum Encode {
  BASE64,
  HEX,
}
/**
*/
export class CBC {
  free(): void;
/**
* @param {number} bits
* @param {string} key
* @param {string} iv
* @returns {CBC}
*/
  static from(bits: number, key: string, iv: string): CBC;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class ECB {
  free(): void;
/**
* @param {number} bits
* @param {string} key
* @returns {ECB}
*/
  static from(bits: number, key: string): ECB;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class RSAPrivate {
  free(): void;
/**
* @param {string} key
* @returns {RSAPrivate}
*/
  static from_pkcs1(key: string): RSAPrivate;
/**
* @param {string} key
* @returns {RSAPrivate}
*/
  static from_pkcs8(key: string): RSAPrivate;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  pub_encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
/**
* @param {SharedPtr} ciphertext_ptr
* @returns {SharedPtr}
*/
  decrypt(ciphertext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class RSAPublic {
  free(): void;
/**
* @param {string} key
* @returns {RSAPublic}
*/
  static from_pkcs1(key: string): RSAPublic;
/**
* @param {string} key
* @returns {RSAPublic}
*/
  static from_pkcs8(key: string): RSAPublic;
/**
* @param {SharedPtr} plaintext_ptr
* @returns {SharedPtr}
*/
  encrypt(plaintext_ptr: SharedPtr): SharedPtr;
}
/**
*/
export class SharedPtr {
  free(): void;
/**
* @param {number} capacity
* @returns {SharedPtr}
*/
  static with_capacity(capacity: number): SharedPtr;
/**
* @param {string} text
* @returns {SharedPtr}
*/
  static from_text(text: string): SharedPtr;
/**
* @param {number} encode
* @returns {string}
*/
  encode(encode: number): string;
/**
* @returns {string}
*/
  binary_to_str(): string;
/**
* @returns {number}
*/
  at_ptr: number;
/**
* @returns {number}
*/
  cap: number;
/**
* @returns {number}
*/
  len: number;
}
