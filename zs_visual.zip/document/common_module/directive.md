所在目录：src/apps/directive
# 1.v-asset
加载静态资源的指令
使用方式: v-asset:src="`src`" src是指静态资源相对src/assets/的路径
功能：加载静态资源
示例: v-asset:src="`icon/datasource/panelboard/boardlist_empty.svg`"

# 2.v-editor
报表平台项目中，文本编辑组件的工具栏定位及显示/隐藏使用的一个指令
使用方式：v-editor="true/false"
功能：寻找当前绑定指令的dom元素的父元素，将当前元素放在父元素的左上方(父元素外)，根据传入的值决定是显示还是隐藏，true为显示，false为隐藏。每次切换显示状态时更新该dom的位置。

# 3.v-tap
兼容移动端的touch事件的一个指令
使用方式：v-tap
功能：在touchend事件中派发click事件
示例：在元素上加v-tap

# 4.v-touch
让pc端的拖拽功能能在移动端或者触摸屏上使用的一个指令
使用方式：v-touch
功能：因为移动端没有drag事件，只有touch事件，所以在移动端监听了touchstart和touchend事件，在touchstart中派发dragstart事件，在touchend事件中派发dragend事件，在移动端模拟pc端的drag相关的逻辑；并clone当前节点，在touchmove中模拟正在拖拽的节点。
示例：在元素上加v-touch

# 5.v-input
使输入框在实时更新或者清除内容时触发keyup.enter事件的一个指令
功能：部分输入框具有搜索功能，需要实时触发或者按需触发。绑定的值为'val1-val2'，val1为输入框绑定的值，val2为触发方式，目前只支持clear和input，clear是输入框内容为空时触发，input是实时触发，触发的是绑定元素的keyup.enter事件，即按下enter的事件
示例: v-input="`${activityName}-clear`"

# 6.v-Focus
带搜索的下拉框，因为空状态时也有输入框，在有数据和无数据的切换时。需要让此时显示的input聚焦/focus，但是element-ui自带的autoFocus无法满足这种场景，所以用v-Focus实现input展示时的自动聚焦。

# 7.v-Mousemove
为了兼容触摸屏下的mouse系列事件，用touch系列事件模拟mouse系列的事件。
touchstart触发mousedown，touchmove触发mousemove,touchend触发mouseup。
需要注意的是，touch系列和mouse系列有一些属性无法兼容，比如touch事件对象没有offsetX和offsetY，有pageX、pageY和screenX、screenY。其他属性，在使用的时候请自行比较两种事件的事件对象的差异

updatetime:2020-8-26
