所在目录：src/apps/mixins
# 1.dialog
请求异常时出现的弹框组件，由store/Dialog中的showDialog属性控制，包含confirm和cancel两个回调

# 2.explorerControl
控制左侧菜单栏是否显示。在mounted中隐藏，beforeDestroy中默认显示
示例:src/apps/app_reportplat/views/datasource/panel_board/edit/edit_area_section/edit_head/index.ts

# 3.functor
部分工具函数，放在这个mixins中方便在组件中使用

# 4.loading
在http请求时出现的过渡动画，由store/loading中的abortLoading属性控制

# 5.routeHooks
路由变化时的钩子，包括beforeRouteLeave和beforeRouteEnter。在手动执行路由对象的push或者replace方法时，在beforeRouteLeave中判断当前路由是否有权限跳转到目标路由上，在beforeRouteEnter中判断进入路由时，菜单数据如果为空则跳转到登录页。
示例:src/apps/app_reportplat/views/datasource/panel_board/index.ts

# 6.socket
为使用websocket功能开发的一个组件，websocket的相关数据放在了store/socket中，业务组件通过wsSendRequest方法发送请求，并在store/socket获取数据

## 使用方式

组件直接混入socket组件
示例:src/apps/app_reportplat/views/datasource/data_collection_list/edit/edit_section/code_mirror/index.ts

## 发送请求
this.ws.wsSendRequest(params,project).
注意，同一个会话发起的websocket通信不要携带toUser参数，并且需要携带id区分各个请求的相应。

## 接收数据
监听 SocketStore的currentKey属性，currentKey是入参中的id属性。
通过SocketStore的currentDataMap属性，获取存储实际数据的map对象，通过map对象的take(id,defaultValue)方法获取该id对应的数据

参考:
```
  @Watch('currentKey')
  public getFieldData(id: string) {
    const fieldData: TableField[] = this.currentDataMap.take<TableField[]>(id, []) ?? []
  }
```


# 7.BuriedPoint
为实现埋点统计开发的一个组件，在进入一些页面时，需要触发埋点，所以在该组件的mounted钩子中调用了触发埋点的逻辑，埋点数据类型需要在对应的组件上用pointType属性指定

# 8.chart.mixins
仪表板作为看板在其他项目中使用时，该组件可作为处理仪表板相关数据的功能组件。

## 初始化仪表板数据
获取到仪表板的数据之后，调用chart.mixins.ts内的handleBoardData方法，可将数据初始化为可用的数据

## 事件监听
其他项目嵌入仪表板，需要在chart-area组件上监听setFieldRangeMap及pageChange方法，处理函数调用chart.mixins.ts内的同名函数即可

## 过滤条件
如果看板有过滤条件，那么在过滤条件对应的change事件上调用changeFilters方法，该方法有三个参数，分别为(字段别名，当前的值，值绑定的key)
第三个参数：值绑定的key，对应关系如下：
输入框/单选框/非范围的时间选择框等单个值的，key为value，
数字范围输入框，key为valRange
多选框，key为valList
时间范围选择框，key为date

参考：src\apps\app_crm\views\active_plane\parts\promote_board\index.ts
```
    this.changeFilters('时间', date, 'value')
```

# 9.formValidate
商机中心项目及精准营销项目部分表单生成校验函数的一个工具函数，因为vue中this实例的绑定问题，暂时将表单数据绑定的对象和key写死



updatetime:2020-8-7

