# 登录流程解释

登录分为两次请求，两次请求的路径相同，但是请求方式不同，数据放在响应头及返回的数据里面，相关逻辑位于src\store\model\base\auth.ts文件中，解释如下：

## 第一次登录
接口路径：/login

请求方式：get请求

携带参数：无

返回的数据：
1.响应头中的zxwd-ua
该数据是rsa的私钥，记为RSAPrivateKey，用于对用户数据进行加密

2.返回的数据body中的data
该数据是加密模型，记为uaKey，前端存储，传给后端，后端用于获取对应的加密模型
该接口的返回数据后端没有加密，前端也不需要解密。因为后续的接口需要传递该数据，因为存放在window.localStorage中，可通过getSessionKey(SESSION_KEY.UAKEY)获取，通过setSessionKey(SESSION_KEY.UAKEY)修改

## 第二次登录
接口路径：/login

请求方式：post请求

携带参数 ：

1.body体中携带的数据，是用RSAPrivateKey加密之后的用户信息，没有添加签名

2.请求头中，需要携带zxwd-ua，值为第一次请求时获取的uaKey

返回的数据：

1.响应头中的zxwd-ua
该数据为rsa的私钥，记为rsaPriKey，用于对AES秘钥的解密

2.响应头中的ua
该数据为RSA加密之后的AES秘钥，记为AESKey，经rsaPriKey解密之后，该AES秘钥用于后续接口数据的加密，因此存放在window.localStorage中，可通过getSessionKey(SESSION_KEY.AESKEY)获取，通过setSessionKey(SESSION_KEY.AESKEY)修改

3.响应头中的zxwd-sessionid
该数据为用户的token，记为token，用于后端的校验，因此后续所有接口都需要携带该token，也用于参数的签名认证，存放在window.localStorage中，可通过getSessionKey(SESSION_KEY.TOKEN)获取，通过setSessionKey(SESSION_KEY.TOKEN)修改

4.返回的数据
此次接口返回的数据经过了AES加密，秘钥是AESKey(后续所有接口返回的数据都经过了AES加密)，正常返回的数据是用户信息。

## 相关数据控制

登录成功时获取的部分数据，会用于后续的接口校验和数据处理，目前存放在window.localSrorage中。为方便控制这些数据，对这些数据的读取和写入进行了封装，如下：

```TypeScript
const enum SESSION_KEY {
  TOKEN = 'zxwd_sessionid',
  AESKEY = 'AESKey',
  UAKEY = 'UAKey',
}
const getSessionKey = (key: SESSION_KEY): string => {
  return window.localStorage.getItem(key) ?? ''
}
const setSessionKey = (key: SESSION_KEY, value: string) => {
  window.localStorage.setItem(key, value)
}
```

示例：
```TypeScript
  setSessionKey(SESSION_KEY.TOKEN, '')
  getSessionKey(SESSION_KEY.TOKEN)
```



updatetime:2020-11-5
