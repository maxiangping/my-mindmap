# 1. calc

**工程内严格控制使用calc。**

## 解释：
    calc 是运行时进行动态计算，在复杂场景下往往会引起渲染性能下降。在动态组件中，容易引起传递错误的size到子级，导致一些难以处理的bug。

# 2. 使用样式继承而不是重复定义

**暂无**

## 解释：
    继承能还来更低的页面修改或重构成本
        举例：

```css
    body{
        font: normal 14px xxx;
    }

    .xxx{
        font-family: PingFangSC-Regular;
    }

    .xxx .yyy{
        font-family: PingFangSC-Regular;
    }
```

# 3. !important

**样式中禁止使用!important**

## 解释：
  使用!important方式控制样式权重太过粗暴，不利于后续的维护和修改，也很容易发生样式覆盖的问题。

# 4. less文件中样式嵌套不宜过多

**暂无**

## 解释：
  嵌套的书写方式使结构复杂，不利于阅读和维护。


# 5. flex-grow：auto

**flex-grow:auto的元素，在主轴方向上的长度属性应设置为0**

## 解释：
  当某元素的父元素是flex布局，该元素的flex-grow属性为auto时，若不设置主轴方向上的长度属性，且该元素或该元素的子元素需要超出滚动，那该元素会被子元素撑开，flex-grow:auto会失效。
  举例：
  ```css
  .parent{
    display:flex;
  }
  .child1{
    width:20px;
    flex:none
  }
  .child2{
    flex:auto;
    width:0;
    overflow:auto;
  }
  ```

# 6. float/position:absolute

**在自适应或者一些布局场景，尽量使用flex/grid布局而非flot或者position:absolute**

## 解释：
  float会导致父元素的塌陷，且各版本的浏览器对float的一些实现细节不同，导致一些兼容性问题，尽量不要使用。
  position:absolute在适配方面表现不如flex/grid。
  按照目前的经验，大部分布局方案都可以用非float或者absolute的方案实现
  当然，只是推荐flex或者grid，并非强制。


# 7. height

**需要出现竖向滚动条的页面，页面元素(非position:absolute/fixed)不管size是否固定，都要写height属性**

## 解释
 竖向滚动条的出现需要该元素有height属性，height默认是不继承的，作为页面布局元素，需要显示的写height属性才能保证height属性从外层元素正常传递进内层元素，否则渲染时容易导致元素高度计算不正确，最典型的就是需要出现滚动条的table。

# 8. img元素父元素的高度问题

如果一个元素内包裹一个替换inline/inline-block元素（img/video等），那么父元素的高度将会比img元素的高度略高。这是因为替换inline元素前默认有一个不可见的空白inline节点，而元素的vertical-align默认值是baseline，即基线对齐，img元素的基线是图片下边缘，空白节点的基线是x字符的下边缘，因为空白节点的行高默认继承，所以空白节点会将父元素往下挤，导致父元素高度比img元素略高。

解决思路分两种：处理img元素；处理空白节点。

1.处理空白节点，其实就是处理父元素,因为父元素是被空白节点的对齐方式挤高的，那么，空白节点和img顶端对齐，就不会往下挤。或者，空白节点的font-size或者line-height为0，也不会往下挤，而空白节点的font-size和line-height是继承自父节点的，所以给父节点设置vertical-align:top、line-height:0、font-size:0，都可以解决

2.处理img元素。替换inline元素会出现这个问题，那么非inline元素就不会了。可以将img元素的display设置为block，或者给父元素设置display:flex等属性，或者将img元素float:left等。


updatetime:2020-10-28
