
# 1. truety and falsely

**工程内对真假值需要进行严格进行判断，禁止使用隐式转换。**
## 解释：
    js 中真假值隐式转换容易引起bug，由于js是弱类型语言，边界情况比较复杂。隐式转换本身就带来了隐藏问题，故禁止使用。

    举例：

```js
function somefn(i){
    if(i){
        // todo
    }
}

```

# 2. true判断

**工程内判断逻辑要求洁明了，禁止对真值再判断。**
## 解释：
    了解编程中语句(statement)与表达式(expression)的区别。 表达式本身就是返回一个逻辑运算结果，而语句通常是进行逻辑运算、分支处理等。
    举例：

```javascript
// 1
// a = 1 here
const i = a<5

// bad
if(i===true){
    // todo
}

// good
if(i){
    // todo
}

// bad
if(a<5?true:false){
    // todo
}
```

# 3. 逻辑运算符/三目运算符

**不要利用逻辑运算符的短路/三目运算符来执行语句**

## 解释：
  从代码的语义性考虑，运算符的目的是返回一个结果，利用逻辑运算符的短路来执行语句，不利于代码阅读和维护，也无法带来性能上的提升。

  ```typescript
  let a!:boolean
  //...some code

  // bad
  a||(this.doSomething())
  a?(this.doSomething()):(this.doAnotherThing())

  ```

# 4. delete,in等操作符

**删除对象属性等操作，使用Reflect对象上的方法而非用操作符**

## 解释
  delete，in等操作符是命令式的代码，与函数行为的代码相比，可读性更差

  ```javascript
  const obj = { a:1 }
  // bad: delete obj.a
  // good: Reflect.deleteProperty(obj, 'a')

  // bad: 'a' in obj
  // good:Reflect.has(obj, 'a')
  ```
  目前项目上有封装工具函数：deleteUselessKey方法，位于src\apps_modules\functor\index.ts上，用于删除对象的部分属性
  objHasKey方法，位于src\apps_modules\functor\index.ts上，用于根据对象是否有某个属性判断某个对象是否是某个类型

# 5. 绑定事件的方式

**绑定事件使用dom.addEventListener()，不使用dom.on+eventname=fn的方式**

## 解释
  dom.addEventListener()是将需要触发的回调函数推入对应的监听队列，不会影响已绑定的其他回调函数。
  dom.onclick等方式，会覆盖该dom已绑定的回调函数

  目前项目没有兼容ie8及以下浏览器的需求，不需要考虑addEventListener的兼容性问题

  示例:
  ```javascript
  const a = window.document.querySelector('.aaa')

  // bad
  a.onclick = fn

  // good
  a.addEventListener('click',fn,false)
  ```

# 6. 获取dom的方式

**注意getElementBy系列api和querySelectorAll的差别，在不同的场景使用合适的api**

## 解释
虽然两个系列的api返回结果，都是null或者类数组(Array Like)，但是返回的数据类型以及自身消耗的性能有区别

getElement系列的api返回结果是HTMLCollection，querySelectorAll返回的是NodeList，从规范上来说，二者都是动态的元素集合(Live Node List)，但是规范对querySelectorAll方法做了特别的限制:

The NodeList object returned by the querySelectorAll() method must be static ([DOM], section 8).

querySelectorAll方法返回的是一个静态的NodeList(Static Node List)，即当前元素集合的快照。
这就带来一个问题，当对页面的元素修改时，动态的元素集合会自动重新查询并更新，静态的则不会，这就带来了性能损耗。如果修改了元素，很可能造成多次更新甚至死循环

示例：
```javascript
//以下代码会死循环，因为lis是动态更新的，每次执行一轮循环，都会引起lis的更新
var ul = document.getElementsByTagName('ul')[0],
    lis = ul.getElementsByTagName("li");
for(var i = 0; i < lis.length ; i++){
    ul.appendChild(document.createElement("li"));
}

```

从本身的查询性能来说，getElementBy系列远远优于querySelectorAll，目前在谷歌70的浏览器下耗时相差15倍左右，84版本下耗时相差10倍左右。

所以，总的来说， 如果要修改查询出来的dom，更适合querySelector系列api;如果页面非常复杂，dom数量很多，且不需要修改dom，getElementBy系列更好;除此之外，二者均可。

# 7. localStorage和sessionStorage等window上api的调用

**在调用window上的方法时，请使用window.localStorage...的方式**

## 解释

localStorage、sessionStorage等window上挂的api并不是关键字或保留字，有被局部变量覆盖的风险，建议显式的通过window调用


updatetime:2020-11-4
