<!-- @format -->

项目公共组件分为两部分，一部分是与业务关联性不强的组件，目录为 src/components;另一部分是可能在多个项目中使用的，和业务关联性较强的组件，目录为 src/apps/components

# 1 路径

src/apps/components

# 2 组件说明

## 1 app

所有项目的根实例组件(普通 vue 项目的 APP.vue)，一些公共逻辑，如左侧菜单栏的显示/隐藏、权限判断等放在了这里

## 2 auth_failed

公共的登录页

## 3 card_box

封装的卡片组件，目前在精准营销项目中有使用，适用于内容+操作按钮的卡片

## 4 chart

项目所用的图表组件，基于 fusionchart 封装而成。chart.fc 是 fusionchart

## 5 customer

客户视图一期项目中使用的一些组件，包括规则组件(rule)、顶部栏(userbar)、看板组件(board)等

## 6 editorjs

引入的一个文本编辑器插件

## 7 explorer

左侧菜单栏组件及相关的子组件

## 8 feedback

公共的意见反馈页

## 9 flow

自动流程图组件，支持节点的拖拽、连线等功能。目前在精准营销项目中有使用，详细说明文档见 src/apps/components/flow/flow 组件开发说明.md

## 10 layout

一些页面布局组件，包括:
chart:移动 bi 项目用的图表布局
cockpit:大屏项目所用的综合视图布局
datagrip:客户视图一期的页面布局
large_screen:大屏项目的页面布局
system:系统配置项目的页面布局
simulation:移动 bi 项目用的图表的布局

## 11 panel_board_preview

报表平台项目的看板预览组件，用于在其他项目预览看板

## 12 popLayer

封装的公共组件的容器组件，如 dialog，loading 等

## 13 route_tab

封装的菜单页签组件(用于大屏项目)

## 14 simulation

模拟的一个手机界面，用于移动 bi 项目作为图表容器

## 15 querySelect

支持关键字搜索的下拉框组件，在 el-select 的基础上包装了一层，没有分页，内部前端实现实时过滤，支持 el-select 的所有属性，同时需要另外传 selectList 作为下拉框的数据来源，labelKey:用于作为 label 的属性，默认为`label`，valueKey:用于作为 value 的属性，默认为`value`
示例:

```html
          <query-select
            v-model="editForm.nodeDefineRule.ctGroupId"
            :label-key="`groupName`"
            :value-key="`groupId`"
            placeholder="请选择客群"
            :size="`small`"
            :select-list="groupList"
          ></query-select>
```

## 16 form-error-message

类似表单验证的错误提示组件，需要注意的是，该组件定位方面是 absolute+top:100%，所以需要给父组件设置 position:relative 同时不能设置 overflow:hidden。
props 有三个:visible，控制提示的显示/隐藏，类型为 boolean；errorText:错误提示的文字，string 类型；showIcon:是否在文字前面显示图标，boolean 类型，默认 false
示例:

```html
 <form-error-message :visible="!checkSoureName" :error-text="sourceNameErrorMsg"></form-error-message>
```

## 17 colorImage

支持动态的修改 svg/image 的颜色，目前只支持单色修改，利用 filter 滤镜实现。目前可用于背景透明的 svg 图标的颜色修改
props 说明:
src:图片路径，是绝对路径，与 v-asset 的路径等同，string 类型，必传
width:图片宽度，string 类型，需要带上单位，可选，默认值为 16px
height:图片高度，string 类型，需要带上单位，可选，默认值为 width 的值
color:图片颜色，string 类型，支持十六进制及 rgba 颜色值，可选，不传时保持 svg 原来的颜色
title:鼠标悬浮上去时的文字,string，可选
hoverMarkBgColor: 鼠标悬浮上去时图片蒙层的颜色

```html
            <color-image
              :width="`16px`"
              src="icon/datasource/chart_design_fold_default.svg"
              :color="isCurrentCategory(item.categoryId) ? '#4D81EF' : ''"
              class="edit-icon"
              :hoverMarkBgColor="'#F4F7FE'"
            ></color-image>
```

## 18 send_sms

商机管理/精准营销中使用的短信渠道编辑组件

updatetime:2020-11-3
