<!-- @format -->

# 1.common

所在目录:src/apps/common
dynImporter.ts:用于动态导入一些模块
launcher.ts:项目初始化的基类，管理所有项目公共的一些功能，如管理登录状态、路由守卫，注册公共路由等
PageBuilder.ts:大屏项目图表区域初始化的基类，管理大屏页面的功能，如 tab 栏、数据处理等
constant.ts :公共的一些全局常量 ，目前包括 登录失败的路径（真正的及在数字展示厅展示的）

# 2.interceptor

所在目录:src/apps/interceptor
登录状态相关的一些公共方法

# 3.router

所在目录:src/apps/router
注册公共页面的路由，如登录/反馈页、看板预览页

# 4.assets

所在目录:src/assets
放置静态资源，svg、img 等

# 5.stylesheets

所在目录:src/assets/stylesheets
放置项目的一些全局样式文件

updatetime:2020-7-10
