<!-- @format -->

# 1.说明

## a. 欢迎提 bug、提优化建议、提新增功能。

## b. 如阅读完本文档之后仍有疑问，请联系 ygf。

# 2.文件路径

## a. 业务代码路径:src/apps/components/flow 文件夹下。

## b. 模型定义路径:src/store/modules/public/flow.ts。

## c. 此说明文档路径:src/store/modules/public/flow/flow 组件开发说明.md。

# 3.模块说明

为方便维护，解耦流程图组件的各模块功能，将组件逻辑拆分为 6 个 module 及对外的公共入口 newIndex，各模块说明如下:

## a.dataInit

负责 flow 组件的所有 数据初始化，以及和具体功能无关的公共方法

## b.dataManage

一些和 flow 数据相关的处理方法，不作为功能逻辑的入口/起点，而是负责 flow 数据的处理部分

## c.stackManage

负责 flow 组件的状态记录。因为 flow 组件目前有前进/后退功能，需要在一些交互的节点上记录数据，以及相关的存/取数据功能，都在该模块上

## d.canvasDrawer

负责画布绘制，如绘制各类线条

## e.canvasInteraction

主要负责画布的交互功能，包括画布缩放、画布拖拽、画布点击及相应的部分计算，如对各类线条的处理，对线段选中的判断等

## f.nodeInteraction

负责节点的交互，包括节点的拖拽、连线、删除等

## g.newIndex

flow 组件新的入口，目前页面的初始化数据的入口、对一些数据的 watch、各类事件的监听和解绑、对外暴露的一些 api、和工具栏的操作入口等逻辑位于该模块上

# 4.flow 组件 props

## a. movestep

    拖拽的步长，非必传，number类型，默认值10，单位px。

## b. scaleStep

    缩放的步长，非必传，number类型，默认值5，单位%。

## c. listData

    自动流程图的数据，必传，FlowNodeItem<T>[]类型， 由createItem()生成，位于 src/store/modules/public/flow/config.ts内，如下:

```typescript
 /**
 * createItem
 * @item 节点自身的数据，类型通过T传入
 * @layout 节点的坐标，由flow组件传递出来，外部组件只需接收
 * @id 节点的id，需保持一致
 * @w 节点的宽度，单位px
 * @h 节点的高度 单位px
 * @showFocus 节点悬浮时是否显示连线的焦点,'0':默认都显示 '1':隐藏顶部焦点 '2'隐藏底部焦点 '3':都隐藏
 */
const createItem = <T = null>(item: T, layout: FlowNodeLayout, id: string, w: number, h: number ,showFocus='0'): FlowNodeItem<T> => {

  return {
    id,
    x: layout.x,
    y: layout.y,
    w,
    h,
    showFocus,
    childNode:[]
    lineData: [],
    componentData: item,
  }
}
```

## d. isDragItem

    当前是否正在拖拽节点（此属性只需考虑外部节点的拖拽），必传，boolean类型。

## e. mode

    当前流程图的模式，非必传，string类型，默认值为edit，目前暂定值可选项为edit/preview/limitEdit，eidt模式下可进行所有操作，preview模式下无法进行任何交互（不含节点自身定义的交互）。limitEdit模式下，允许使用limitFun指定的功能
    mode的优先级高于moveable

## f. moveAble

    当前节点是否能拖拽，boolean类型，默认值为true，可传入flow组件或者flow-item组件，以flow-item组件属性优先。

moveable 的优先级低于 mode。

## g. placeholder

    流程图为空时的提示文字，非必传，默认值为 :请从左侧拖入节点进行组合，开启增长计划。

## h.limitFun

    limitEdit模式下，允许使用的功能,目前只支持工具箱对应五种功能，其中，缩放功能值为scale,缩放至合适大小功能值为suit，自动排版的值为compose，前进/后退功能为back，连线类型的值为line。该值可选，string类型，值为对应功能的字符串，以“，”连接，默认值为''

## i.editFun

    edit模式下，允许使用的功能,目前只支持工具箱对应的四种功能，其中，缩放功能值为scale,缩放至合适大小功能值为suit，自动排版的值为compose，前进/后退功能为back，连线类型的值为line。该值可选，，string类型，值为对应功能的字符串，以","连接,默认值为"scale,compose,suit,back,line"

## j.defaultLineColor

    线条的默认颜色，可选，string类型，默认值为"#7C8BAF"

## k.hightlightColor

    选中状态时线条的颜色，可选，string类型，默认值为"#4D81EF"

## l.disableConnectNode

不能连线的开始节点、结束节点 id 组成的数组，类型为 FlowLinePoint[ ]，默认值为[]

## m.defaultDashLineStyle

虚线的样式，类型为 number[ ]，默认值为[3,6]

## n. canJoinInLink

当前拖动的节点是否能自动加入链路，类型为 boolean，默认值为 true

## o.arrowHeight

箭头高度，类型为 number，默认值为 8

## p.isInCopyState

右击画布空白时，是否显示粘贴按钮(也就是是否能 copy 节点)，类型为 boolean，默认值为 false

## q.testColor

线条测试状态的颜色,类似为 string

# 5.flow-item 组件 props

## a. itemData

    节点自身的数据，类型为FlowNodeItem，必传。

## b. moveAble

    当前节点是否能拖拽，boolean类型，默认值为true，可传入flow组件或者flow-item组件，以flow-item组件属性优先。
    moveable的优先级低于mode。

## c.showFocus

    当前节点鼠标悬浮时是否显示连线的焦点,'0':默认都显示 '1':隐藏顶部焦点 '2'隐藏底部焦点 '3':都隐藏，类型为string

# 6.对外触发的事件

## a. dropItem

    拖拽节点并在画布上释放时触发，第一个参数参数为FlowDropParams<your type>,结构如下:

export interface FlowNodeLayout<T = number> {
x: T
y: T
}
export interface FlowDropParams<T = string > {
data: T
layout: FlowNodeLayout
}

    其中，data的类型为使用时自定义传入，默认为string，值为拖拽开始事件（@dargstart）时放入事件对象的、经字符串序列化之后的值。
    示例:

第二个参数为 linkPoint，若当前节点坐标在某个链路内，则 linkPoint 有值，类型为 FlowLinePoint，里面是线条开始节点和结束节点的 id；若节点不是在某个链路上松开，则 linkPoint 为 undefined

## b. updateDefaultLayout

    flow组件mounted完成时以及窗口缩放时触发，参数为默认的坐标，类型为FlowNodeLayout。该方法用于传递开始节点的坐标。

## c. hasAddLine

    新生成线条时触发，参数为线条起始节点和结束节点的id，类型为FlowLinePoint，结构如下:

export interface FlowLinePoint {
startId: string
endId: string
}

## d. deleteLine

    在删除线条时触发，参数为线条起始、结束节点的id组成的数组，类型为FlowLinePoint[]

## e. rejectConnect

    连接不能连接的节点时触发，参数为对应的开始、结束节点id，类型为FlowLinePoint

# 7. 对外暴露的事件

## a. refreshFlowLayout

需外部组件手动调用，当进入界面之后,如果 flow 组件可视区域的宽高有变化，则应调用该方法刷新布局。

## b. connectNodeByLine

需外部组件手动调用，手动连接两个节点。参数为线条起始节点和结束节点的 id 组成的数组，类型为 FlowLinePoint[]

## c. replaceNodeId

需外部组件手动调用，替换某个节点的 id,，第一个参数为旧 id，第二个参数为新 id,类型均为 string

## d. initLineListData

需外部组件手动调用,重新绘制线条

## e.deleteLineByNode

需外部组件手动调用，参数为起始节点、结束节点组成的数组，类型为 FlowLinePoint[]

## f. copyNode

复制某个节点的数据，默认向右偏移 30px，参数为要复制的节点的 id 和新的 id，类型为 string

## g. joinItemInLink

从左侧拖拽节点新增时，若该节点松开位置在某链路上且该节点可以加入当前链路，请调用此方法，参数为当前节点的 id

## h.setLineTestByNode

将线条颜色设置为测试状态的颜色，第一个参数为线条所在的节点 id，类型为 string[]，第二个参数为是否测试状态，默认为 false

# 8.完整使用示例（示例 demo 的节点的模型为 ItemData）

## a. 界面部分

<flow :is-drag-item="isDragItem" :list-data="listData" @dropItem="dropItem">
<flow-item v-for="item in listData" :key="item.id" :item-data="item">
<item-component :item="item"></item-component>//自定义的节点，flow 组件不会影响该组件的交互
</flow-item>
</flow>

## b. dropItem 事件

public dropItem(item: FlowDropParams<ItemData>) {
this.listData.push(createItem<ItemData>(item.data, item.layout, `${Math.random()}`, 120, 48))
}

## c. 数据定义

public listData: FlowNodeItem<ItemData>[] = []
public isDragItem = false

interface ItemData {
id: number
label: string
type: string
}

interface FlowLineItem {
originId: string
targetId: string
originDirection: number
targetDirection: number
path: Path2D | null
type: string
lineStyle: string
lineLayout: FlowNodeLayout[]
}

# 9.注意事项

## a. 自定义节点内容不能阻止冒泡的事件

    因flow组件使用鼠标mouse系列事件完成拖拽，所以如需正常使用flow组件功能，请不要在传入的节点组件上绑定阻止冒泡的mouseup、mousedown、mousemove等事件。且为了避免逻辑冲突，尽量不要给节点绑定这些事件。

## b.为兼容火狐浏览器，节点自身的拖拽使用了 mouse 系列事件，因此，节点自身的 click 事件在捕获阶段被阻止了无法触发，所以节点上的 click 事件请替换为 mouseup 事件

## c.

    你的支持是对我们最大的鼓励，给个五星吧亲~~

updatetime:2020-8-25
