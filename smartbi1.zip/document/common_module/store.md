<!-- @format -->

所在目录:src/store

# 1 api

一般放封装好的各项目的 http 请求

# 2 model

放各项目中定义的数据结构和变量类型

# 3 modules

放置各项目中定义的 store 实例

# 4 net

放置请求相关的模块

## 4.1 net/modules/\*

登录业务和 http 请求相关的模块

### 4.1.1 config

http 请求相关的一些数据和模块，包括:
token 相关的一些方法，包括启动定时器、停止定时器、写入 token、获取 token 等
目前与后端约定、不执行公共异常逻辑的 code 值

### 4.1.2 crypto

用于登录的请求模块，因为登录数据需要加密，相关秘钥放在了请求头上，所以单独封装了该模块

### 4.1.3 download

下载文件的方法，参数是文件在服务器上的路径及文件名，原理是请求二进制流的文件数据，在客户端生成该文件流的临时地址，通过 a 标签的默认行为下载文件。

### 4.1.4 loading

封装 http 请求的一个模块，包括对响应和请求的封装，在 http 请求响应之前会出现全局的过渡弹框，并对弹框的出现做了防抖处理

### 4.1.5 loop

封装 http 请求的一个模块，包括对响应和请求的封装，在 http 请求响应之前不会出现全局的过渡弹框

### 4.1.6 xhr

初始化 axios 实例的模块

### 4.1.7 auth

与登录相关的一些业务数据和方法，因为后续的请求与这些数据相关，所以也放 net/目录下，包括存储在客户端的数据的 key 以及封装的对应的读取操作

### 4.1.8 deprecatedFetch

封装的一些参数为表单的 api，包括:
deprecatedFetch:参数为表单格式，默认代理到当前项目 deprecatedFetch<dataType>(url,params,'get'/'post')

deprecatedFetchByProject:参数为表单格式，代理到第二个参数对应的项目上 deprecatedFetchByProject<dataType>(url,'reportplat',params,'get'/'post')

deprecatedLoop:参数为表单格式 deprecatedLoop<dataType>(url,params,'get'/'post')

multipleUpload:上传文件，代理到当前项目 multipleUpload<dataType>(url,files)

multipleUploadLoop:文件上传，默认代理到当前项目 multipleUpload<dataType>(url,files)

## 4.2 net/io

建立 websocket 连接的模块

updatetime:2020-11-3
