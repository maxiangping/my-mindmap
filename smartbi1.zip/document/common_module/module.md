<!-- @format -->

所在目录:src/apps_modules

# 1.crypto

提供加密的一些算法，包括:aes 加密，获取随机数的 uuid 等

# 2.dom

提供一些 dom 操作的 api，如制定部分属性的 createElement，派发事件的 dispatchEvent,dispachTouchEvent，创建 iframe 的 createIframe 等

# 3.functor

提供一些工具函数，如 deepCopy、throttle 等

# 4.fusionchart

fusionchart 组件的入口，根据项目需要声明和定义了一些 fusionchart 的配置和处理方法

# 5.grid_layout

vue-grid-layout 组件的重构，对组件内容渲染时机做了处理，只有组件坐标确定之后才渲染内容。

# 6.jsbridge

在项目页面内部，如果需要对手机系统暴露方法，在 globalfun 内注册，注册的事件将通过全局模块暴露出来

# 7.jsencrypt

用于 aes 和 res 加密

# 8.observer_zone

声明一个 map 对象用于存储数据。
使用场景:在一些数据较大的情况下，如果不需要对数据的每个键值对做监听，只需要渲染，如果放在组件的 data 里，会造成无谓的性能消耗，所以通过 map 对象来存储数据，通过 key 来取值

## 提供一个 Map 对象的缓存机制

### syncToZone

保存对象到缓冲区

```
值得注意的是:key = `zone-key-${__zone.size}` key用__zone.size这种方式并不安全，会出现key重复的情况。最好使用随机数
```

### readZone

根据 key 获取缓存对象

### freeZone

释放缓存

### class Zone

将缓存区私有化，只暴露方法 copyZone、freeZone。这样做更安全

# 9.slideshow

图片碎片化过渡效果的插件，用于多媒体展示项目的动画

# 10.socket_zone

用于存储 websocket 数据的一个 map 对象，通过 Key 获取数据，实例保存在 store/Socket 的 dataMap 属性上，当前的 websokcet 请求的 key 保存在 store/Socket 的 key 属性上

# 11.task-manager

用于大屏图表数据处理的任务管理器。指定任务执行的间隔及对应的处理函数，将按照指定的间隔按顺序执行各任务

## addTask

参数为执行间隔、处理函数、初始数据。功能为添加处理函数，返回值为任务名称

## removeTask

参数为任务名称，功能为移除对应的处理函数

# 12.toolbox

一些工具函数、fusionchart 的配置数据等等

## 1.asset

定义 Icon 组件,图片的名字和对应的路径也声明在这，主要用于图片展示，后面因新增了 v-asset 指令，现该组件建议不使用

## 2.list

数组相关的工具函数将放在

### replaceMembers

将数组的某个值替换为新值

### toogleMembers

如果数组中有某个值，则删除；如果没有则增加。类似 classlist 的 toogle

## 3.math

纯数学的一些工具函数，包括: 1.求最大公约数; 2.求最小公倍数; 3.判断某个值是否在某个区间; 4.根据基准值和步长四舍五入/向下/向上取整; 5.根据步长和基准值得到等差数组; 6.判断两个矩形是否相交等等; 7.根据关系类型对应的含义判断两个值的关系; 8.计算点到直线的距离; 9.判断点是否在二次贝塞尔曲线上;

## 4.runtime

一些项目中使用的枚举值

### PROJECT

当前的项目名称，用于在 main.ts 中注册对应的获取菜单数据的参数

### MEDIA_SCREEN

一些屏幕尺寸，用于媒体查询样式的使用

## 5.timestamp

用于时间格式字符串的一些方法

### timestampMMSS

返回当前，用对应字符串分隔的 分钟 : 秒 的值

### timestampHHMMSS

返回对应时间(默认当前时间)，用对应字符串分隔的 小时 : 分钟 :秒 的值

### diffTimestampHHMMSS

传入一个时间间隔、分隔字符串、特定时间(默认当前时间)，返回特定时间加上时间间隔的时间值并用对应的字符串分隔的 小时 : 分钟 :秒 的值

# 13.x_spreadsheet

在线编辑 excell 的插件，中式报表依赖于这个插件

# 14.mindmap

在线编辑思维脑图的插件，君智知识 pad 依赖于这个插件 对应的测试页面在 @/apps/app_kmind/views/testG6

# 15.t_map

腾讯地图插件，君智问卷后期地图定位会用这个插件，对应的测试页面在 @/apps/app_kmind/views/mapTest

updatetime:2021-12-29
