<!-- @format -->

所在目录:src/apps/mixins

# 1.dialog

请求异常时出现的弹框组件，由 store/Dialog 中的 showDialog 属性控制，包含 confirm 和 cancel 两个回调

# 2.explorerControl

控制左侧菜单栏是否显示。在 mounted 中隐藏，beforeDestroy 中默认显示
示例:src/apps/app_reportplat/views/datasource/panel_board/edit/edit_area_section/edit_head/cardBoxController.ts

# 3.functor

部分工具函数，放在这个 mixins 中方便在组件中使用

# 4.loading

在 http 请求时出现的过渡动画，由 store/loading 中的 abortLoading 属性控制

# 5.routeHooks

路由变化时的钩子，包括 beforeRouteLeave 和 beforeRouteEnter。在手动执行路由对象的 push 或者 replace 方法时，在 beforeRouteLeave 中判断当前路由是否有权限跳转到目标路由上，在 beforeRouteEnter 中判断进入路由时，菜单数据如果为空则跳转到登录页。
示例:src/apps/app_reportplat/views/datasource/panel_board/cardBoxController.ts

# 6.socket

为使用 websocket 功能开发的一个组件，websocket 的相关数据放在了 store/socket 中，业务组件通过 wsSendRequest 方法发送请求，并在 store/socket 获取数据

## 使用方式

组件直接混入 socket 组件
示例:src/apps/app_reportplat/views/datasource/data_collection_list/edit/edit_section/code_mirror/cardBoxController.ts

## 发送请求

this.ws.wsSendRequest(params,project).
注意，同一个会话发起的 websocket 通信不要携带 toUser 参数，并且需要携带 id 区分各个请求的相应。

## 接收数据

监听 SocketStore 的 currentKey 属性，currentKey 是入参中的 id 属性。
通过 SocketStore 的 currentDataMap 属性，获取存储实际数据的 map 对象，通过 map 对象的 take(id,defaultValue)方法获取该 id 对应的数据

参考:

```
  @Watch('currentKey')
  public getFieldData(id: string) {
    const fieldData: TableField[] = this.currentDataMap.take<TableField[]>(id, []) ?? []
  }
```

# 7.BuriedPoint

为实现埋点统计开发的一个组件，在进入一些页面时，需要触发埋点，所以在该组件的 mounted 钩子中调用了触发埋点的逻辑，埋点数据类型需要在对应的组件上用 pointType 属性指定

# 8.chart.mixins

仪表板作为看板在其他项目中使用时，该组件可作为处理仪表板相关数据的功能组件。

## 初始化仪表板数据

获取到仪表板的数据之后，调用 chart.mixins.ts 内的 handleBoardData 方法，可将数据初始化为可用的数据

## 事件监听

其他项目嵌入仪表板，需要在 chart-area 组件上监听 setFieldRangeMap 及 pageChange 方法，处理函数调用 chart.mixins.ts 内的同名函数即可

## 过滤条件

如果看板有过滤条件，那么在过滤条件对应的 change 事件上调用 changeFilters 方法，该方法有三个参数，分别为(字段别名，当前的值，值绑定的 key)
第三个参数:值绑定的 key，对应关系如下:
输入框/单选框/非范围的时间选择框等单个值的，key 为 value，
数字范围输入框，key 为 valRange
多选框，key 为 valList
时间范围选择框，key 为 date

参考:src\apps\app_crm\views\active_plane\parts\promote_board\cardBoxController.ts

```
    this.changeFilters('时间', date, 'value')
```

# 9.formValidate

商机中心项目及精准营销项目部分表单生成校验函数的一个工具函数，因为 vue 中 this 实例的绑定问题，暂时将表单数据绑定的对象和 key 写死

# 10.antvG6Mixin

antv-g6 插件的一个公共混入， 里面有一些公共逻辑的处理 ，计算图表框的大小:initViewSize 并依赖于 mount-node 这个样式；还有一些公共的节点收缩 COLLAPSE_ICON 展开 EXPAND_ICON 按钮；初始化加载 g6.min.js；

# 11.goBackService

返回按钮的处理逻辑，点击返回是否要弹出保存弹框，基本原理是在进入页面的时候将要保存的对象转成字符串，调用 setInitData 方法初始化 Json 字符串，在点击返回的时候调用 hasUpdateParams 方法传入新的字符串, 判断该字符串是否和初始化的字符串相等, 如果不相等说明有修改，就弹框提示是否要保存

# 12.questionnairePreviewMixin

问卷预览的混入，检查连接是否正确，并获取问卷详情

# 13.widgetToImage

图表生成图片的混入。在知识 pad-简报版-左侧数据源中拖拽图表-渲染图表-生成图片-渲染到节点

# 14.WidgetToImageData

图表生成图片的抽象方法，在 widgetToImage 中引入。
提供两个方法:

### 1.getWidgetImageUrl 根据 dom 节点和样式，获取缩略图

### 2.setChartSize 根据图表类型设置图表大小

updatetime:2020-12-29
