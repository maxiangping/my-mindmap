项目公共组件分为两部分，一部分是与业务关联性不强的组件，目录为src/components;另一部分是可能在多个项目中使用的，和业务关联性较强的组件，目录为src/apps/components
# 1 路径
 src/components

# 2 组件说明

## 1 material_icon
带名称的icon组件

## 2 CircularBar
圆环(中心为百分比和文字)组件

## 3 Dialog
公共弹框组件，目前用于接口异常时的提示

## 4 dynElement
对vue的render方法做的一个简单的包装，根据传入的标签类型渲染对应dom

## 5 Field
封装的一个表单组件

## 6 Icon
封装的一个icon组件（目前大部分场景可被v-asset取代），提前注册icon路径，通过name指定加载的icon，通过size指定尺寸(实际的尺寸为传入尺寸的80%)

## 7 IconButton
封装的一个支持前置icon的按钮组件，后置按钮可旋转角度（类似下拉框）

## 8 IPhone
模拟的一个手机界面，目前在移动bi项目及报表平台的仪表板有使用

## 9 Loading
发送http请求时界面出现的过渡动画组件

## 10 Pad
模拟的一个pad界面，目前报表平台的仪表板有使用

## 11 Player
封装的一个视频列表组件

## 12 Rotate
封装的一个可旋转的组件，传入的angle值为旋转的角度(用css3的rotate属性实现)

## 13 Sized
封装的一个布局组件，与屏幕同等大小

## 14 Tab
封装的一个左右边距为2em、上下边距为0的组件，一般作为TabMobile组件的内容组件，内容为传入tab值

## 15 TabBar
封装的TabMobile组件的头部组件

## 16 TabMobile
封装的一个适配移动端的页签组件，一般放在手机顶部作为菜单栏

## 17 Thumb
封装的一个滚动条组件

## 18 XScroll
TabMobile组件控制顶部栏，封装了点击切换下拉框的显示/隐藏状态的功能
