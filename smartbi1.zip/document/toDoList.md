# 1. 骨架屏方案

# 2. 首屏优化

# 3. css体积优化

# 4. vue3的代码规范

# 5. 常规代码规范



**make the camp cleaner than when you came**
updatetime:2020-11-4

# ! never stop !
