<!-- @format -->

bi:移动 BI 项目

controlcenter:展示厅的多媒体展示项目的控制中心 //开发分支:feature/control/v1.0.1

crm:精准营销项目

dashboard:大屏项目 //开发分支:dashboard/dev

home:营销中枢项目

kmind:君智项目

reportplat:报表平台项目

system:后台系统项目

datagrip:客户视图项目

managercrm:商机中心项目

boardshare:看板分享项目

updatetime:2020-12-22
