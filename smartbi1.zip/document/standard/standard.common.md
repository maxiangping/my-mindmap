<!-- @format -->

# 1. 组件导入/导出

**组件导入/导出不要直接通过.vue 文件，放在一个 ts 文件中导出这个组件，需要导入也通过这个 ts 文件**

## 解释:

组件作为一个整体，.vue、.less、.ts 文件等都是组件的一部分，对外应暴露为一个整体而非直接暴露部分文件。

# 2. 文件/文件夹/静态资源命名

**文件夹命名使用下划线*分隔，文件命名使用小驼峰命名，静态资源命名使用下划线*分隔**

# 3. components 目录

**某页面文件目录内不要出现 components 目录**

## 解释:

目前工程内 components 目录有三级，src/components 存放和项目关联性不强的公共组件，src/apps/components 存放项目公共功能相关的组件，src/apps/yourproject/components 存放某个项目自己的公共组件。因此，某页面内的组件应都为该页面的布局组件/功能组件，如需抽取为公共组件应放在对应的公共 components 目录下

# 4. 全局共享的数据使用枚举

**全局共享的数据和变量(和具体某个项目无关的)，使用的时候写枚举值，而不是写实际的属性值**

## 解释:

项目中目前有一些公共数据，比如项目名称、登录页的路由、登录之后保存的 token 的 key 等，使用枚举值而不直接写属性值。
从代码可读性考虑，将一组值声明为枚举值，方便追溯数据来源，可读性比直接写属性值强（直接写属性值，不写注释的话不知道该值的含义）。
从可维护性的角度考虑，枚举值方便修改，只需在声明处修改，不需要在每个使用的地方修改。
从健壮性的角度考虑，直接写属性值可能会写错单词，ts 的智能提示可以避免这个问题。

示例:

```TypeScript
//src\apps\foundation\constant.ts
const enum GlobalVariable {
  AUTH_FAILED_URL = '/auth_failed',
  AUTH_FAILED_TEMP_URL = '/auth_failed_temp',
  BOARD_SHARE_AES_KEY = '91016ece016543b584f48e0666678cc7',
  HTTP_HEADER_ORIGIN = 'CredEx',
}


```

# 5. 组数据尽量使用枚举

**一组相关联的数据，比如某个状态的值，某个类型的值等，声明为枚举值，而非直接在使用的时候写实际的属性值**

## 解释:

优点同第 4 点。另外:
一组值是互相关联的，应作为一个整体考虑。同时，声明为一组枚举值，写注释也方便，可以互相参照。

示例:

```TypeScript
export const enum NodeDefineType {
GeneralNode = 0,
StartNode = 1,
EndNode = 2,
HeavyChildNode = 3,
ChannelNode = 4,
HeavyNode = 5,
HistoryNode = 6,
BranchNode = 7,
BranchChildNode = 8,
}
```

# 6.

updatetime:2020-11-3
