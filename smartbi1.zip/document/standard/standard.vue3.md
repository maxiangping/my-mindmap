<!-- @format -->

# 1. 父子组件通信的事件名使用 kebab-case(中划线分隔的小写单词)

## 解释:

按照 vue 最新的文档解释，在 dom 中的事件监听会自动转换为小写，且事件名称不会用作变量名或属性名，所以使用分隔符分隔小写单词，推荐使用中划线分隔。

# 2.provide/inject 的 key 使用 Symbol

## 解释:

每次实例化出来的 Symbol 值，即使描述符相同，结果也不同，可以最大程度保证 key 的唯一性。
示例:

```javascript
const key1=Symbol('data1')
const key2=Symbol('data1')
key1 === key2 //false

//父组件
provide(key1, parentData);

//子组件
inject(key1, defaultValue)

```

# 3. 不要使用解构赋值获取 reactive 的子属性值

## 解释:

用解构赋值获取 reactive 变量的子属性，会丢失响应性。所以在取值或者传递进其他组合函数时，要么传递整个 reactive 对象，要么使用 toRefs(obj)将对象的属性转换为 ref。

示例:

```javascript
const a = reactive({count:0})
//丢失响应性
const {count: b} = a
a.count++
console.log(b) // 0
console.log(a.count) // 1

//保持响应性
const {count:c}=toRefs(a)

a.count++
console.log(c.value) // 2
console.log(a.count) // 2

c.value++
console.log(a.count) // 3
console.log(c.value) // 3

// 组件
setup(){
    const a = reactive({count:0})
  //...

  //good
  return {
    a
  }
  // or
  return {
    a:toRefs(a)
  }

  //bad
  return {
    ...a
  }
}
```

# 4.

updatetime:2020-11-4
