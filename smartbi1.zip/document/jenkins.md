<!-- @format -->

# linux 下启动停与停止 jenkins (systemctl 模式)

```bash

systemctl start jenkins
systemctl stop jenkins

```

## 将本地 node_modules 上传到 linux 服务器

```bash

#将本地node_modules全量压缩，非全量(隐藏文件和以.开头的文件)将无法使用
tar -czf ../node_modules.tar.gz .
#拷贝node_modules压缩包到服务器(需要输入密码)
scp ../node_modules.tar.gz root@172.16.163.2:/var/ftp/pub

#登录服务器，并进入到对应的目录
mkdir node_modules
tar -xzvf node_modules.tar.gz -C node_modules
ln -s /var/ftp/pub/node_modules /var/lib/jenkins/workspace/BUILD_CRM

```

## jenkins 主要构建脚本

```bash

  # 授权jenkins目录权限
  chown -R jenkins:jenkins /var/ftp/pub/node_modules;

  # 将 node_modules 目录以软连接方式，连接到jenkins当前工作目录
  ln -sf /var/ftp/pub/node_modules $WORKSPACE;

  cd $WORKSPACE;

  # 导出 node 和 yarn 环境变量
  export PATH=$PATH:/usr/node-v14.6.0-linux-x64/bin:/usr/yarn-v1.22.4/bin;


  # 设置变量， PROJECT 变量是 jenkins Build with Parameters 中的选项参数，主要提供当前构建所需的信息
  PN=build_${PROJECT};

  # 使用 yarn 命令运行构建
  yarn run $PN;

  # 设置变量
  FTP_PUBROOT=/var/ftp/public_root/apps;

  # 设置变量
  TARGET_DIR=$FTP_PUBROOT/${PROJECT};

  # 打印信息
  echo $TARGET_DIR;

  # 判断目录是否存在
  if [ -d "${TARGET_DIR}" ]; then
    # 删除目录
    rm -rf $TARGET_DIR;
  fi

  # 移动构建好的目录到nginx指定目录下
  mv -f $WORKSPACE/built/$PROJECT $FTP_PUBROOT;

```
