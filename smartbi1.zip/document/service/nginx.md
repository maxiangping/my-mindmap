<!-- @format -->

# 各环境的服务器配置文件地址

项目服务器地址:172.16.163.2
账号:root
密码:qmcAZjxI3n

## 内部系统开发环境 (访问地址:http://172.16.163.2:9999/项目名称)(对应后台:172.16.163.4)

/etc/nginx/conf.d/apps.dev.9999.conf

## 内部系统测试环境 (访问地址:http://172.16.163.2:20000/项目名称)(对应后台:172.16.163.42)

/etc/nginx/conf.d/apps.testing.20000.conf

## 华夏项目开发环境 (访问地址:http://172.16.163.2/项目名称)(对应后台:172.16.163.8)

/etc/nginx/conf.d/apps.conf

## 华夏项目测试环境 (访问地址:http://172.16.163.2:30000/项目名称)(对应后台:172.16.163.43)

/etc/nginx/conf.d/apps.testing.30000.conf

## 演示环境(数字展示厅) (访问地址:http://172.16.163.2:10000/项目名称)(对应后台:172.16.163.2:18088)

/etc/nginx/conf.d/apps.10000.conf

## 中式报表开发环境 (访问地址:http://172.16.163.2:40000/项目名称)(对应后台:172.16.163.8)

/etc/nginx/conf.d/apps.dev.40000.conf

## 损益报表开发环境 (访问地址:http://172.16.163.2:41000/项目名称)(对应后台:http://172.16.163.8:11109)

/etc/nginx/conf.d/apps.dev.41000.conf

## 华夏大屏开发环境 (访问地址:http://172.16.163.2:42000/项目名称)(对应后台:http://172.16.163.8:11003)

/etc/nginx/conf.d/apps.dev.42000.conf

## 中式报表测试环境 (访问地址:http://172.16.163.2:50000/项目名称)(对应后台:172.16.163.8)

/etc/nginx/conf.d/apps.test.50000.conf

## 君智开发环境 (访问地址:http://172.16.163.2:60000/项目名称)(对应后台:172.16.163.4)

/etc/nginx/conf.d/apps.dev.60000.conf

## 精准营销 3 开发环境 (访问地址:http://172.16.163.2:61000/项目名称)(对应后台:172.16.163.4)

/etc/nginx/conf.d/apps.dev.61000.conf

## websocket 连接的配置地址 (访问地址:无)

/etc/nginx/conf.d/socket.conf

## ftp (访问地址:http://172.16.163.2:8100)

/etc/nginx/conf.d/ftp.conf

## 配置文件说明及示例 (访问地址:http://172.16.163.2:8200)

/etc/nginx/conf.d/deploy.conf

# nginx 配置说明

## http 服务

### 服务初始化

参考:/etc/nginx/conf.d/apps.conf
请求头里面的属性，浏览器默认会携带(属性名由字母、数字、下划线组成)
如果属性名包含特殊字符(如中划线)，需要在下面的配置添加(如下面的 my-header)

```
server {
    listen       80; //监听的服务器端口 (服务器端口默认是80，浏览器默认是8080)
    listen       443 ssl http2;
    server_name  visual.ngx.com;

    charset UTF-8;

    ssl_certificate       /root/apps/nginx/ssl/agsenterprise.crt;
    ssl_certificate_key   /root/apps/nginx/ssl/agsenterprise.key;
    ssl_session_cache    shared:SSL:1m;
    ssl_session_timeout  5m;
    ssl_ciphers          HIGH:!aNULL:!MD5;
    ssl_protocols        TLSv1 TLSv1.1 TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers  on;
    my-header                  on;//请求头需要携带的特殊属性

    root     /var/ftp/public_root/apps;  // 读取前端资源的目录
}
```

## 项目入口配置

默认获取 index.html 作为项目入口，以及处理 options 请求

```
    location ~ /(home|crm|reportplat|datagrip|system|controlcenter) {
        if ( $request_method = 'OPTIONS' ){ //处理options请求
            include /root/apps/nginx/conf.d/proxy.options.conf;
            return 200;
        }

        include /root/apps/nginx/conf.d/proxy.document.conf;

	      index /$1/index.html;
        try_files $uri /$1/index.html;
    }
```

## http 请求配置

在项目中，为了转发对应项目的请求，在请求路径前面，需要使用 joinBaseUrl 方法(添加当前项目路径)或者 joinProjectUrl 方法(添加指定项目路径)为请求路径添加特殊前缀。如在 reportplat 项目

const url=joinBaseUrl('aaa/getData') // reportplat_api/aaa/getData

使用参考: src\store\api\modules\reportplatform\base.ts

```
    location ^~ /crm_api/ {  // ^~ /正则/ 用来匹配需要转发的http请求。
        proxy_pass   http://172.16.163.4:8999; //需要转发请求到目标服务的地址

        include /root/apps/nginx/conf.d/proxy.conf; //需要携带的一些公共请求头
        # 利用正则进行匹配
        rewrite      ^/crm_api/(.*)$ /$1 break; //重写请求路径，把特殊前缀去掉
    }
```

## 静态资源请求

图片等存储在服务器的静态资源，也需要通过 nginx 转发。在项目中，可以使用 joinStaticUrl 方法在静态资源路径前加/oss/项目名称的前缀，使 nginx 能够匹配对应的静态资源请求。如在 crm 项目中

const url=joinStaticUrl('aaa/bbb.png') // /oss/crm/aaa/bbb.png

使用参考 :src\apps\app_reportplat\views\datasource\panel_board\edit\edit_area_section\image_widget\cardBoxController.ts line:62

```
    location ^~ /oss/crm/ { // ^~ /正则/ 用来匹配需要转发的http请求。
        proxy_pass   http://172.16.162.42:8999; //需要转发请求到目标服务的地址

        include /root/apps/nginx/conf.d/proxy.oss.conf; //需要携带的一些公共请求头

        rewrite      ^/oss/crm/(.*)$ /$1 break;  //重写请求路径，把特殊前缀去掉
    }
```

## websocket 服务

在项目中有大量场景使用到了 websocket(数字展示厅，数据集管理中的 sql 数据集，客户视图的客户分群页面等)。使用 getWebsocketInstance 方法初始化 websokcet 连接时，通过传入的项目名称参数，将 socket 连接代理到对应的服务
websocket 组件的使用说明，详见 common_module/mixins.md/6.socket

### 服务初始化

```
upstream websocket_testing_crm { // 这是声明的websocket代理项的名称，需要保证各个名称都不同
    #ip_hash;
    #转发到服务器上相应的ws端口
    server 172.16.162.42:8999; // 需要转发websocket连接到目标服务的地址
}

```

### websocket 连接

通过特殊前缀，拦截 websocket 连接，转发到对应的服务上。
websocket 默认会连接当前项目的服务，如果要连接其他服务，请在组件中调用 initSocketInitiative(project)方法。
特殊的 websocket 使用参考:src\apps\mixins\socket.ts

```
    location ^~ /reportplat_api/system/websocket { // reportplat_api是特殊前缀，用于匹配连接。system/websocket是实际的websocket连接路径
        proxy_pass http://websocket_testing_reportplat/system/websocket; // websocket_testing_reportplat是websocket代理项的名称，后面的是websocket的连接路径
        include /root/apps/nginx/conf.d/proxy.socket.conf;
    }

```

# 手动重启 nginx

如果需要修改 nginx 的配置文件，那么在修改之后
1 执行 "/sbin/nginx -t" ,若输出信息中带有 "test is successful" 字样,则表明 nginx 配置正确，该配置可以使用,否则配置错误，需要检查 nginx 的配置项
2 执行 "/sbin/nginx -s stop ". 停止 nginx 服务
3 执行 "/sbin/nginx". 启动 nginx 服务

updatetime:2021-04-07
