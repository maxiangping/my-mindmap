# 控制页

src\apps\app_controlcenter\views\control
在进入控制页和展示页时，都会自动登录，并且默认是用controlcenter这个用户登录的，所以每次更新环境需要保证这个用户存在且有权限。
在控制页面的首页，有项目视频播放/音量调节/项目/回到首页功能，点击项目时，会进入这个项目对应的ppt的第一页，通过翻页切换上一页/下一页。
点击视频播放时，另一个屏幕展示对应的视频并自动播放。
点击项目演示的按钮时，另一个屏幕进入对应的登录页。
通信通过websocket实现，参数为:
```typescript
    const params: SocketParams = {
      jsonParam: JSON.stringify(video ? `video-${video}` : project),
      id: project,
      toUser: 'controlcenter',
    }
```
jsonParams表示参数，是视频播放还是跳转到某个项目，id是项目名称，toUser是发送给谁，如果没有这个参数，那么会发送给自己。

# 展示页

展示页一是播放视频，二是让用用户实际体验项目。
因为屏幕都是触摸屏，没有drag系列的事件，所以一些drag的交互用了v-touch指令做了兼容，用touch触发，再手动的合成drag事件，实现原有的功能。
指令逻辑在src\apps\framework\directives\v\vTouch.ts

在控制页，监听websocket的信息，执行后续的逻辑
```typescript
  @Watch('currentKey')
  public changeRouter(val: string) {
    if (isEmpty(val) || val === 'empty') return
    if (val === 'controlcenter') {
      this.showVideo = false
      this.videoSrc = ''
    } else if (val.startsWith('video-')) {
      this.videoSrc = `video_${val.split('-')[1]}`
      this.showVideo = true
    } else {
      window.location.href = `${window.location.origin}/${val}${GlobalVariable.AUTH_FAILED_TEMP_URL}?isControl=1`
    }
  }
```
