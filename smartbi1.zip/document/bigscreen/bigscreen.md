<!-- @format -->

# 项目信息

大屏和多媒体互动演示系统的代码均在 git 仓库:可视化大屏的 bigscreen/dev 分支内，部署在 172.16.163.2 上，前端访问地址是 172.16.163.2:10000
其中，大屏对应的后台是 172.16.163.2:8080(演示环境)，该版本的后台代码是很早的，后续没有变化过，登录相关流程也是之前的，所以这块不能合并。

# websocket 通信

因为需要在 ipad 上和大屏界面通信，所以用 websocket 用于端到端的通信。
ipad 控制界面:src\apps\app_dashboard\views\central\index.ts

基本流程是，在 ipad 的控制界面操作，发送 websocket 信息，数据格式为

```typescript
export interface SendJsonId {
  id: string
  currentPage: string
  event: string
  option: SendOption
}

```

currentPage 是当前 ipad 要控制的页面，event 是事件类型，option 是具体的选项，id 是唯一标识，只是用于请求的区分。

而大屏也有一些消息要发送到 ipad，主要是缩略图、以及交互的确认。因为 websocket 的通信有延时，所以用了 3 秒作为每次请求的间隔。如果一个操作发送了 websocket 且没有对应的确认信息返回，那么 3 秒内不会再次触发 websocket。
大屏发送到 ipad 的数据格式为

```typescript
export interface SendOption {
  chartIndex?: string
  filed?: string
  methodName?: string
  value: string
}
```

其中，methodName 用于区分操作类型，value 为具体的值，chartIndex 为可能要操作的图表，filed 为文件信息。
大屏的页面和 websocket 相关的逻辑位于 src\apps\mixins\centralSocket.ts 内。
大致流程是:
websocket 接收到信息，然后在 handleEvent(data: SendJsonId) 事件内根据事件类型做一个分发处理，每一种事件，公共逻辑会对应的方法，某个图表自身的特殊逻辑，可以在对应的组件内部写同名方法覆盖处理，或者预留前置/后置的逻辑入口。
如全屏的功能:

```typescript
    this.changeChartConfigBeforeFullScreen?.(params)
    this.fullScreenEvent(params)
```

# 地图组件

目前的首页，是在 src\apps\app_dashboard\views\home_new_2 内，地图组件在 src\apps\app_dashboard\views\home_new_2\part\content_head\part\head_map。
地图有下钻和上卷的功能，大致流程就是，页面加载时默认是全国地图，点击某个省份，会加载对应的省份地图，点击回到全国，会加载全国地图。
全国地图和省份地图分别用两个不同的实例展示，用 v-if 来控制。
provinceId 属性表示当前的省份 id,如果是全国地图，则该属性为''。
通过 provinceId 自动更新对应的省份配置数据，全部的配置数据在
src\apps_modules\fusionchart\config.ts\ZHCN_PROVINCE 对象内。
省份数据:

```typescript
  TA: {
    label: '台湾省',
    id: 'taiwan',
    position: [0, 0],
    cities: {},
  },
```

label 是中文名，id 是省份 id,这个 id 也会作为该省份地图对应的 chartType(每个省份对应一个 chartType)，position 是坐标，即该区域的中心坐标，用于地图上标记的定位，cities 是该省份的城市数据。
城市数据的格式为:

```typescript
      11: {
        label: '昌平区',
        posisiton: [186.5, 261.2],
      },
```

其中，11 是城市 id，这个 ids 是每一个城市数据的 id，在地图数据上，fusionchart 根据这个 id 找到对应的城市，不可修改。position 是坐标，用于地图上标记的定位。

# threejs

客户视图-经营贷和房产视图使用了 threejs 进行模型渲染，主要方法放在了 src\apps\app_dashboard\common\tool.three.ts 内。有一个需要注意的是，加载模型文件时，threejs 对象使用的是全局的绝对路径加载资源的，不会被 webapck 的编译影响，所以资源要放在 public 目录下，目前 loadSource 方法加载资源的根目录是 public/model，所以资源最好都放这。
