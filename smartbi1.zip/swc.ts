/** @format */
import type { JscConfig } from '@swc/core'

const jsc: JscConfig = {
  parser: {
    syntax: 'typescript',
    tsx: true,
    decorators: true,
    dynamicImport: true,
  },
  baseUrl: '.',
  loose: false,
  externalHelpers: true,
  transform: {
    legacyDecorator: true,
    decoratorMetadata: true,
    react: {
      runtime: 'automatic',
      importSource: '@lancercomet/vue2-jsx-runtime',

      throwIfNamespace: false,
      useBuiltins: false,
      // To use preact/jsx-runtime:
      // importSource: "preact",
      // runtime: "automatic"
    },
  },
}

export const jscGenerator = (isProd: boolean): JscConfig => {
  const prodProps = {
    target: 'es2017',
    minify: {
      compress: {
        defaults: false,
        drop_console: false,
        drop_debugger: false,
      },
    },
  }
  return Object.assign(jsc, isProd ? prodProps : { target: 'es2020' })
}
