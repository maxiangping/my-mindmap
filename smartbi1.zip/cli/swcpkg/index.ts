import type { FilterPattern } from '@rollup/pluginutils'
import { createFilter } from '@rollup/pluginutils'
import type { Options as SwcOptions } from '@swc/core'
import { transform as swcTransform } from '@swc/core'
import { resolveId } from './resolve'
import type { Plugin } from 'vite'

export type Options = SwcOptions & {
  include?: FilterPattern
  exclude?: FilterPattern
}

export default function swcPlugin(options: Options) {
  const filter = createFilter(
    options.include || /\.[jt]sx?$/,
    options.exclude ?? [],
  )

  return {
    name: 'vite-plugin-swc-tsx',
    esbuild: false,
    resolveId,
    async transform(code: string, id: string) {
      if (!filter(id)) return null

      const output = await swcTransform(code, {
        filename: id,
        sourceMaps: options.sourceMaps ?? false,
        inlineSourcesContent: options.inlineSourcesContent ?? false,
        ...options,
      })

      const result = {
        code: output.code,
        map: output.map && JSON.parse(output.map),
      }

      return result
    },
  } as Plugin
}
