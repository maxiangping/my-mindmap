/** @format */

import { createHash } from 'node:crypto'
import { join } from 'node:path'
import { access, mkdir, readdir, readFile, writeFile } from 'node:fs/promises'
import { Buffer } from 'buffer'
//use .update(data).digest('base64');

export const hash = (str: string) => {
  return createHash('sha1').update(str).digest('hex')
}

const resolvePath = (path: string) => {
  return join(__dirname, '../../node_modules/.swc', path)
}

const write = async (path: string, content: string) => {
  const filePath = resolvePath(path)

  const cacheDir = join(__dirname, '../../node_modules/.swc')
  try {
    await access(cacheDir)
  } catch (err) {
    await mkdir(cacheDir, { recursive: true })
  }
  try {
    const data = new Uint8Array(Buffer.from(content))
    await writeFile(filePath, data)
  } catch (err) {
    // When a request is aborted - err is an AbortError
    console.error(err)
  }
}

const readAll = async (path: string): Promise<Item[]> => {
  try {
    const files = await readdir(path)

    return files.map((file) => {
      return { file: file, cb: () => readFile(resolvePath(file)) }
    })
  } catch (err) {
    // When a request is aborted - err is an AbortError
    console.error(err)
  }
}
export class Lru<T> {
  private lruCache
  constructor() {
    this.lruCache = new Map<string, T>()
  }

  public has(key: string): boolean {
    const hashKey = hash(key)

    return this.lruCache.has(hashKey)
  }

  public get(key: string): T | undefined {
    const hashKey = hash(key)
    return this.lruCache.get(hashKey)
  }

  public set(key: string, value: T) {
    const hashKey = hash(key)
    this.lruCache.set(hashKey, value)
  }
}

interface Item {
  cb: () => Promise<Buffer>
  file: string
}

function getResult(item: Item) {
  return item.cb().then((content) => {
    return [item.file, content]
  })
}

export class SwcCache<T> {
  private constructor(private swcCache: Map<string, T>) {}

  public static async init<S>() {
    const cache = new Map<string, S>()
    const cacheDir = join(__dirname, '../../node_modules/.swc')
    try {
      await access(cacheDir)
    } catch (err) {
      await mkdir(cacheDir, { recursive: true })
      return new SwcCache(cache)
    }

    const items = await readAll(cacheDir).then((items) => {
      return items.map((item) => getResult(item))
    })

    const res = await Promise.all(items)

    res.forEach(([file, content]: [string, Buffer]) => {
      const value = JSON.parse(content.toString()) as S
      cache.set(file, value)
    })

    return new SwcCache(cache)
  }

  public has(key: string): boolean {
    const hashKey = hash(key)

    return this.swcCache.has(hashKey)
  }

  public get(key: string): T | undefined {
    const hashKey = hash(key)
    return this.swcCache.get(hashKey)
  }

  public async set(key: string, value: T) {
    const hashKey = hash(key)
    await write(hashKey, JSON.stringify(value))
    this.swcCache.set(hashKey, value)
  }
}
