/** @format */

import { access, constants, stat } from 'node:fs/promises'
import path from 'path'
import { Lru } from './lru'

const RESOLVE_EXTENSIONS = ['.tsx', '.ts', '.jsx', '.js', '.mjs', '.cjs']

const pathExist = async (path: string): Promise<string | null> => {
  try {
    await access(path, constants.F_OK)
    return path
  } catch {
    return null
  }
}

const resolveFile = async (resolved: string, index = false) => {
  const files = RESOLVE_EXTENSIONS.map((ext) =>
    pathExist(index ? path.join(resolved, `index${ext}`) : `${resolved}${ext}`)
  )

  return Promise.any(files)

  // for (const ext of RESOLVE_EXTENSIONS) {
  //   const file = index ? path.join(resolved, `index${ext}`) : `${resolved}${ext}`

  //   // eslint-disable-next-line no-await-in-loop
  //   const isexist = await pathExist(file)
  //   if (isexist) {
  //     return file
  //   }
  // }
}

const RESOLVE_CONTROL = new Lru<string>()
export const resolveId = async (importee: string, importer?: string) => {
  const key = `${importee}_${importer}`
  console.log(key)
  if (RESOLVE_CONTROL.has(key)) return RESOLVE_CONTROL.get(key)
  if (importer && importee.startsWith('.')) {
    const absolutePath = path.resolve(importer ? path.dirname(importer) : process.cwd(), importee)

    let resolved = await resolveFile(absolutePath)

    if (!resolved) {
      const exist = await pathExist(absolutePath)
      if (exist !== null) {
        const s = await stat(absolutePath)
        if (s.isDirectory()) {
          resolved = await resolveFile(absolutePath, true)
        }
      }
    }

    RESOLVE_CONTROL.set(key, resolved)

    return resolved
  }
}
