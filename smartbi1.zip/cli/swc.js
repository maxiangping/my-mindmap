/** @format */

// eslint-disable-next-line @typescript-eslint/no-var-requires

const reactOptions = {
  runtime: 'automatic',
  importSource: '@lancercomet/vue2-jsx-runtime',
  throwIfNamespace: false,
  useBuiltins: false,
}

const jsSwcOptions = (jsx = false) => {
  const react = jsx ? reactOptions : {}
  return {
    jsc: {
      parser: {
        syntax: 'ecmascript',
        jsx,
        decorators: true,
        dynamicImport: true,
        importMeta: true,
        decoratorsBeforeExport: true,
        topLevelAwait: true,
      },
      target: 'es2017',
      loose: true,
      externalHelpers: true,
      transform: {
        legacyDecorator: true,
        decoratorMetadata: true,
        react,
      },
    },
  }
}

const tsSwcOptions = (tsx = false) => {
  const react = tsx ? reactOptions : {}
  return {
    jsc: {
      parser: {
        syntax: 'typescript',
        tsx,
        decorators: true,
        dynamicImport: true,
        importMeta: true,
        decoratorsBeforeExport: true,
        topLevelAwait: true,
      },
      target: 'es2017',
      loose: true,
      externalHelpers: true,
      transform: {
        legacyDecorator: true,
        decoratorMetadata: true,
        react,
      },
    },
  }
}

module.exports = { jsSwcOptions, tsSwcOptions }
