/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function __wbg_ecb256_free(a: number): void;
export function ecb256_new(a: number, b: number): number;
export function ecb256_encrypt(a: number, b: number, c: number, d: number): void;
export function ecb256_decrypt(a: number, b: number, c: number, d: number): void;
export function __wbg_rsapublickey_free(a: number): void;
export function rsapublickey_rsa_pkcs1(a: number, b: number, c: number): void;
export function rsapublickey_rsa_pubkey(a: number, b: number, c: number): void;
export function rsapublickey_encrypt(a: number, b: number, c: number, d: number): void;
export function __wbg_rsaprivatekey_free(a: number): void;
export function rsaprivatekey_rsa_pkcs1(a: number, b: number, c: number): void;
export function rsaprivatekey_rsa_pkcs8(a: number, b: number, c: number): void;
export function rsaprivatekey_encrypt(a: number, b: number, c: number, d: number): void;
export function rsaprivatekey_decrypt(a: number, b: number, c: number, d: number): void;
export function ecb256_decrypt_string(a: number, b: number, c: number, d: number): void;
export function __wbindgen_malloc(a: number, b: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number, d: number): number;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number, c: number): void;
export function __wbindgen_exn_store(a: number): void;
