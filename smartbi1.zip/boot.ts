/** @format */

// 苟利国家生死以，岂因祸福避趋之

import * as fs from 'fs'
// import * as path from 'path'
// import * as events from 'events'
// import { spawn } from 'child_process'

// const targetEnvPath = './.env'

// const resolve = (_path: string): string => {
//   return path.resolve(__dirname, _path)
// }

const access = (path: string): Promise<boolean> => {
  return new Promise<boolean>((resolve, reject) => {
    try {
      fs.access(path, fs.constants.R_OK | fs.constants.W_OK, () => {
        resolve(true)
      })
    } catch (err) {
      reject(false)
    }
  })
}

const readfile = (filepath: string): Promise<string | undefined> => {
  return new Promise<string | undefined>((resolve, reject) => {
    fs.readFile(filepath, { encoding: 'utf8' }, (err, data) => {
      if (err !== null) {
        return reject()
      }
      resolve(data)
    })
  })
}

const writefile = (filepath: string, content: string): Promise<boolean> => {
  return new Promise<boolean>((resolve, reject) => {
    try {
      fs.writeFile(filepath, content, { encoding: 'utf8' }, () => {
        resolve(true)
      })
    } catch (error) {
      reject(false)
    }
  })
}

const delFile = (filepath: string): Promise<void> => {
  return new Promise<void>((resolve, reject) => {
    fs.access(filepath, (err) => {
      if (err) {
        return resolve()
      }

      fs.unlink(filepath, (err) => {
        if (err) {
          console.error(err)
          return reject()
        }
        console.log('file deleted successfully')
        resolve()
      })
    })
  })
}

const copy = async (from: string, to: string) => {
  const isExist = await access(from)
  if (isExist) {
    const content = await readfile(from)
    if (content !== undefined) {
      writefile(to, content)
    }
  }
}

// const isWin32 = process.platform === 'win32'

const offsetRight = (num: number) => num + 1
// npm
// console.dir(process.env.npm_config_argv)

// yarn

const { argv } = process

// const index_type = argv.indexOf('--type')
const index_mode = argv.indexOf('--mode')

// const type = argv[offsetRight(index_type)]
const mode = argv[offsetRight(index_mode)]

// const bootstrap = () => {
//   process.setMaxListeners(0)
//   events.EventEmitter.defaultMaxListeners = 0
//   spawn(isWin32 ? 'vue-cli-service.cmd' : 'vue-cli-service', [type, '--report'], {
//     stdio: 'inherit',
//     shell: isWin32,
//   })
// }
// copy('./public/cdn/fusioncharts/fusioncharts.js', './node_modules/fusioncharts/fusioncharts.js'),
Promise.all([
  delFile('./.env'),
  copy(`./environments/.env.${mode}`, `./.env.${mode}`),
  copy(
    './public/cdn/fusioncharts3/fusioncharts.js',
    './node_modules/fusioncharts/fusioncharts.js',
  ),
])
  .then(() => {
    console.log('done!')
    return
  })
  .catch((err) => {
    throw err
  })

// copy('./fix/cascader.d.ts', './node_modules/element-ui/types/cascader.d.ts')
// copy('./fix/serve.js', './node_modules/@vue/cli-service/lib/commands/serve.js')
