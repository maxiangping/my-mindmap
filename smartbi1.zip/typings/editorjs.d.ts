/** @format */

declare module '@editorjs/header' {}
declare module '@editorjs/image' {}
declare module '@editorjs/list' {}
declare module '@editorjs/nested-list' {}
// declare module '@editorjs/paragraph' {}
