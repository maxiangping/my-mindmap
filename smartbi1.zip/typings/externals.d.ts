/** @format */

declare module '*.json'
declare module '*.png'
declare module '*.jpg'
declare module '*.svg'

declare module '*.less' {
  const resource: Record<string, string>
  export = resource
}

declare module '*.json' {
  const value: Record<string, unknown>
  export default value
}
