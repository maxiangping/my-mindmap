/** @format */

import type { ITMapLatLngPoint } from './tmap'

declare interface ITMapSubPois {
  parent_id: string
  id: string
  title: string
  address: string
  location: ITMapLatLngPoint
  adcode: number
  city: string
}

/**
 * status
 * 200	OK:请求成功
 * 400	Bad Request:客户端请求的语法错误，服务器无法理解
 * 500	Internal Server Error:内部服务器错误
 */
declare interface ITMapResponse<T> {
  status: number
  message: string
  count?: number
  request_id?: string
  data?: T
  sub_pois?: ITMapSubPois
  result?: T
}

declare interface ITMapPlaceSearchParams {
  boundary: string
  keyword: string
  key?: string
  page_size?: number
  page_index?: number
}

declare interface ITMapAddressInfo {
  adcode: number
  province: string
  city: string
  district: string

  nation_code?: string
  city_code?: string
  name?: string
  location?: ITMapLatLngPoint
  nation?: string
}

declare interface ITMapPlaceSearchResponse {
  id: string
  title: string
  address: string
  tel: string
  category: string
  type: number //	POI类型，值说明:0:普通POI / 1:公交车站 / 2:地铁站 / 3:公交线路 / 4:行政区划
  location: ITMapLatLngPoint
  _distance: number
  ad_info: ITMapAddressInfo
}

declare interface ITMapSuggestionResponse {
  title: string
  address: string
  adcode: number
  province: string
  city: string
  location: ITMapLatLngPoint
  id?: string
  type?: number //	POI类型，值说明:0:普通POI / 1:公交车站 / 2:地铁站 / 3:公交线路 / 4:行政区划
  _distance?: number
}

declare interface ITMapAddressPoi {
  id: string
  title: string
  location: ITMapLatLngPoint
  address: string
  category: string

  ad_info: ITMapAddressInfo
}

declare interface ITMapAddress {
  id: string
  title: string
  location: ITMapLatLngPoint
  _distance: number
  _dir_desc: string
}

declare interface ITMapAddressComponent {
  nation: string
  province: string
  city: string
  district: string
  street: string
  street_number: string
}

declare interface ITMapLanLngToAddress {
  address: string
  formatted_addresses: {
    recommend: string
    rough: string
  }
  address_component: ITMapAddressComponent
  ad_info: ITMapAddressInfo

  address_reference: {
    famous_area: ITMapAddress

    business_area: ITMapAddress
    town: ITMapAddress

    landmark_l1: ITMapAddress

    landmark_l2: ITMapAddress

    street: ITMapAddress
    street_number: ITMapAddress
    crossroad: ITMapAddress
    water: ITMapAddress
  }

  poi_count: number
  pois: ITMapAddressPoi[]
  _distance: number
}

declare interface ITMapAddressToLanLng {
  title: string
  location: ITMapLatLngPoint
  address_component: ITMapAddressComponent
  ad_info: ITMapAddressInfo
  reliability: number
  level: number
}

declare interface ITMapGetLocation {
  ip: string
  location: ITMapLatLngPoint
  ad_info: ITMapAddressInfo
}
