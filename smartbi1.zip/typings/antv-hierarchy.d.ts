/** @format */

declare module '@antv/hierarchy'
declare module '@antv/x6/dist/x6.js'
