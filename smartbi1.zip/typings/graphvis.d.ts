/** @format */

import { SpecialValueMap } from '@/store/model/common'

export class VisGraphClass {
  constructor(el: HTMLElement, config: VisGraphConfig)
  nodes: VisGraphDataNode[]
  links: VisGraphDataLink[]

  currentNode: VisGraphDataNode
  currentLink: VisGraphDataLink

  addGraph(data: VisGraphData): void
  drawData(data: VisGraphData): void
  getGraphData(): VisGraphData
  setZoom(type: string): void
  clearAll(): void
  restoreHightLight(): void // 取消高亮
  getVisibleData(): VisGraphData
  translateToCenter(): void
  moveCenter(): void
  clearClusters(): void
  deleteNode(node: VisGraphDataNode): void
  // addNode(node: VisGraphDataNode): void
  addNode(node: VisGraphDataNode)
  findNode(name: string): VisGraphDataNode
  addEdge(link: VisGraphDataLink): void
  activeAddNodeLinks(nodes: VisGraphDataNode[], links: VisGraphDataLink[])
  highLightNeiberNodes(node: VisGraphDataNode, alpha: number) //相邻节点高亮显示，其他节点设置为指定透明度node：指定可视化节点对象alpha：透明度（取值 0-1）
  lockNode(node: VisGraphDataNode): void //锁定指定节点，不可移动或拖动 node：指定可视化节点对象
  unLockNode(node: VisGraphDataNode): void //节点取消锁定状态
  showNodeLabel(flag: boolean): void //显示或隐藏节点标签flag:是否显示节点标签true:显示false:不显示
  showLinkLabel(flag: boolean): void //显示或隐藏连线标签flag:是否显示节点标签true:显示false:不显示
  setMouseModel(mode: string): void //设置鼠标模式mode：鼠标模式类型说明：drag：拖动模式select：框选模式normal：正常模式
  contract(node: VisGraphDataNode): void //收起指定节点的孤立叶子节点
  expanded(node: VisGraphDataNode): void //展开指定节点的叶子节点
  setNodeShape(shapeType: string): void //统一设置节点的形态shapeType：形状类型详细参照：节点形状类型的定义
  saveImage(
    width?: number,
    height?: number,
    type?: string,
    fileName?: string,
  ): void //保存图片width：图片的宽度（2000）height：图片的高度（2000）
  showOverView(flag: boolean): void //显示或隐藏缩略图flag:是否显示true:显示false:不显示
  hideAllLink(): void //隐藏所有连线
  showAllLink(): void //显示所有连线
  showAllNode(): void //显示所有节点
  setTextPosition(textAlign: string): void //设置节点标签位置textAlign：标签位置类型详细参照：节点标签位置的定义
  setLineType(textAlign: string): void // 设置连线类型
  setLineDashed(flag: boolean): void // 设置连线样式
  setLinkAlpha(alpha: number): void //设置连线透明度alpha：透明度取值：0-1
  setLinkArrowShow(flag: boolean): void //设置连线箭头是否显示flag:是否显示true:显示false:不显示
  setLinkColorType(type: string): void //设置连线颜色类型type：连线颜色类型说明：source：继承起始节点颜色target：继承目标节点颜色both：继承两边节点颜色defined：自定义颜色值
  applyNodeSize(range: number[]): void //按度大小映射节点大小range：节点的大小范围如：[10,100]
  applyLinkWeight(range: number[]): void //安权重大小映射连线宽度range：连线的宽度范围如：[1,20]
  selectAll(): void //全选
  reverseSelect(): void //反选
  selectRelate(node: VisGraphDataNode): void //选中关联节点node：指定节点对象
  showSelected(): void //仅显示选中
  hideSelected(): void //隐藏已选中节点
  hideIsolatedNodes(): void //隐藏所有孤立节点
  deleteLink(link: VisGraphDataLink): void //删除指定连线link：指定待删除的连线对象
  rotateGraph(angle: number[] | number): void //旋转图数据angle：旋转角度取值：[0-360]
  nodeWrapText(flag: boolean): void //节点包裹文字
  findShortPath(sourceLabel: string, targetNodeLabel: string): void //查找两点间的最短路径 显示最短路径经过的节点
  pathAnalyze(sourceLabel: string, targetNodeLabel: string): void //查找两点间所有路径显示所有路径经过的节点
  nLayerRelates(nodeLabel: string, nlayer: number): void //查找节点的n层关系显示n层关系的节点
  setNodeSize(nodeSize: number): void //统一设置节点大小nodeSize：节点大小如：60
  setNodeColor(color: string): void //统一设置节点颜色
  getMousePosition(event): void //获取鼠标事件在画布中的事件位置event：鼠标位置返回鼠标在画布中的位置信息
  addNodeForDrag(node: VisGraphDataNode, callback: Function): void //拖拽添加节点到画布中node：节点信息callback：添加成功的回调函数
  showAll(): void //显示所有连线和节点
  delSelect(): void //删除选中节点
  findNodeById(nodeId: string): VisGraphDataNode //根据节点ID获取节点对象 nodeId：节点ID
  updateNodeLabel(nodeId: string, nodeLabel: string): void //更新节点名称nodeId：节点ID nodeLabel：节点名称
  begainAddLine(node: VisGraphDataNode): void //开始添加连线node：指定的起始节点，一般为当前选中节点
  addClusterContainer(clusters: VisGraphCluster[], avoidOverlap?: boolean): void
  addNodesInGroup(
    node: AddNodesInGroupSelfParams,
    nodeGroup: VisGraphDataNode[],
  )
  translateOrZoom(method: string, val: number): void // 坐标放大or缩小
  refresh(): void
}

export declare class VisGraphLayout {
  constructor(data: VisGraphData)

  createLayout(type: string): VisGraphLayout
  resetConfig(config: any): void
  getConfig(): any

  runLayout(): void
  initAlgo(): void
}

export class VisGraphCluster {
  constructor(data: VisGraphData)

  createClutser(type: string): VisGraphCluster
  applay(): void
}

export interface VisGraphData {
  nodes: VisGraphDataNode[]
  links: VisGraphDataLink[]
}

export interface VisGraphDataNode {
  id: string | number
  label?: string | number
  type?: string
  personId?: string
  isCenter?: boolean
  style?: VisGraphDataNodeStyle
  value?: number
  properties?: Object
  selfProperties?: SelfPropertiesParams // 自定义自己需要的属性 待优化
  selfDetails?: SelfDetail[]
  tipText?: string
  showlabel?: boolean
  color?: string // 节点颜色
  size?: number // 节点大小
  x?: number // 节点x轴位置
  y?: number // 节点y轴位置
  font?: string // 字体大小及类型
  borderColor?: string // 边框颜色
  shape?: string // 节点形状
  cluster?: string
  showSelected?: boolean // 是否被选中
  fillColor?: string // 节点的填充色（只支持色值）
  scaleX?: number // 横向放大系数
  scaleY?: number // 纵向放大系数
  scale?: string // mock数据的缩放
  selected?: boolean // 是否选中
  dragable?: boolan // 是否可以拖拽
  visible?: boolean //	是否显示	true或false
  onClick?: (callback: (event?: Event, node?: VisGraphDataNode) => void) => void
  click?: (callback: (event?: Event) => void) => void
  dbclick?: (callback: (event?: Event) => void) => void
}
// 自定义节点属性xinxi

export interface SelfDetail {
  prop_name: string
  prop_value: string
}

// 自定义节点属性
export interface SelfPropertiesParams {
  tips?: string // 需要展示的标识信息
  color?: string //  需要展示的标识色值
  colorDesc?: string // 对色值的解释
  showBorder?: string // 空心(只展示border)1：实心(不展示boeder)
  expand?: boolean // 是否能扩展
  showlabel?: string // 是否显示标签
  fillColor?: string // 自定义节点颜色 rgb格式
}
// 创建的分组params
export interface TableColumnObjParams {
  id: string
  type: string
  x: number
  y: number
}

// 同上
export interface AddNodesInGroupSelfParams {
  color: string
  alpha: number
  padding?: number
  label?: string
}

export interface VisGraphDataLink {
  id?: string | number
  source: string | number | VisGraphDataNode
  target: string | number | VisGraphDataNode
  label?: string
  type?: string
  weight?: number
  value?: number
  style?: VisGraphDataLinkStyle
  properties?: Object
  color?: string // 连线颜色
  lineType?: string // 连线类型
  selfProperties?: string // 自定义自己需要的属性
}

export interface VisGraphDataNodeStyle {
  x?: number
  y?: number
  shape?: string //	形状	circle：圆形 polygon：六边形 square：正方形 star：星形
  size?: number //	大小	40
  visible?: boolean //	是否显示	true或false
  showlabel?: boolean //	是否显示名称	true或false
  fillColor?: string //		节点颜色	rgb色值，如：180,180,220
  borderWidth?: number //	边框宽度	2
  borderColor?: string //		边框颜色	rgb色值，如：180,180,220
  selectedBorderWidth?: number //	选中时边框宽度	4
  selectedBorderColor?: string //		选中时边框颜色	rgb色值，如：180,180,220
  showShadow?: boolean //	是否显示阴影	true或false
  shadowBlur?: number //	阴影的范围大小	30
  shadowColor?: string //		阴影的颜色	rgb色值，如：180,180,220
  font?: string //		字体定义	如：'normal 14px KaiTi'
  fontColor?: string //		字体颜色	rgb色值，如：80,80,80
  textPosition?: string //		文字位置	居中：Middle_Center，下居中：Bottom_Center，上居中：Top_Center
  image?: string //		图片路径	图片的url路径
  tagColor?: string //		角标的颜色	rgb色值，如：230,80,80
  tags?: string[] //角标的值	如：['毒','盗']
}

export interface VisGraphDataLinkStyle {
  lineType?: string //	连线类型	straight：直线, hlink、vlink：横竖向折线, hbezier、vbezier：横竖向贝塞尔曲线
  lineWidth?: number //	连线的宽度	2
  visible?: boolean //	是否显示	true或false
  showlabel?: boolean //	是否显示名称	true或false
  showArrow?: boolean //	是否显示箭头	true或false
  arrowType?: string //	箭头类型	arrow：箭头 triangle：三角形
  strokeColor?: string //	连线颜色	rgb色值，如：120,120,120
  labelBackGround?: string //	连线文字背景颜色	rgb色值，如：250,250,250
  selectedColor?: string //	选中时的颜色	rgb色值，如：230,120,120
  background?: string //	连线背景色	rgb色值，如：180,180,220
  font?: string //	字体定义	如：'normal 14px KaiTi'
  fontColor?: string //	字体颜色	rgb色值，如：80,80,80
  lineDash?: number[] //	虚线间隔	连线虚线间隔，如：[3,5]
}

export interface VisGraphConfig {
  node: {
    //节点的默认配置
    label?: {
      //标签配置
      show?: boolean //是否显示
      color?: string //字体颜色
      font?: string //字体大小及类型
      textPosition?: string //文字位置 Top_Center,Bottom_Center,Middle_Right
      wrapText?: boolean // 节点包裹文字(该属性为true时只对于字体位置为Middle_Center时有效)
      textOffsetX?: number //文字横向偏移量(默认不配置)
      textOffsetY?: number //文字纵向偏移量(默认不配置)
      background?: string | null //文字背景色(默认不配置)
    }
    shape?: string //节点形状 circle,star,polygon,square
    width?: number
    height?: number
    color?: string //节点颜色
    borderColor?: string //边框颜色
    borderWidth?: number //边框宽度
    borderRadius?: number // 节点圆角
    tagColor?: string //标记的颜色
    size?: number //节点半径大小
    lineDash?: number[] // 节点边框线条类型 [0] 表示实线 [5,8] 表示虚线 borderWidth > 0有效
    alpha?: number // 节点透明度
    selected?: {
      //选中时的样式设置
      borderColor?: string //选中时边框颜色
      borderAlpha?: number //选中时的边框透明度
      borderWidth?: number //选中是的外部边框宽度
      showShadow?: boolean //是否展示阴影
      shadowColor?: string //选中是的阴影颜色
      shadowBlur?: number //阴影的范围大小
    }
    onClick?: (_event: Event, node: VisGraphDataNode) => void
    onMouseOver?: (_event: MouseEvent, node: VisGraphDataNode) => void
    onMouseOut?: (_event: MouseEvent, node: VisGraphDataNode) => void
  }
  link: {
    //连线的默认配置
    label?: {
      //连线标签
      show?: boolean //是否显示
      color?: string //字体颜色
      font?: string //字体大小及类型
      background?: string | null //文字背景色(有背景时上线居中)
    }
    lineType?: string //连线类型,straight,curver,vlink,hlink,vbezier,hbezier
    colorType?: string // 连线颜色类型 source:继承source颜色,target:继承target颜色 both:用双边颜色，defined:自定义
    color?: string //连线颜色
    alpha?: number // 连线透明度
    lineDash?: number[] // 虚线间隔样式如：[5,8]
    selected?: {
      // 选中时的样式设置
      color?: string // 选中时的颜色
      alpha?: number // 选中时的透明度
      lineWidth?: number // 选中线条宽度
      showShadow?: boolean // 显示阴影
      shadowColor?: string // 阴影颜色
    }
    lineWidth?: number //连线宽度
    showArrow?: boolean //显示连线箭头
    arrowType?: string //箭头样式arrow,triangle
  }
  highLightNeiber?: boolean //相邻节点高度标志
  backGroundType?: string //保存图片的类型，支持png、jpeg
  wheelZoom?: number //滚轮缩放开关，不使用时不设置
  selectBox?: {
    //框选区域的颜色配置
    color?: string //框的颜色
    alpha?: number //框的透明度
  }
  rightMenu?: {
    nodeMenu?: {
      init: (_data: VisGraphClass) => void
      show: (e: MouseEvent, _data: VisGraphClass) => void
      hide: () => void
    }
  }
  noElementClick?: (_event: Event) => void
}

// 节点右键菜单
export interface NodeRightMenuParams {
  init(): void
  show(): void
  hide(): void
}
