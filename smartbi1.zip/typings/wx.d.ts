/** @format */

type ApiCall<T> = (apiConf: T) => void

interface IWxCall<T> {
  success: (res: T) => void
  fail?: () => void
  complete?: () => void
  cancel?: () => void
  trigger?: () => void
}

declare interface ICheckJsApi extends IWxCall<boolean> {
  jsApiList: string[]
}

declare interface IUpdateAppMessageShareData extends IWxCall<void> {
  title: string // 分享标题
  desc: string // 分享描述
  link: string // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
  imgUrl: string // 分享图标
}

declare interface IUpdateTimelineShareData extends IWxCall<void> {
  title: string // 分享标题
  link: string // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
  imgUrl: string // 分享图标
}

declare interface IMenuShareWeibo extends IWxCall<void> {
  title: string // 分享标题
  desc: string // 分享描述
  link: string // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
  imgUrl: string // 分享图标
}

declare interface IChooseImage extends IWxCall<string[]> {
  count: number // 默认9
  sizeType: ['original', 'compressed'] // 可以指定是原图还是压缩图，默认二者都有
  sourceType: ['album', 'camera'] // 可以指定来源是相册还是相机，默认二者都有
}

declare interface IPreviewImage extends IWxCall<void> {
  current: string // 当前显示图片的http链接
  urls: string[] // 需要预览的图片http链接列表
}

declare interface IOpenLocation extends IWxCall<void> {
  latitude: number // 纬度，浮点数，范围为90 ~ -90
  longitude: number // 经度，浮点数，范围为180 ~ -180。
  name: string // 位置名
  address: string // 地址详情说明
  scale: number // 地图缩放级别,整形值,范围从1~28。默认为最大
  infoUrl: string // 在查看位置界面底部显示的超链接,可点击跳转
}

declare interface IGetLocation
  extends IWxCall<{
    latitude: number // 纬度，浮点数，范围为90 ~ -90
    longitude: number // 经度，浮点数，范围为180 ~ -180。
    speed: number // 速度，以米/每秒计
    accuracy: number // 位置精度
  }> {
  type: 'wgs84' | 'gcj02' // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
}

declare interface IScanQRCode
  extends IWxCall<{ networkType: '2g' | '3g' | '4g' | 'wifi' }> {
  needResult: number // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
  scanType: ['qrCode', 'barCode'] // 可以指定扫二维码还是一维码，默认二者都有
  success: (res: { resultStr?: string }) => void // 当needResult 为 1 时，扫码返回的结果
}

declare type IGetNetwokType = IWxCall

declare interface ISubjWeiXin {
  checkJsApi: ApiCall<ICheckJsApi>
  // 自定义“分享给朋友”及“分享到QQ”按钮的分享内容（1.4.0）
  onMenuShareAppMessage: ApiCall<IUpdateAppMessageShareData>

  // 自定义“分享到朋友圈”及“分享到QQ空间”按钮的分享内容（1.4.0）
  onMenuShareTimeline: ApiCall<IUpdateTimelineShareData>

  // 获取“分享到腾讯微博”按钮点击状态及自定义分享内容接口
  onMenuShareWeibo: ApiCall<IMenuShareWeibo>

  // 图像接口

  // 拍照或从手机相册中选图接口
  chooseImage: ApiCall<IChooseImage>

  // 预览图片接口
  previewImage: ApiCall<IPreviewImage>

  // 设备信息

  // 获取网络状态接口
  getNetworkType: ApiCall<IGetNetwokType>

  // 地理位置

  // 使用微信内置地图查看位置接口
  openLocation: ApiCall<IOpenLocation>

  // 获取地理位置接口
  getLocation: ApiCall<IGetLocation>

  // 微信扫一扫
  // 调起微信扫一扫接口
  scanQRCode: ApiCall<IScanQRCode>
}

declare interface IWxSignature {
  debug: boolean // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
  appId: string // 必填，公众号的唯一标识
  timestamp: number // 必填，生成签名的时间戳
  nonceStr: string // 必填，生成签名的随机串
  signature: string // 必填，签名
  jsApiList: string[] // 必填，需要使用的JS接口列表
}

export declare interface IjWeiXin extends ISubjWeiXin {
  config: ApiCall<IWxSignature>
  ready: ApiCall<() => void>
  error: ApiCall<(res: string) => void>
}

export interface IWxSignParams {
  nonceStr: string
  timestamp: number
  url: string
}
