/** @format */
import type { D3, D3FlexTree } from './d3.d'
import { VisGraph, VisGraphCluster, VisGraphLayout } from './graphvis'
import { IMdate } from './mDate'
import type { IjWeiXin } from './wx.d'

declare global {
  interface ImportMeta {
    env: Record<string, unknown>
  }
}

export declare interface ResizeObserverSize {
  blockSize: number
  inlineSize: number
}

export declare interface ResizeObserverEntry {
  borderBoxSize: ResizeObserverSize[]
  contentBoxSize: ResizeObserverSize[]
  contentRect: {
    x: number
    y: number
    width: number
    height: number
    top: number
    bottom: number
    left: number
    right: number
  }
  devicePixelContentBoxSize: ResizeObserverSize[]
  target: Element
}

declare type ResizeObserverParam = (params: ResizeObserverEntry[]) => void

export declare class ResizeObserver {
  constructor(parameters: ResizeObserverParam)

  observe(e: Element | Element[])
}

export declare global {
  interface Window {
    wx?: IjWeiXin
    d3: D3
    flextree: D3FlexTree
    ResizeObserver: new (parameters: ResizeObserverParam) => ResizeObserver
    TMap?: ITMap
    G6: G6
    VisGraph: VisGraphClass
    LayoutFactory: VisGraphLayout
    ClusterFactory: VisGraphCluster
    Mdate: unknown
    iScroll: unknown
    MdateCss: unknown
    ssoAuthUrl?: string // sso 授权地址
  }
}
