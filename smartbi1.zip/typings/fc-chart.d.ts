/** @format */

// \s\[\+\](\s\S+)?\n  \n

declare namespace AttributesOfChart {
  // These attributes let you control a variety of functional elements on the chart. For example, you can opt to show/hide data labels, data values. You can also set chart limits and extended properties.
  interface IFunctionalAttributes {
    animation: boolean
    animationDuration: number
    palette: number
    paletteColors: string
    showLabels: boolean
    labelStep: number
    maxLabelWidthPercent: number
    minLabelWidthPercent: number
    useEllipsesWhenOverflow: boolean
    showValues: boolean
    placeValuesInside: boolean
    showLimits: boolean
    showDivLineValues: boolean
    showShadow: boolean
    adjustDiv: boolean
    clickURL: string
    clickURLOverridesPlotLinks: boolean
    maxBarHeight: number
    setAdaptiveYMin: boolean
    useDataPlotColorForLabels: boolean
    hasRTLText: number
    showPrintMenuItem: boolean
    plotBinSize: number
    labelBinSize: number
    theme: string
  }

  // Using these attributes, you can set the various headings and titles of chart like caption, sub-caption, x-axis and y-axis names etc.
  interface IChartTitlesAndAxisNames {
    caption: string
    subCaption: string
    xAxisName: string
    yAxisName: string
  }

  // These attributes let you configure the cosmetics of chart caption and sub-caption.
  interface IChartCaptionCosmetics {
    captionAlignment: string
    captionOnTop: boolean
    captionFontSize: number
    subCaptionFontSize: number
    captionFont: string
    subCaptionFont: string
    captionFontColor: string
    subCaptionFontColor: string
    captionFontBold: boolean
    subCaptionFontBold: boolean
    alignCaptionWithCanvas: boolean
    captionHorizontalPadding: number
  }

  // Using these attributes, you can set and configure x-axis labels, y-axis values and set chart cosmetics for the axis like color, alpha, etc.
  interface IChartAxisConfigurationAttributes {
    showXAxisLine: boolean
    xAxisPosition: string
    yAxisPosition: string
    axisLineAlpha: number
    xAxisLineColor: string
    centerXaxisName: boolean
    rotateXAxisName: boolean
    xAxisNameWidth: number
    showYAxisValues: boolean
    yAxisValuesStep: number
    yAxisMinValue: number
    yAxisMaxValue: number
    forceYAxisValueDecimals: boolean
    yAxisValueDecimals: number
  }

  // To configure the font cosmetics of x-axis name (title), you can use the following attributes.
  interface IXAxisNameCosmetics {
    xAxisNameFont: string
    xAxisNameFontColor: string
    xAxisNameFontSize: number
    xAxisNameFontBold: boolean
    xAxisNameFontItalic: boolean
    xAxisNameBgColor: string
    xAxisNameBorderColor: string
    xAxisNameAlpha: number
    xAxisNameFontAlpha: number
    xAxisNameBgAlpha: number
    xAxisNameBorderAlpha: number
    xAxisNameBorderPadding: number
    xAxisNameBorderRadius: number
    xAxisNameBorderThickness: number
    xAxisNameBorderDashed: boolean
    xAxisNameBorderDashLen: number
    xAxisNameBorderDashGap: number
  }

  // To configure the font cosmetics of y-axis name (title), you can use the following attributes.
  interface IYAxisNameConsmetics {
    yAxisNameFont: string
    yAxisNameFontColor: string
    yAxisNameFontSize: number
    yAxisNameFontBold: boolean
    yAxisNameFontItalic: boolean
    yAxisNameBgColor: string
    yAxisNameBorderColor: string
    yAxisNameAlpha: number
    yAxisNameFontAlpha: number
    yAxisNameBgAlpha: number
    yAxisNameBorderAlpha: number
    yAxisNameBorderPadding: number
    yAxisNameBorderRadius: number
    yAxisNameBorderThickness: number
    yAxisNameBorderDashed: boolean
    yAxisNameBorderDashLen: number
    yAxisNameBorderDashGap: number
  }

  // The following attributes let you configure chart cosmetics like background color, background alpha, canvas color & alpha etc.
  interface IChartCosmetics {
    showBorder: boolean
    borderColor: string
    borderThickness: number
    borderAlpha: number
    bgColor: string
    bgAlpha: number
    bgRatio: number
    bgAngle: number
    bgImage: string
    bgImageAlpha: number
    bgImageDisplayMode: string
    bgImageVAlign: string
    bgImageHAlign: string
    bgImageScale: number
    canvasBgColor: string
    canvasBgAlpha: number
    canvasBgRatio: Numbers // When a gradient is used to set the color of the canvas background, this attribute sets the ratio of the colors. Example : If the value of the canvasBgColor attribute is set as #FF5904, #FFFFFF, canvasBgRatio can be used to specify their ratio in the background. Range: 0 - 100
    canvasBgAngle: number
    showcanvasborder: boolean
    canvasBorderColor: string
    canvasBorderThickness: number
    canvasBorderAlpha: number
    showVLineLabelBorder: boolean
    rotateVLineLabels: boolean
    logoURL: string
    logoLeftMargin: number
    logoTopMargin: number
    logoPosition: string
    logoAlpha: number
    logoScale: number
    logoLink: string
  }

  // These attributes let you configure how your plot (columns, lines, area, pie or any data that you're plotting) will appear on the chart. If the plots can show borders, you can control the border properties using the attributes listed below. Or, if they support gradient fills, you can again configure various properties of the gradient using these attributes. Various other controls over plot cosmetics can be attained using this set of attributes.
  interface IDataPlotCosmetics {
    useRoundEdges: boolean
    showPlotBorder: boolean
    plotBorderColor: string
    plotBorderAlpha: number
    plotBorderThickness: number
    plotBorderDashed: boolean
    plotBorderDashLen: number
    plotBorderDashGap: number
    plotFillAngle: number
    plotFillRatio: number
    plotFillAlpha: number
    plotGradientColor: string
    usePlotGradientColor: boolean
    minPlotHeightForValue: number
  }

  // These attributes let you configure font, background and border cosmetics, of value text-field that appear for each data plot.
  interface IDataValueCosmetics {
    valueFont: string
    valueFontColor: string
    valueFontSize: number
    valueFontBold: boolean
    valueFontItalic: boolean
    valueBgColor: string
    valueBorderColor: string
    valueAlpha: number
    valueFontAlpha: number
    valueBgAlpha: number
    valueBorderAlpha: number
    valueBorderThickness: number
    valueBorderPadding: number
    valueBorderRadius: number
    valueBorderDashed: boolean
    valueBorderDashLen: number
    valueBorderDashGap: number
    textOutline: boolean
  }

  // These attributes let you configure font, background and border cosmetics, of the Y-axis value text.
  interface IYAxisValueCosmetics {
    yAxisValueFont: string
    yAxisValueFontColor: string
    yAxisValueFontSize: number
    yAxisValueFontBold: boolean
    yAxisValueFontItalic: boolean
    yAxisValueBgColor: string
    yAxisValueBorderColor: string
    yAxisValueAlpha: number
    yAxisValueBgAlpha: number
    yAxisValueBorderAlpha: number
    yAxisValueBorderPadding: number
    yAxisValueBorderRadius: number
    yAxisValueBorderThickness: number
    yAxisValueBorderDashed: boolean
    yAxisValueBorderDashLen: number
    yAxisValueBorderDashGap: number
    yAxisValueLink: URL
  }

  // Using this set of attributes, you can control the properties of divisional lines, zero plane and alternate color bands. Divisional Lines are horizontal or vertical lines running through the canvas. Each divisional line signifies a smaller unit of the entire axis thus aiding the users in interpreting the chart. The zero plane is a 2D/3D plane that signifies the 0 position on the chart. If there are no negative numbers on the chart, you won't see a visible zero plane. Alternate color bands are colored blocks between two successive divisional lines.
  interface IDivisionalLinesAndGrids {
    numDivLines: number
    divLineColor: string
    divLineThickness: number
    divLineAlpha: number
    divLineDashed: boolean
    divLineDashLen: number
    divLineDashGap: number
    zeroPlaneColor: string
    zeroPlaneThickness: number
    zeroPlaneAlpha: number
    showZeroPlaneValue: boolean
    showAlternateVGridColor: boolean
    alternateVGridColor: string
    alternateVGridAlpha: number
  }

  // FusionCharts XT offers you a lot of options to format your numbers on the chart. Using the attributes below, you can control a myriad of options like: Formatting of commas and decimals Number prefixes and suffixes Decimal places to which the numbers will round to Scaling of numbers based on a user defined scale Custom number input formats
  interface INumberFormatting {
    formatNumber: boolean
    formatNumberScale: boolean
    defaultNumberScale: string
    numberScaleUnit: string
    numberScaleValue: string
    forceNumberScale: boolean
    scaleRecursively: boolean
    maxScaleRecursion: number
    scaleSeparator: string
    numberPrefix: string
    numberSuffix: string
    decimalSeparator: string
    thousandSeparator: string
    thousandSeparatorPosition: number
    inDecimalSeparator: string
    inThousandSeparator: string
    decimals: number
    forceDecimals: boolean
  }

  // Using the attributes below, you can define the generic font properties for all the text on the chart. These attributes allow you a high level control over font properties. If you intend to specify font properties for individual chart elements (like Caption, sub-caption etc.), you'll need to use the Styles feature of FusionCharts XT. Using Styles, you can also specify advanced font properties like Bold, Italics, HTML Mode etc.
  interface IFontProperties {
    baseFont: string
    baseFontSize: number
    baseFontColor: string
    outCnvBaseFont: string
    outCnvBaseFontSize: number
    outCnvBaseFontColor: string
  }

  // Using these attributes, you can set and configure cross line and set its cosmetics like color, alpha, etc.
  interface ICrossLineAttributes {
    drawCrossLine: boolean
    crossLineColor: string
    crossLineAlpha: number
    crossLineAnimation: boolean
    crossLineAnimationDuration: number
    plotColorinTooltip: boolean
    drawCrossLineOnTop: boolean
  }

  // These attributes let you control the tool tip. You can set the background color, border color, separator character and few other details.
  interface ITooltipAttributes {
    showToolTip: boolean
    toolTipBgColor: string
    toolTipColor: string
    toolTipBorderColor: string
    tooltipBorderAlpha: number
    toolTipSepChar: string
    showToolTipShadow: boolean
    tooltipbgalpha: number
    tooltipborderradius: number
    tooltipborderthickness: number
    toolTipPadding: number
    plottooltext: string
  }

  // Using this set of attributes, you can customize the toolbar on the chart. The advantage of having a toolbar is that it manages all the UI action elements (context menus, checkboxes, buttons) centrally. This provides a clean, uniform look and a better, more meaningful and logical grouping.
  interface IToolbarAttributes {
    toolbarPosition: string
    toolbarX: number
    toolbarY: number
    toolbarHAlign: string
    toolbarVAlign: string
    toolbarButtonColor: string
    showToolBarButtonTooltext: boolean
    toolbarButtonScale: number
  }

  // These attributes allow you to control the saving of chart as image, SVG or XLSX.
  interface IAttributesForExportingCharts {
    exportEnabled: boolean
    exportShowMenuItem: boolean
    exportFormats: string
    exportHandler: string
    exportAction: string
    exportTargetWindow: string
    exportCallback: string
    exportFileName: string
  }

  // If you wish to show an effect on the data plot (column, line anchor, pie etc.) when the user hovers his mouse over the data plot, these attributes let you configure the cosmetics of the hover for all data plots in the chart.
  interface IDataPlotHoverEffects {
    showHoverEffect: boolean
    plotHoverEffect: boolean
    plotFillHoverColor: string
    plotFillHoverAlpha: number
    barHoverColor: string
    barHoverAlpha: number
    plotHoverGradientColor: string
    plotHoverRatio: number
    plotHoverAngle: number
    plotBorderHoverColor: string
    plotBorderHoverThickness: number
    plotBorderHoverDashed: boolean
    plotBorderHoverDashLen: number
    plotBorderHoverDashGap: number
  }

  // These attributes let you configure the cosmetics of all data labels of the chart.
  interface IDataLabelCosmetics {
    labelFont: string
    labelFontColor: string
    labelFontSize: number
    labelFontBold: boolean
    labelFontItalic: boolean
    labelBgColor: string
    labelBorderColor: string
    labelAlpha: number
    labelBgAlpha: number
    labelBorderAlpha: number
    labelBorderPadding: number
    labelBorderRadius: number
    labelBorderThickness: number
    labelBorderDashed: boolean
    labelBorderDashLen: number
    labelBorderDashGap: number
    labelLink: URL
  }

  // The following attributes help you control chart margins and paddings. FusionCharts Suite XT allows you manually customize the padding of various elements on the chart to allow advanced manipulation and control over chart visualization. Padding in FusionCharts XT is always defined in pixels, unless the attribute itself suggests some other scale (like plotSpacePercent, which configures the spacing using percentage values). You can also define the chart margins. Chart Margins refer to the empty space left on the top, bottom, left and right of the chart. That means, FusionCharts Suite XT will not plot anything in that space. It's not necessary for you to specify any padding/margin values. FusionCharts Suite XT automatically assumes the best values for the same, if you do not specify the same.
  interface IChartPaddingAndMargins {
    captionPadding: number
    xAxisNamePadding: number
    yAxisNamePadding: number
    yAxisValuesPadding: number
    labelPadding: number
    valuePadding: number
    plotSpacePercent: number
    chartLeftMargin: number
    chartRightMargin: number
    chartTopMargin: number
    chartBottomMargin: number
    canvasPadding: number
    canvasLeftPadding: number
    canvasRightPadding: number
    canvasTopPadding: number
    canvasBottomPadding: number
    canvasLeftMargin: number
    canvasRightMargin: number
    canvasTopMargin: number
    canvasBottomMargin: number
  }

  interface ITrendLines {
    trendlineColor: string
    trendlineThickness: number
    trendlineAlpha: number
    trendLineToolText: string
    showTrendlinesOnTop: boolean
  }

  interface ITrendLinesDisplayValueCosmetics {
    trendValueFont: string
    trendValueFontSize: number
    trendValueFontBold: boolean
    trendValueFontItalic: boolean
    trendValueBgColor: string
    trendValueBorderColor: string
    trendValueAlpha: number
    trendValueBgAlpha: number
    trendValueBorderAlpha: number
    trendValueBorderPadding: number
    trendValueBorderRadius: number
    trendValueBorderThickness: number
    trendValueBorderDashed: boolean
    trendValueBorderDashLen: number
    trendValueBorderDashGap: number
  }

  interface IVerticalTrendLines {
    startValue: number
    endValue: number
    displayValue: string
    color: string
    isTrendZone: boolean
    thickness: number
    alpha: number
    dashed: boolean
    dashLen: number
    dashGap: number
    toolText: string
  }

  interface IVerticalDataSeparatorLine {
    vLine: string
    color: string
    thickness: number
    alpha: number
    dashed: boolean
    dashLen: number
    dashGap: number
    label: string
    showLabelBorder: boolean
    linePosition: number
    labelPosition: number
    labelHAlign: string
    labelVAlign: string
  }

  interface ILegendProperties {
    showLegend: boolean
    legendItemFontBold: boolean
    legendItemFont: string
    legendItemFontSize: number
    legendItemFontColor: string
    legendItemHoverFontColor: string
    legendPosition: string
    legendXPosition: number
    legendYPosition: number
    legendNumRows: number
    legendNumColumns: number
    legendCaptionAlignment: string
    legendCaptionFontBold: boolean
    legendCaptionFont: string
    legendCaptionFontSize: number
    legendCaptionFontColor: string
    legendCaption: string
    legendItemHiddenColor: string
    legendIconScale: number
    legendBgColor: string
    legendBgAlpha: number
    legendBorderColor: string
    legendBorderThickness: number
    legendBorderAlpha: number
    legendShadow: boolean
    legendAllowDrag: boolean
    legendScrollBgColor: string
    reverseLegend: boolean
    interactiveLegend: boolean
    legendNumColumns: number
    minimiseWrappingInLegend: boolean
    drawCustomLegendIcon: boolean
    legendIconBorderColor: string
    legendIconBgColor: string
    legendIconAlpha: number
    legendIconBgAlpha: number
    legendIconSides: number
    legendIconBorderThickness: number
    legendIconStartAngle: number
    alignLegendWithCanvas: boolean
  }

  interface IAnchors {
    drawAnchors: boolean
    anchorSides: number
    anchorStartAngle: number
    anchorRadius: number
    anchorBorderColor: string
    anchorBorderThickness: number
    anchorBgColor: string
    anchorAlpha: number
    anchorBgAlpha: number
    anchorImageUrl: string
    anchorImageAlpha: number
    anchorImageScale: number
    anchorImagePadding: number
  }

  interface ICategoriesObject {
    font: string
    fontColor: string
    fontSize: number
    verticalLineAlpha: number
    verticalLineColor: string
    verticalLineDashed: boolean
    verticalLineDashLen: number
    verticalLineDashGap: number
    verticalLineThickness: number
  }

  interface ICategoryObject {
    label: string
    lineDashed: boolean
    showLabel: boolean
    showVerticalLine: boolean
    x: number
    font: string
    fontColor: string
    fontSize: number
    fontBold: boolean
    fontItalic: boolean
    bgColor: string
    borderColor: string
    alpha: number
    bgAlpha: number
    borderAlpha: number
    borderPadding: number
    borderRadius: number
    borderThickness: number
    borderDashed: boolean
    borderDashLen: number
    borderDashGap: number
  }

  interface IDatasetObject {
    seriesName: string
    color: string
    plotFillAlpha: string
    showValues: boolean
    valueFontColor: string
    valueBgColor: string
    valueBorderColor: string
    includeInLegend: boolean
    showPlotBorder: boolean
    plotBorderColor: string
    plotBorderThickness: number
    plotBorderAlpha: number
    showRegressionLine: boolean
    showYOnX: boolean
    regressionLineColor: string
    regressionLineThickness: number
    regressionLineAlpha: number
    showHoverEffect: boolean
    hoverColor: string
    hoverAlpha: number
    is3dOnHover: boolean
    hoverScale: number
  }

  interface IPivotProperties {
    pivotRadius: number
    pivotFillColor: color
    pivotFillAlpha: number
    pivotFillAngle: number
    pivotFillType: string
    pivotFillMix: string
    pivotFillRatio: string
    showPivotBorder: boolean
    pivotBorderThickness: number
    pivotBorderColor: color
    pivotBorderAlpha: number
    pivotbgcolor: color
  }
}

/**
 * These attributes let you set and configure custom chart messages, using text as well as images. These attributes are supported in FusionCharts constructor (FusionCharts({ })).
 */
declare namespace FusionCharts {
  interface IChartMessageRelatedAttributes {
    baseChartMessageFont: string
    baseChartMessageFontSize: number
    baseChartMessageColor: string
    baseChartMessageImageHAlign: string
    baseChartMessageImageVAlign: string
    baseChartMessageImageAlpha: number
    baseChartMessageImageScale: number
    loadMessage: string
    loadMessageFont: string
    loadMessageFontSize: number
    loadMessageColor: string
    loadMessageImageHAlign: string
    loadMessageImageVAlign: string
    loadMessageImageAlpha: number
    loadMessageImageScale: number
    typeNotSupportedMessage: string
    typeNotSupportedMessageFont: string
    typeNotSupportedMessageFontSize: number
    typeNotSupportedMessageColor: string
    typeNotSupportedMessageImageHAlign: string
    typeNotSupportedMessageImageVAlign: string
    typeNotSupportedMessageImageAlpha: number
    typeNotSupportedMessageImageScale: number
    renderErrorMessage: string
    renderErrorMessageFont: string
    renderErrorMessageFontSize: number
    renderErrorMessageColor: string
    renderErrorMessageImageHAlign: string
    renderErrorMessageImageVAlign: string
    renderErrorMessageImageAlpha: number
    renderErrorMessageImageScale: number
    dataLoadStartMessage: string
    dataLoadStartMessageFont: string
    dataLoadStartMessageFontSize: string
    dataLoadStartMessageColor: string
    dataLoadStartMessageImageHAlign: string
    dataLoadStartMessageImageVAlign: string
    dataLoadStartMessageImageAlpha: number
    dataLoadStartMessageImageScale: number
    dataEmptyMessage: string
    dataEmptyMessageFont: string
    dataEmptyMessageFontSize: number
    dataEmptyMessageColor: string
    dataEmptyMessageImageHAlign: string
    dataEmptyMessageImageVAlign: string
    dataEmptyMessageImageAlpha: number
    dataEmptyMessageImageScale: number
    dataLoadErrorMessage: string
    dataLoadErrorMessageFont: string
    dataLoadErrorMessageFontSize: number
    dataLoadErrorMessageColor: string
    dataLoadErrorMessageImageHAlign: string
    dataLoadErrorMessageImageVAlign: string
    dataLoadErrorMessageImageAlpha: number
    dataLoadErrorMessageImageScale: number
    dataInvalidMessage: string
    dataInvalidMessageFont: string
    dataInvalidMessageFontSize: number
    dataInvalidMessageColor: string
    dataInvalidMessageImageHAlign: string
    dataInvalidMessageImageVAlign: string
    dataInvalidMessageImageAlpha: number
    dataInvalidMessageImageScale: number
  }
}

declare namespace DataOfChart {
  interface IVerticalDataSeparatorLines {
    vLine: string
    color: string
    thickness: number
    alpha: number
    dashed: boolean
    dashLen: number
    dashGap: number
    label: string
    showLabelBorder: boolean
    linePosition: number
    labelPosition: number
    labelHAlign: string
    labelVAlign: string
  }

  interface IDataObject {
    alpha: number
    color: string
    dashed: boolean
    displayValue: string
    label: string
    link: string
    showLabel: boolean
    showValue: boolean
    valueFontColor: string
    valueBgColor: string
    valueBorderColor: string
    toolText: string
    value: number
    labelFont: string
    labelFontColor: string
    labelFontSize: number
    labelFontBold: boolean
    labelFontItalic: boolean
    labelBgColor: string
    labelBorderColor: string
    labelAlpha: number
    labelBgAlpha: number
    labelBorderAlpha: number
    labelBorderPadding: number
    labelBorderRadius: number
    labelBorderThickness: number
    labelBorderDashed: boolean
    labelBorderDashLen: number
    labelBorderDashGap: number
    labelLink: URL
    hoverColor: string
    hoverAlpha: number
    hoverGradientColor: string
    hoverRatio: number
    hoverAngle: number
    borderHoverColor: string
    borderHoverAlpha: number
    borderHoverThickness: number
    borderHoverDashed: boolean
    borderHoverDashLen: number
  }
}

declare namespace Line {
  interface ITrendLines {
    startValue: number
    endValue: number
    displayValue: string
    color: string
    isTrendZone: boolean
    showOnTop: boolean
    thickness: number
    alpha: number
    dashed: boolean
    dashLen: number
    dashGap: number
    toolText: string
  }
  type IAnchors = AttributesOfChart.IAnchors
}

declare namespace InterfaceOfFusionChart {
  interface IArea2D {
    chart: AttributesOfChart.IChartTitlesAndAxisNames &
      AttributesOfChart.IFunctionalAttributes
    data: DataOfChart.IDataObject
  }

  type IBar2D = IArea2D
}

declare namespace IBubble {
  interface IQuadrants {
    drawQuadrant: boolean
    quadrantXVal: number
    quadrantYVal: number
    quadrantLineColor: string
    quadrantLineThickness: number
    quadrantLineAlpha: number
    quadrantLineDashed: boolean
    quadrantLineDashLen: number
    quadrantLineDashGap: number
    quadrantLabelTL: string
    quadrantLabelTR: string
    quadrantLabelBL: string
    quadrantLabelBR: string
    quadrantLabelFont: string
    quadrantLabelTLFont: string
    quadrantLabelTRFont: string
    quadrantLabelBLFont: string
    quadrantLabelBRFont: string
    quadrantLabelFontColor: string
    quadrantLabelTLFontColor: string
    quadrantLabelTRFontColor: string
    quadrantLabelBLFontColor: string
    quadrantLabelBRFontColor: string
    quadrantLabelFontAlpha: number
    quadrantLabelTLFontAlpha: number
    quadrantLabelTRFontAlpha: number
    quadrantLabelBLFontAlpha: number
    quadrantLabelBRFontAlpha: number
    quadrantLabelFontSize: number
    quadrantLabelTLFontSize: number
    quadrantLabelTRFontSize: number
    quadrantLabelBLFontSize: number
    quadrantLabelBRFontSize: number
    quadrantLabelFontBold: boolean
    quadrantLabelTLFontBold: boolean
    quadrantLabelTRFontBold: boolean
    quadrantLabelBLFontBold: boolean
    quadrantLabelBRFontBold: boolean
    quadrantLabelFontItalic: boolean
    quadrantLabelTLFontItalic: boolean
    quadrantLabelTRFontItalic: boolean
    quadrantLabelBLFontItalic: boolean
    quadrantLabelBRFontItalic: boolean
    quadrantLabelBorderColor: string
    quadrantLabelTLBorderColor: string
    quadrantLabelTRBorderColor: string
    quadrantLabelBLBorderColor: string
    quadrantLabelBRBorderColor: string
    quadrantLabelBorderAlpha: number
    quadrantLabelTLBorderAlpha: number
    quadrantLabelTRBorderAlpha: number
    quadrantLabelBLBorderAlpha: number
    quadrantLabelBRBorderAlpha: number
    quadrantLabelBorderThickness: number
    quadrantLabelTLBorderThickness: number
    quadrantLabelTRBorderThickness: number
    quadrantLabelBLBorderThickness: number
    quadrantLabelBRBorderThickness: number
    quadrantLabelBorderPadding: number
    quadrantLabelTLBorderPadding: number
    quadrantLabelTRBorderPadding: number
    quadrantLabelBLBorderPadding: number
    quadrantLabelBRBorderPadding: number
    quadrantLabelBorderRadius: number
    quadrantLabelTLBorderRadius: number
    quadrantLabelTRBorderRadius: number
    quadrantLabelBLBorderRadius: number
    quadrantLabelBRBorderRadius: number
    quadrantLabelBorderDashed: boolean
    quadrantLabelTLBorderDashed: boolean
    quadrantLabelTRBorderDashed: boolean
    quadrantLabelBLBorderDashed: boolean
    quadrantLabelBRBorderDashed: boolean
    quadrantLabelBorderDashlen: number
    quadrantLabelTLBorderDashlen: number
    quadrantLabelTRBorderDashlen: number
    quadrantLabelBLBorderDashlen: number
    quadrantLabelBRBorderDashlen: number
    quadrantLabelBorderDashgap: number
    quadrantLabelTLBorderDashgap: number
    quadrantLabelTRBorderDashgap: number
    quadrantLabelBLBorderDashgap: number
    quadrantLabelBRBorderDashgap: number
    quadrantLabelBgColor: string
    quadrantLabelTLBgColor: string
    quadrantLabelTRBgColor: string
    quadrantLabelBLBgColor: string
    quadrantLabelBRBgColor: string
    quadrantLabelBgAlpha: number
    quadrantLabelTLBgAlpha: number
    quadrantLabelTRBgAlpha: number
    quadrantLabelBLBgAlpha: number
    quadrantLabelBRBgAlpha: number
    quadrantLabelPadding: number
  }
}

declare namespace AttributesOfMapChart {
  interface IMapFunctionalAttribute {
    showLabels: boolean
    includeNameInLabels: boolean
    includeValueInLabels: boolean
    useSNameInLabels: boolean
    useSNameInToolTip: boolean
    showShadow: boolean
    caption: string
    subCaption: string
    captionPosition: string
    clickURL: string
    hoverOnEmpty: boolean
    aboutMenuItemLabel: string
    entityLabelsOnTop: boolean
  }

  interface IMapCosMetics {
    showCanvasBorder: boolean
    canvasBorderColor: string
    canvasBorderThickness: number
    canvasBorderAlpha: number
    bgColor: string
    bgAlpha: number
    bgRatio: number
    bgAngle: number
    bgImage: string
    bgImageAlpha: number
    bgImageDisplayMode: string
    bgImageVAlign: string
    bgImageHAlign: string
    bgImageScale: number
    logoURL: string
    logoPosition: string
    logoAlpha: number
    logoScale: number
    logoLink: string
  }

  interface IMapEntitiesCosmetics {
    showBorder: boolean
    borderColor: string
    borderAlpha: number
    fillColor: string
    fillAlpha: Alpha
    useHoverColor: boolean
    hoverColor: string
    nullEntityColor: string
    nullEntityAlpha: number
    showEntityToolTip: boolean
    labelConnectorColor: string
    labelConnectorAlpha: number
  }

  type IMapNumberFormatting = AttributesOfChart.INumberFormatting

  interface IMapLegendProperties {
    showLegend: boolean
    interactiveLegend: boolean
    legendAllowDrag: boolean
    legendCaption: string
    reverseLegend: boolean
    legendPosition: string
    legendIconScale: number
    legendShadow: boolean
    legendBgColor: string
    legendBgAlpha: number
    legendBorderColor: string
    legendBorderThickness: number
    legendBorderAlpha: number
    legendScrollBgColor: string
    legendScrollBarColor: string
    legendScrollBtnColor: string
    legendPointerColor: string
    legendPointerAlpha: number
    legendPointerBorderThickness: number
    legendPointerBorderAlpha: number
    legendPointerBorderColor: string
    legendScaleLineColor: string
    legendScaleLineAlpha: number
    legendScaleLineThickness: number
  }

  interface IMapDataObject {
    value: number
    displayValue: string
    toolText: string
    color: string
    alpha: number
    link: string
    font: string
    fontSize: string
    fontColor: boolean
    fontBold: boolean
    showLabel: boolean
    showToolTip: boolean
    labelConnectorColor: string
    labelConnectorAlpha: number
    useHoverColor: boolean
  }

  interface IMapToolTip {
    showToolTip: boolean
    toolTipBgColor: string
    toolTipBorderColor: string
    toolTipSepChar: string
    showToolTipShadow: boolean
  }

  interface IMapFontProperties {
    baseFont: string
    baseFontSize: number
    baseFontColor: string
  }

  interface IMapPaddingAndMargins {
    legendPadding: number
    chartLeftMargin: number
    chartRightMargin: number
    chartTopMargin: number
    chartBottomMargin: number
  }

  interface IMapAttributeToAllowExportingOfMapsAsImagePdfSvgXLSX {
    exportEnabled: boolean
    exportAction: string
    exportHandler: string
    exportFormats: string
    exportAtClientSide: boolean
    exportShowMenuItem: boolean
    exportTargetWindow: string
    exportFileName: string
  }

  interface ImapMarkerProperties {
    markerFont: string
    markerFontSize: number
    markerFontColor: string
    showMarkerToolTip: boolean
    showMarkerLabels: boolean
    markerLabelPadding: number
    markerBgColor: string
    markerBorderColor: string
    markerRadius: number
    connectorColor: string
    connectorAlpha: number
    showHoverEffect: boolean
    fillHoverColor: string
    fillHoverAlpha: number
    fillHoverRatio: string
    fillHoverAngle: number
    borderHoverThickness: number
    borderHoverColor: string
    borderHoverAlpha: number
    'markerConnColor-deprecated': string
    'markerConnAlpha-deprecated': number
    connectorThickness: number
    'markerConnThickness-deprecated': number
    showConnectorToolTip: boolean
    connectorDashed: boolean
    'markerConnDashed-deprecated': boolean
    connectorDashLen: number
    'markerConnDashLen-deprecated': number
    connectorDashGap: number
    'markerConnDashGap-deprecated': number
    autoScaleMarkers: boolean
    markerFillColor: string
    markerFillAlpha: number
    markerFillRatio: number
    markerFillAngle: number
    markerBorderAlpha: number
  }

  interface IMapDefinitionObject {
    id: string | number
    shapeId: string
    x: number
    y: number
    label: string
    labelPos: string
    toolText: string
    link: string
    scale: number
    radius: number
  }

  interface IMapApplicationObject {
    id: string | number
    shapeId: string
    label: string
    labelPos: string
    toolText: string
    link: string
    scale: number
  }

  interface IMapShapeObject {
    id: string | number
    type: string
    url: string
    sides: number
    alpha: number
    labelPadding: number
    fillColor: string
    fillAlpha: number
    fillRatio: number
    fillAngle: number
    fillPattern: string
    showBorder: boolean
    borderColor: string
    borderThickness: number
    borderAlpha: number
    radius: number
    innerRadius: number
    startAngle: number
    endAngle: number
    xScale: number
    yScale: number
    vAlign: string
  }

  interface IMapConnectorsObject {
    from: string
    to: string
    link: string
    label: string
    toolText: string
    thickness: number
    color: string
    alpha: number
    dashed: boolean
    dashLen: number
    dashGap: number
    showHoverEffect: boolean
    hoverColor: string
    hoverAlpha: number
    hoverThickness: number
    showToolTip: boolean
  }

  interface IMapEntityDefObject {
    internalId: string
    newId: string
    sName: string
    lName: string
    showHoverEffect: boolean
    entityBorderHoverThickness: number
    fillHoverColor: string
    fillHoverAlpha: number
    fillHoverRatio: string
    fillHoverAngle: number
  }

  interface IMapColorRangeObject {
    gradient: boolean
    minValue: number
    code: string
    alpha: number
    startLabel: string
    endLabel: string
  }

  interface IMapColorObject {
    minValue: number
    maxValue: number
    displayValue: string
    code: string
    alpha: number
  }

  interface IMapHoverEffects {
    showHoverEffect: boolean
    showEntityHoverEffect: boolean
    entityFillHoverColor: string
    entityFillHoverAlpha: number
    entityFillHoverRatio: string
    entityFillHoverAngle: number
    markerFillHoverColor: string
    markerFillHoverAlpha: number
    markerFillHoverAngle: number
    markerFillHoverRatio: string
    markerBorderHoverThickness: number
    markerBorderHoverColor: string
    markerBorderHoverAlpha: number
    connectorHoverColor: string
    connectorHoverThickness: number
    connectorHoverAlpha: number
  }
}

declare namespace ICandlestickChart {
  interface IPrimaryYAxisNameCosmetics {
    pYAxisNameFont: string
    pYAxisNameFontColor: string
    pYAxisNameFontSize: number
    pYAxisNameFontBold: boolean
    pYAxisNameFontItalic: boolean
    pYAxisNameBgColor: string
    pYAxisNameBorderColor: string
    pYAxisNameAlpha: number
    pYAxisNameFontAlpha: number
    pYAxisNameBgAlpha: number
    pYAxisNameBorderAlpha: number
    pYAxisNameBorderPadding: number
    pYAxisNameBorderRadius: number
    pYAxisNameBorderThickness: number
    pYAxisNameBorderDashed: boolean
    pYAxisNameBorderDashLen: number
    pYAxisNameBorderDashGap: number
  }

  interface IVolumeYAxisNameCosmetics {
    vYAxisNameFont: string
    vYAxisNameFontColor: string
    vYAxisNameFontSize: number
    vYAxisNameFontBold: boolean
    vYAxisNameFontItalic: boolean
    vYAxisNameBgColor: string
    vYAxisNameBorderColor: string
    vYAxisNameAlpha: number
    vYAxisNameFontAlpha: number
    vYAxisNameBgAlpha: number
    vYAxisNameBorderAlpha: number
    vYAxisNameBorderPadding: number
    vYAxisNameBorderRadius: number
    vYAxisNameBorderThickness: number
    vYAxisNameBorderDashed: boolean
    vYAxisNameBorderDashLen: number
    vYAxisNameBorderDashGap: number
  }

  interface ITrendsetObject {
    trendSetColor: string
    trendSetAlpha: number
    trendSetThickness: number
    trendSetDashed: boolean
    trendSetDashLen: number
    trendSetDashGap: number
    alpha: number
    color: string
    dashed: boolean
    dashlen: number
    dashgap: number
    includeinlegend: boolean
    thickness: number
  }
}

declare namespace IChordChart {
  interface INodeConfiguration {
    nodeLabelPadding: number
    showNodeLabels: boolean
    nodeLabelPosition: string
    nodeThickness: number
    nodeHoverAlpha: number
    showNodeBorder: boolean
    minNodeSize: number
    nodeBorderDashed: boolean
    nodeBorderDashedLen: number
    nodeBorderDashedGap: number
    nodeBorderColor: string
    nodeBorderThickness: number
    nodeBorderAlpha: number
  }

  interface INodeLabelConfiguration {
    nodeSpacing: number
    nodeAlpha: number
    nodeLinkPadding: number
    nodeLabelFont: string
    nodeLabelColor: string
    nodeLabelFontSize: number
  }

  interface ILinksConfiguration {
    linkHoverAlpha: number
    showLinkBorder: boolean
    linkBorderThickness: number
  }

  interface INodeObject {
    color: string
    alpha: number
    showLabel: boolean
    hoveralpha: number
  }
}

declare namespace IPieAndDoughnut {
  interface IPieAndDoughnutProperties {
    pieRadius: number
    doughnutRadius: number
    startingAngle: number
    radius3D: number
    enableSlicing: boolean
    slicingDistance: number
    enableRotation: boolean
    enableMultiSlicing: boolean
  }

  interface ISmartLabelAndLines {
    labelDistance: number
    enableSmartLabels: boolean
    skipOverlapLabels: boolean
    isSmartLineSlanted: boolean
    smartLineColor: string
    smartLineThickness: number
    smartLineAlpha: number
    manageLabelOverflow: boolean
    useEllipsesWhenOverflow: boolean
    labelPosition: string
    valuePosition: string
    minAngleForLabel: number
    minAngleForValue: number
  }
}

declare namespace IDragNodeChart {
  interface IFormAndMenuOption {
    enableSubmit: boolean
    formAction: string
    formMethod: string
    formTarget: string
    submitText: string
    submitFormUsingAjax: boolean
    enableRestore: boolean
    restoreText: string
  }

  interface IConnectorsObject {
    alpha: number
    arrowAtEnd: boolean
    arrowAtStart: boolean
    color: string
    dashed: boolean
    dashLen: number
    dashGap: number
    stdThickness: number
    strength: number
  }

  interface IConnectorObject {
    alpha: Alpha
    arrowAtEnd: boolean
    arrowAtStart: boolean
    color: string
    dashed: boolean
    dashLen: number
    dashGap: number
    from: string
    label: string
    link: string
    strength: number
    to: string
  }

  interface ILabelsObjectAndLabelObject {
    allowdrag: boolean
    alpha: Alpha
    bgColor: string
    borderColor: string
    color: string
    fontsize: number
    padding: boolean
    text: string
    x: number
    y: number
  }
}

declare namespace IDragableAreaChart {
  interface IDraggingRelatedAttributes {
    allowAxisChange: boolean
    snapToDivOnly: boolean
    snapToDiv: boolean
    snapToDivRelaxation: number
    doNotSnap: boolean
  }

  interface ITrendLines {
    dashGap: number
    valueOnRight: boolean
    displayValue: string
    color: string
    isTrendZone: boolean
    showOnTop: boolean
    thickness: number
    alpha: number
    dashed: boolean
    dashLen: number
    startValue: number
    endValue: number
    toolText: string
  }
}

declare namespace IFunnelChart {
  interface IFunnelFunctionalProperties {
    streamlinedData: boolean
    is2D: boolean
    isSliced: boolean
    isHollow: boolean
    useSameSlantAngle: boolean
    funnelYScale: number
  }

  interface IFunnelCosmeticProperties {
    showPlotBorder: boolean
    plotBorderColor: string
    plotBorderThickness: number
    plotBorderAlpha: number
    plotFillAlpha: number
    minPlotHeightForValue: number
  }
}

declare namespace IGanttChart {
  interface IScrollBarProperties {
    scrollColor: string
    scrollPosition: string
    scrollPadding: number
    scrollHeight: number
    scrollWidth: number
    scrollBtnWidth: number
    scrollBtnPadding: number
    flatscrollbars: boolean
  }

  interface IChartLevelAttributesForCustomizingMilestoneLabels {
    milestoneFont: string
    milestoneFontSize: string
    milestoneFontColor: string
    milestoneFontBold: string
    milestoneFontItalic: string
  }

  interface IProcessesObject {
    align: string
    bgAlpha: number
    bgColor: string
    font: string
    fontColor: string
    fontSize: number
    headerAlign: string
    headerBgAlpha: number
    headerBgColor: string
    headerFont: string
    headerFontColor: string
    headerFontSize: number
    headerIsBold: boolean
    headerIsItalic: boolean
    headerIsUnderline: boolean
    headerVAlign: string
    headertext: string
    isBold: boolean
    isItalic: boolean
    isUnderline: boolean
    positionInGrid: string
    hoverBandAlpha: number
    hoverBandColor: string
    showGanttPaneHoverBand: boolean
    showHoverBand: boolean
    vAlign: string
    width: number
  }

  interface IProcessObject {
    align: string
    bgAlpha: number
    bgColor: string
    font: string
    fontColor: string
    fontSize: string
    id: string
    isBold: boolean
    isItalic: boolean
    isUnderline: boolean
    label: string
    link: string
    hoverBandAlpha: number
    hoverBandColor: string
    showGanttPaneHoverBand: boolean
    showHoverBand: boolean
    vAlign: string
    height: number
  }

  interface ITasksObject {
    alpha: number
    borderalpha: number
    bordercolor: string
    borderthickness: number
    color: string
    font: string
    fontcolor: string
    fontsize: number
    showborder: boolean
    showenddate: boolean
    showlabels: boolean
    showpercentlabel: boolean
    showstartdate: boolean
    slackFillColor: string
    showHoverEffect: boolean
    hoverFillAlpha: number
    hoverFillColor: string
    slackHoverFillAlpha: boolean
    slackHoverFillColor: number
  }

  interface ITaskObject {
    alpha: number
    animation: boolean
    borderAlpha: number
    borderColor: string
    borderThickness: number
    color: string
    end: string
    font: string
    fontColor: string
    fontSize: number
    height: number
    id: string | number
    label: string
    link: string
    percentComplete: number
    processId: string
    showAsGroup: boolean
    showBorder: boolean
    showEndDate: boolean
    showLabel: boolean
    showPercentLabel: boolean
    showStartDate: boolean
    showHoverEffect: boolean
    hoverFillAlpha: number
    hoverFillColor: string
    slackHoverFillAlpha: boolean
    slackHoverFillColor: number
    start: string
    toolText: string
    topPadding: number
  }

  interface IDataTableObject {
    align: string
    bgAlpha: number
    bgColor: string
    font: string
    fontColor: string
    fontSize: number
    headerAlign: string
    headerBgAlpha: number
    headerBgColor: string
    headerFont: string
    headerFontColor: string
    headerFontSize: number
    headerIsBold: boolean
    headerIsItalic: boolean
    headerIsUnderline: boolean
    headerVAlign: string
    isBold: boolean
    isItalic: boolean
    isUnderline: boolean
    vAlign: string
  }

  interface IDataColumnObject {
    align: string
    bgAlpha: number
    bgColor: string
    font: string
    fontColor: string
    fontSize: number
    headerAlign: string
    headerBgAlpha: number
    headerBgColor: string
    headerFont: string
    headerFontColor: string
    headerFontSize: number
    headerIsBold: boolean
    headerIsItalic: boolean
    headerIsUnderline: boolean
    headerLink: string
    headerText: string
    headerVAlign: string
    isBold: boolean
    isItalic: boolean
    isUnderline: boolean
    vAlign: string
    width: number
  }

  interface ITextObject {
    align: string
    bgAlpha: number
    bgColor: string
    font: string
    fontColor: string
    fontSize: number
    isBold: boolean
    isItalic: boolean
    isUnderline: boolean
    label: string
    link: string
    vAlign: string
  }

  interface IMilestoneObject {
    alpha: number
    borderColor: string
    borderThickness: number
    borderAlpha: number
    color: string
    date: Date
    link: string
    numSides: number
    radius: number
    shape: string
    startAngle: number
    taskId: string
    toolText: string
    showHoverEffect: boolean
    hoverFillColor: string
    hoverFillAlpha: number
    hoverBorderColor: string
    hoverBorderAlpha: number
    label: string
    font: string
    fontSize: string
    fontColor: string
    milestoneFontBold: string
    fontItalic: string
  }
}

declare namespace IHeadMapChart {
  interface IRowsAndRowObject {
    id: number | string
    label: string
    showLabel: string
  }

  interface IColumnsAndColumnObject {
    id: number | string
    label: string
    showLabel: string
  }

  interface IDatasetObjectAndDataObject {
    rowId: string
    columnId: string
    colorRangeLabel: string
    value: number
    displayValue: number | string
    tlLabel: number | string
    trLabel: number | string
    blLabel: number | string
    brLabel: number | string
    color: string
    link: string
    toolText: string
    showValue: boolean
    valueFontColor: string
    valueBgColor: string
    valueBorderColor: string
    alpha: number
  }

  interface IColorRangeObject {
    code: string
    endLabel: string
    gradient: boolean
    mapByPercent: boolean
    minValue: number
    startLabel: string
  }

  interface IColorObject {
    alpha: number
    code: string
    label: string
    maxValue: number
    minValue: number
  }
}

declare namespace IHorizontalBulletGraph {
  interface AxisTickMarkProperties {
    setAdaptiveYMin: boolean
    upperLimit: number
    lowerLimit: number
    upperLimitDisplay: string
    lowerLimitDisplay: string
    showTickMarks: boolean
    showTickValues: boolean
    showLimits: boolean
    ticksBelowGraph: boolean
    tickValueStep: number
    majorTMNumber: number
    majorTMColor: color
    majorTMAlpha: number
    majorTMHeight: number
    majorTMThickness: number
    minorTMNumber: number
    minorTMColor: color
    minorTMAlpha: number
    minorTMHeight: number
    minorTMThickness: number
    tickMarkDistance: number
    tickValueDistance: number
    tickValueDecimals: number
    forceTickValueDecimals: boolean
    placeTicksInside: boolean
    placeValuesInside: boolean
    adjustTM: boolean
  }
  interface IRealTimeProperties {
    dataStreamURL: URL
    refreshInterval: number
    dataStamp: string
    showRTMenuItem: boolean
  }

  interface IColorRangeAndColorObject {
    alpha: number
    colorRangeFillMix: string
    colorRangeFillRatio: string
    showColorRangeBorder: boolean
    colorRangeBorderColor: color
    colorRangeBorderThickness: number
    colorRangeBorderAlpha: number
    showShadow: boolean
    maxValue: number
    minValue: number
    value: number
  }
}

declare namespace IHorizontalLEDChart {
  interface IGuageScaleProperties {
    gaugeFillColor: color
    showGaugeBorder: boolean
    gaugeBorderColor: color
    gaugeBorderThickness: number
    gaugeBorderAlpha: number
  }

  interface ILEDProperties {
    ledSize: number
    ledGap: number
    useSameFillColor: boolean
    useSameFillBgColor: boolean
  }

  interface IMesageLogger {
    useMessageLog: boolean
    messageLogWPercent: number
    messageLogHPercent: number
    messageLogShowTitle: boolean
    messageLogTitle: string
    messageLogColor: color
    messageGoesToLog: boolean
    messageGoesToJS: boolean
    messageJSHandler: string
    messagePassAllToJS: boolean
  }

  interface IColorRangeAndColorObject {
    alpha: number
    borderAlpha: number
    borderColor: color
    code: color
    maxValue: number
    minValue: number
  }
}

declare namespace IKagiChart {
  interface IKagiPlotProperties {
    reversalValue: number
    reversalPercentage: number
    maxHShiftPercent: number
    rallyColor: color
    rallyAlpha: number
    rallyThickness: number
    rallyDashed: boolean
    rallyDashGap: number
    rallyDashLen: number
    declineColor: color
    declineAlpha: number
    declineThickness: number
    declineDashed: boolean
    declineDashGap: number
    declineDashLen: number
  }
}

declare namespace IMultiLevelPieChart {
  interface IHightLightEffect {
    highlightParentPieSlices: boolean
    highlightChildPieSlices: boolean
  }
}

declare namespace IMlutiSeries2DDualYCombinationChart {
  interface IPrimaryYAxisNameCosmetics {
    pYAxisNameFont: string
    pYAxisNameFontColor: color
    pYAxisNameFontSize: number
    pYAxisNameFontBold: boolean
    pYAxisNameFontItalic: boolean
    pYAxisNameBgColor: color
    pYAxisNameBorderColor: color
    pYAxisNameAlpha: number
    pYAxisNameFontAlpha: number
    pYAxisNameBgAlpha: number
    pYAxisNameBorderAlpha: number
    pYAxisNameBorderPadding: number
    pYAxisNameBorderRadius: number
    pYAxisNameBorderThickness: number
    pYAxisNameBorderDashed: boolean
    pYAxisNameBorderDashLen: number
    pYAxisNameBorderDashGap: number
  }

  interface ISecondaryYAxisNameCosmetics {
    sYAxisNameFont: string
    sYAxisNameFontColor: color
    sYAxisNameFontSize: number
    sYAxisNameFontBold: boolean
    sYAxisNameFontItalic: boolean
    sYAxisNameBgColor: color
    sYAxisNameBorderColor: color
    sYAxisNameAlpha: number
    sYAxisNameFontAlpha: number
    sYAxisNameBgAlpha: number
    sYAxisNameBorderAlpha: number
    sYAxisNameBorderPadding: number
    sYAxisNameBorderRadius: number
    sYAxisNameBorderThickness: number
    sYAxisNameBorderDashed: boolean
    sYAxisNameBorderDashLen: number
    sYAxisNameBorderDashGap: number
  }
}
declare namespace IMultiSeries3DSingleYCombinationChart {
  interface IDivisionalLinesAndGridsAndZeroPlane {
    numDivLines: number
    divLineEffect: string
    divLineColor: color
    divLineThickness: number
    divLineAlpha: number
    divLineDashed: boolean
    divLineDashLen: number
    divLineDashGap: number
    zeroPlaneMesh: boolean
    zeroPlaneColor: color
    zeroPlaneThickness: number
    zeroPlaneAlpha: number
    showZeroPlaneValue: boolean
    showAlternateHGridColor: boolean
    alternateHGridColor: color
  }
}

declare namespace IPyramidChart {
  interface IPyramidFunctionalProperties {
    is2D: boolean
    isSliced: boolean
    pyramidYScale: number
    use3dlighting: boolean
  }

  interface IPyramidCosmeticProperties {
    showPlotBorder: boolean
    plotBorderColor: color
    plotBorderThickness: number
    plotBorderAlpha: number
    plotFillAlpha: number
    minPlotHeightForValue: number
  }
}
declare namespace IRealTimeAngularChart {
  interface IAxisAndTickMarkProperties {
    setAdaptiveMin: boolean
    upperLimit: number
    lowerLimit: number
    lowerLimitDisplay: string
    upperLimitDisplay: string
    showTickMarks: boolean
    showTickValues: boolean
    showLimits: boolean
    adjustTM: boolean
    placeTicksInside: boolean
    placeValuesInside: boolean
    majorTMNumber: number
    majorTMColor: color
    majorTMAlpha: number
    majorTMHeight: number
    majorTMThickness: number
    minorTMNumber: number
    minorTMColor: color
    minorTMAlpha: number
    minorTMHeight: number
    minorTMThickness: number
    tickValueDistance: number
    trendValueDistance: number
    tickValueStep: number
    tickValueDecimals: number
    forceTickValueDecimals: boolean
    autoAlignTickValues: boolean
  }

  interface IRealTimeProperties {
    dataStreamURL: string
    refreshInterval: number
    dataStamp: string
    showRTMenuItem: boolean
  }

  interface IguageScaleProperties {
    gaugeStartAngle: number
    gaugeEndAngle: number
    gaugeOriginX: number
    gaugeOriginY: number
    gaugeOuterRadius: number
    gaugeInnerRadius: number
    gaugeFillMix: string
    gaugeFillRatio: string
    showGaugeBorder: boolean
    gaugeBorderColor: string
    gaugeBorderThickness: number
    gaugeBorderAlpha: number
  }

  interface ITrendPointObjectAndPointObject {
    borderColor: color
    color: color
    dashed: boolean
    dashLen: number
    dashGap: number
    displayValue: string
    endValue: number
    innerRadius: number
    markerBorderColor: color
    markerColor: color
    markerRadius: number
    markerTooltext: string
    radius: string
    showBorder: boolean
    startValue: number
    thickness: number
    useMarker: boolean
    valueInside: boolean
  }
}
declare namespace IRealTimeAreaChart {
  interface IPlotProperties {
    showShadow: boolean
    showPlotBorder: boolean
    plotBorderColor: Color
    plotBorderThickness: number
    plotBorderAlpha: number
    plotBorderDashed: boolean
    plotBorderDashLen: number
    plotBorderDashGap: number
    plotFillColor: Color
    plotFillAlpha: number
    plotGradientColor: Color
    plotFillAngle: number
    usePlotGradientColor: boolean
    drawFullAreaBorder: boolean
    inheritPlotBorderColor: boolean
  }

  interface ICanvasCosmetics {
    canvasBgColor: Color
    canvasBgAlpha: number
    canvasBgRatio: string
    canvasBgAngle: number
    canvasBorderColor: Color
    canvasBorderThickness: number
    canvasBorderAlpha: number
  }

  interface IZeroPlaneProperties {
    zeroPlaneColor: Color
    zeroPlaneThickness: number
    zeroPlaneAlpha: number
    showZeroPlaneValue: boolean
  }
}
declare namespace IRealTimeBulbChart {
  interface IGuageScaleColorRangeProperties {
    gaugeFillAlpha: number
    gaugeOriginX: number
    gaugeOriginY: number
    gaugeRadius: number
    showGaugeBorder: boolean
    gaugeBorderColor: string
    gaugeBorderThickness: number
    gaugeBorderAlpha: number
    is3D: boolean
    upperLimit: number
    lowerLimit: number
  }
}

declare namespace IRealTimeCylinderChart {
  interface ICylinderProperties {
    cylOriginX: number
    cylOriginY: number
    cylRadius: number
    cylHeight: number
    cylYScale: number
    cylFillColor: Color
    cylGlassColor: Color
  }
}

declare namespace IRealTimeHorizontalLinear {
  interface IPointerPreperties {
    pointerRadius: number
    pointerBgColor: Color
    pointerBgAlpha: number
    pointerSides: number
    pointerBorderThickness: number
    pointerBorderColor: Color
    pointerBorderAlpha: number
    showPointerShadow: boolean
  }

  interface IPointerObject {
    bgAlpha: number
    borderAlpha: number
    borderColor: Color
    borderThickness: number
    color: Color
    editMode: boolean
    id: string
    link: string
    radius: number
    showValue: boolean
    sides: number
    toolText: string
    value: number
  }

  interface ITrendPointObjectAndPointObject {
    alpha: number
    color: Color
    dashed: boolean
    dashLen: number
    dashGap: number
    displayValue: string
    endValue: number
    markerBorderColor: Color
    markerColor: Color
    markerRadius: number
    markerTooltext: string
    showOnTop: boolean
    startValue: number
    useMarker: boolean
  }
}

declare namespace IRealTimeLineChart {
  interface IPlotProperties {
    showShadow: boolean
    lineColor: Color
    lineThickness: number
    lineAlpha: number
    lineDashed: boolean
    lineDashLen: number
    lineDashGap: number
  }
}

declare namespace ISankeyDiagramChart {
  interface INodeLabelConfiguration {
    inheritLabelColorFromNode: boolean
    nodeLabelPadding: number
    nodeSpacing: number
    nodeWidth: number
    nodeRelaxation: boolean
    nodeLinkPadding: number
    showNodeLabels: boolean
    showNodeValues: boolean
    rotateNodeLabels: boolean
    nodeLabelPosition: string
    nodeColor: Color
    nodeAlpha: number
  }

  interface INodeLabelCosmetics {
    nodeLabelFont: string
    nodeLabelFontColor: Color
    nodeLabelAlpha: number
    nodeLabelBgColor: Color
    nodeLabelBorderColor: Color
    nodeLabelBorderThickness: number
    nodeLabelFontSize: number
    nodeLabelFontBold: boolean
    nodeLabelFontItalic: boolean
    nodeLabelborderradius: number
    nodeLabelBorderPadding: number
    nodeLabelBorderDashed: boolean
    nodeLabelBorderDashlen: number
    nodeLabelBorderDashgap: number
  }

  interface ILinksCosmetics {
    linkColor: Color
    linkAlpha: number
    linkCurvature: number
  }

  interface ILinksObject {
    from: string
    to: string
    value: number
    color: Color
    alpha: number
    hoverAlpha: number
    curvature: number
  }

  interface INodeObject {
    label: string
    showLabel: boolean
    showValue: boolean
    rotateLabel: boolean
    labelPosition: string
    labelFontColor: Color
    labelAlpha: number
    Labelbgcolor: Color
    Labelbordercolor: Color
    color: Color
    alpha: number
    hoveralpha: number
  }
}

declare namespace IScrollChart {
  interface IScrollProperties {
    scrollColor: Color
    scrollPosition: string
    scrollHeight: number
    scrollPadding: number
    flatscrollbars: boolean
  }
}

declare namespace ISparkColumnChart {
  interface IPeriodBlockProperties {
    periodLength: number
    periodColor: Color
    periodAlpha: number
  }
}

declare namespace ISparkLineChart {
  interface IOpenAndCloseAndHightAndLowProperties {
    openColor: Color
    closeColor: Color
    highColor: Color
    lowColor: Color
    showOpenAnchor: boolean
    showCloseAnchor: boolean
    showHighAnchor: boolean
    showLowAnchor: boolean
    showOpenValue: boolean
    showCloseValue: boolean
    showHighLowValue: boolean
  }

  type IPeriodBlockProperties = ISparkColumnChart.IPeriodBlockProperties
}

declare namespace ISparkWinOrLossChart {
  interface IDataPlotWinOrLossProperties {
    winColor: Color
    lossColor: Color
    drawColor: Color
    scoreLessColor: Color
  }
}

declare namespace ISunburstChart {
  interface IPieOrDoughtnutProperties {
    pieRadius: number
    innerRadius: number
    pieBorderColor: string
    totalAngle: number
    centerAngle: number
    originX: number
    originY: number
  }

  interface IDataObject {
    id: string
    parent: string
    label: string
    value: number
  }
}

declare namespace IZoomChart {
  interface IPeakDataAttributes {
    showPeakData: boolean
    maxPeakDataLimit: number
    minPeakDataLimit: number
  }
}
