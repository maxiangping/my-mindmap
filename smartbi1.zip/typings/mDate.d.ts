/** @format */
export class IMdate {
  constructor(el: HTMLElement, config: IMdateConfig)
}

export interface IMdateConfig {
  acceptId: string
  beginYear: string
  beginMonth: string
  beginDay: string
  endYear: string
  endMonth: string
  endDay: string
  format: string
  onClick?: (_event: Event, node: unknown) => void
}
