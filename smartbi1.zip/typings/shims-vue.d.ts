/** @format */

declare module '*.vue' {
  import Vue from 'vue'
  declare module 'vue/types/vue' {
    interface Vue {
      $closeMessage: ElMessage
    }
  }

  export default Vue
}
