/** @format */

export declare global {
  declare interface DialogState {
    title: string
    msg: string
    cancel?: string
    confirm?: string
    onCancel?: VoidFunction | null
    onConfirm?: VoidFunction | null
  }

  declare interface RootState {
    version: string
  }
}
