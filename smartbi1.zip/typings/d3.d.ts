/** @format */

export type BaseType = Element | EnterElement | Document | Window | null
export type KeyType = string | number
export interface ArrayLike<T> {
  length: number
  item(index: number): T | null
  [index: number]: T
}
export type ValueFn<T extends BaseType, Datum, Result> = (
  this: T,
  datum: Datum,
  index: number,
  groups: T[] | ArrayLike<T>,
) => Result

export interface TransitionLike<GElement extends BaseType, Datum> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  selection(): Selection<GElement, Datum, any, any>
  on(type: string, listener: null): TransitionLike<GElement, Datum>
  on(
    type: string,
    listener: ValueFn<GElement, Datum, void>,
  ): TransitionLike<GElement, Datum>
  tween(name: string, tweenFn: null): TransitionLike<GElement, Datum>
  tween(
    name: string,
    tweenFn: ValueFn<GElement, Datum, (t: number) => void>,
  ): TransitionLike<GElement, Datum>
}
export type ZoomedElementBaseType = Element
export type DragContainerElement = HTMLElement | SVGSVGElement | SVGGElement
export type DraggedElementBaseType = Element
export interface ZoomScale {
  domain(): number[] | Date[]
  domain(domain: (Date | number)[]): this
  range(): number[]
  range(range: number[]): this
  copy(): ZoomScale
  invert(value: number): number | Date
}
export interface EnterElement {
  ownerDocument: Document
  namespaceURI: string
  appendChild(newChild: Node): Node
  insertBefore(newChild: Node, refChild: Node): Node
  querySelector(selectors: string): Element
  querySelectorAll(selectors: string): NodeListOf<Element>
}

export interface SubjectPosition {
  x: number
  y: number
}

interface D3EventTransform {
  k: number
  x: number
  y: number
}
export interface D3Event extends MouseEvent {
  transform: D3EventTransform
  key: string
  type: string
  sourceEvent: MouseEvent | TouchEvent | DragEvent
  ctrlKey?: boolean
  metaKey?: boolean
  button?: number
  subject: Subject
  x: number
  y: number
  dx: number
  dy: number
  deltaY: number
  deltaX: number
  identifier: 'mouse' | number
  active: number
  target: HTMLElement
  on(
    typenames: string,
  ): ((this: GElement, event: D3Event, d: Datum) => void) | undefined
  on(typenames: string, listener: null): this
  on(
    typenames: string,
    listener: (this: GElement, event: D3Event, d: Datum) => void,
  ): this
}

export interface Selection<
  GElement extends BaseType,
  Datum,
  PElement extends BaseType,
  PDatum,
> {
  select<DescElement extends BaseType>(
    selector: string,
  ): Selection<DescElement, Datum, PElement, PDatum>

  select(selector: null): Selection<null, undefined, PElement, PDatum>

  select<DescElement extends BaseType>(
    selector: ValueFn<GElement, Datum, DescElement>,
  ): Selection<DescElement, Datum, PElement, PDatum>

  selectAll(): Selection<null, undefined, GElement, Datum>

  selectAll(selector: null): Selection<null, undefined, GElement, Datum>

  selectAll(selector: undefined): Selection<null, undefined, GElement, Datum>

  selectAll<DescElement extends BaseType, OldDatum>(
    selector: string,
  ): Selection<DescElement, OldDatum, GElement, Datum>

  selectAll<DescElement extends BaseType, OldDatum>(
    selector: ValueFn<
      GElement,
      Datum,
      DescElement[] | ArrayLike<DescElement> | Iterable<DescElement>
    >,
  ): Selection<DescElement, OldDatum, GElement, Datum>

  filter(selector: string): Selection<GElement, Datum, PElement, PDatum>

  filter<FilteredElement extends BaseType>(
    selector: string,
  ): Selection<FilteredElement, Datum, PElement, PDatum>

  filter(
    selector: ValueFn<GElement, Datum, boolean>,
  ): Selection<GElement, Datum, PElement, PDatum>

  filter<FilteredElement extends BaseType>(
    selector: ValueFn<GElement, Datum, boolean>,
  ): Selection<FilteredElement, Datum, PElement, PDatum>

  merge(
    other:
      | Selection<GElement, Datum, PElement, PDatum>
      | TransitionLike<GElement, Datum>,
  ): Selection<GElement, Datum, PElement, PDatum>

  selectChild<DescElement extends BaseType>(): Selection<
    DescElement,
    Datum,
    PElement,
    PDatum
  >

  selectChild<DescElement extends BaseType>(
    selector: string,
  ): Selection<DescElement, Datum, PElement, PDatum>

  selectChild<ResultElement extends BaseType, ChildElement extends BaseType>(
    selector: (
      child: ChildElement,
      i: number,
      children: ChildElement[],
    ) => boolean,
  ): Selection<ResultElement, Datum, PElement, PDatum>

  selectChildren<DescElement extends BaseType, OldDatum>(): Selection<
    DescElement,
    OldDatum,
    GElement,
    Datum
  >

  selectChildren<DescElement extends BaseType, OldDatum>(
    selector: string,
  ): Selection<DescElement, OldDatum, GElement, Datum>

  selectChildren<
    ResultElement extends BaseType,
    ResultDatum,
    ChildElement extends BaseType,
  >(
    selector: (
      child: ChildElement,
      i: number,
      children: ChildElement[],
    ) => boolean,
  ): Selection<ResultElement, ResultDatum, GElement, Datum>

  selection(): this

  attr(name: string): string

  attr(name: string, value: null): this

  attr(name: string, value: string | number | boolean): this
  attr(name: string, value: D3EventTransform): this

  attr(
    name: string,
    value: ValueFn<GElement, Datum, string | number | boolean | null>,
  ): this

  classed(names: string): boolean

  classed(names: string, value: boolean): this

  classed(names: string, value: ValueFn<GElement, Datum, boolean>): this

  style(name: string): string

  style(name: string, value: null): this

  style(
    name: string,
    value: string | number | boolean,
    priority?: null | 'important',
  ): this

  style(
    name: string,
    value: ValueFn<GElement, Datum, string | number | boolean | null>,
    priority?: null | 'important',
  ): this

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  property(name: string): any

  property<T>(name: Local<T>): T | undefined

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  property(name: string, value: ValueFn<GElement, Datum, any>): this

  property(name: string, value: null): this

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  property(name: string, value: any): this

  property<T>(name: Local<T>, value: ValueFn<GElement, Datum, T>): this

  property<T>(name: Local<T>, value: T): this

  text(): string

  text(value: null): this

  text(value: string | number | boolean): this

  text(value: ValueFn<GElement, Datum, string | number | boolean | null>): this

  html(): string

  html(value: null): this

  html(value: string): this

  html(value: ValueFn<GElement, Datum, string | null>): this

  append<K extends keyof ElementTagNameMap>(
    type: K,
  ): Selection<ElementTagNameMap[K], Datum, PElement, PDatum>

  append<ChildElement extends BaseType>(
    type: string,
  ): Selection<ChildElement, Datum, PElement, PDatum>

  append<ChildElement extends BaseType>(
    type: ValueFn<GElement, Datum, ChildElement>,
  ): Selection<ChildElement, Datum, PElement, PDatum>

  insert<K extends keyof ElementTagNameMap>(
    type: K,
    before?: string | ValueFn<GElement, Datum, BaseType>,
  ): Selection<ElementTagNameMap[K], Datum, PElement, PDatum>

  insert<ChildElement extends BaseType>(
    type: string | ValueFn<GElement, Datum, ChildElement>,
    before?: string | ValueFn<GElement, Datum, BaseType>,
  ): Selection<ChildElement, Datum, PElement, PDatum>

  remove(): this
  interrupt(name?: string): this

  clone(deep?: boolean): Selection<GElement, Datum, PElement, PDatum>

  sort(comparator?: (a: Datum, b: Datum) => number): this

  order(): this

  raise(): this

  lower(): this

  data(): Datum[]

  data<NewDatum>(
    data: NewDatum[] | Iterable<NewDatum>,
    key?: ValueFn<GElement | PElement, Datum | NewDatum, KeyType>,
  ): Selection<GElement, NewDatum, PElement, PDatum>

  data<NewDatum>(
    data: ValueFn<PElement, PDatum, NewDatum[] | Iterable<NewDatum>>,
    key?: ValueFn<GElement | PElement, Datum | NewDatum, KeyType>,
  ): Selection<GElement, NewDatum, PElement, PDatum>

  join<K extends keyof ElementTagNameMap, OldDatum = Datum>(
    enter: K,
    update?: (
      elem: Selection<GElement, Datum, PElement, PDatum>,
    ) =>
      | Selection<GElement, Datum, PElement, PDatum>
      | TransitionLike<GElement, Datum>
      | undefined,
    exit?: (elem: Selection<GElement, OldDatum, PElement, PDatum>) => void,
  ): Selection<GElement | ElementTagNameMap[K], Datum, PElement, PDatum>

  join<ChildElement extends BaseType, OldDatum = Datum>(
    enter: string,
    update?: (
      elem: Selection<GElement, Datum, PElement, PDatum>,
    ) =>
      | Selection<GElement, Datum, PElement, PDatum>
      | TransitionLike<GElement, Datum>
      | undefined,
    exit?: (elem: Selection<GElement, OldDatum, PElement, PDatum>) => void,
  ): Selection<ChildElement | GElement, Datum, PElement, PDatum>

  join<ChildElement extends BaseType, OldDatum = Datum>(
    enter: (
      elem: Selection<EnterElement, Datum, PElement, PDatum>,
    ) =>
      | Selection<ChildElement, Datum, PElement, PDatum>
      | TransitionLike<GElement, Datum>,
    update?: (
      elem: Selection<GElement, Datum, PElement, PDatum>,
    ) =>
      | Selection<GElement, Datum, PElement, PDatum>
      | TransitionLike<GElement, Datum>
      | undefined,
    exit?: (elem: Selection<GElement, OldDatum, PElement, PDatum>) => void,
  ): Selection<ChildElement | GElement, Datum, PElement, PDatum>

  enter(): Selection<EnterElement, Datum, PElement, PDatum>

  exit<OldDatum>(): Selection<GElement, OldDatum, PElement, PDatum>

  datum(): Datum

  datum(value: null): Selection<GElement, undefined, PElement, PDatum>

  datum<NewDatum>(
    value: ValueFn<GElement, Datum, NewDatum>,
  ): Selection<GElement, NewDatum, PElement, PDatum>

  datum<NewDatum>(
    value: NewDatum,
  ): Selection<GElement, NewDatum, PElement, PDatum>

  on(
    typenames: string,
  ): ((this: GElement, event: D3Event, d: Datum) => void) | undefined

  on(typenames: string, listener: null): this
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  on(
    typenames: string,
    listener: (this: GElement, event: D3Event, d: Datum) => void,
    options?: any,
  ): this

  dispatch(type: string, parameters?: CustomEventParameters): this

  dispatch(
    type: string,
    parameters?: ValueFn<GElement, Datum, CustomEventParameters>,
  ): this

  each(func: ValueFn<GElement, Datum, void>): this
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  call(
    func: (
      selection: Selection<GElement, Datum, PElement, PDatum>,
      ...args: any[]
    ) => void,
    ...args: any[]
  ): this

  empty(): boolean

  nodes(): GElement[]

  node(): GElement | null

  size(): number

  transition(
    trans: Transition<GElement, Datum, null, undefined>,
  ): Transition<GElement, Datum, null, undefined>

  [Symbol.iterator](): Iterator<GElement>
}

export class ZoomTransform {
  constructor(k: number, x: number, y: number)

  readonly x: number

  readonly y: number

  readonly k: number

  apply(point: [number, number]): [number, number]

  applyX(x: number): number

  applyY(y: number): number

  invert(point: [number, number]): [number, number]

  invertX(x: number): number

  invertY(y: number): number

  rescaleX<S extends ZoomScale>(xScale: S): S

  rescaleY<S extends ZoomScale>(yScale: S): S

  scale(k: number): ZoomTransform

  toString(): string

  translate(x: number, y: number): ZoomTransform
}

export interface ZoomBehavior<
  ZoomRefElement extends ZoomedElementBaseType,
  Datum,
> extends Function {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (selection: Selection<ZoomRefElement, Datum, any, any>, ...args: any[]): void
  transform(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    selection:
      | Selection<ZoomRefElement, Datum, any, any>
      | TransitionLike<ZoomRefElement, Datum>,
    transform:
      | ZoomTransform
      | ((this: ZoomRefElement, event: D3Event, d: Datum) => ZoomTransform),
    point?:
      | [number, number]
      | ((this: ZoomRefElement, event: D3Event, d: Datum) => [number, number]),
  ): void

  translateBy(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    selection:
      | Selection<ZoomRefElement, Datum, any, any>
      | TransitionLike<ZoomRefElement, Datum>,
    x: number | ValueFn<ZoomRefElement, Datum, number>,
    y: number | ValueFn<ZoomRefElement, Datum, number>,
  ): void

  translateTo(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    selection:
      | Selection<ZoomRefElement, Datum, any, any>
      | TransitionLike<ZoomRefElement, Datum>,
    x: number | ValueFn<ZoomRefElement, Datum, number>,
    y: number | ValueFn<ZoomRefElement, Datum, number>,
    p?: [number, number] | ValueFn<ZoomRefElement, Datum, [number, number]>,
  ): void

  scaleBy(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    selection:
      | Selection<ZoomRefElement, Datum, any, any>
      | TransitionLike<ZoomRefElement, Datum>,
    k: number | ValueFn<ZoomRefElement, Datum, number>,
    p?: [number, number] | ValueFn<ZoomRefElement, Datum, [number, number]>,
  ): void

  scaleTo(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    selection:
      | Selection<ZoomRefElement, Datum, any, any>
      | TransitionLike<ZoomRefElement, Datum>,
    k: number | ValueFn<ZoomRefElement, Datum, number>,
    p?: [number, number],
  ): void

  constrain(): (
    transform: ZoomTransform,
    extent: [[number, number], [number, number]],
    translateExtent: [[number, number], [number, number]],
  ) => ZoomTransform

  constrain(
    constraint: (
      transform: ZoomTransform,
      extent: [[number, number], [number, number]],
      translateExtent: [[number, number], [number, number]],
    ) => ZoomTransform,
  ): this

  filter(): (this: ZoomRefElement, event: D3Event, datum: Datum) => boolean

  filter(
    filter: (this: ZoomRefElement, event: D3Event, datum: Datum) => boolean,
  ): this

  touchable(): ValueFn<ZoomRefElement, Datum, boolean>

  touchable(touchable: boolean): this

  touchable(touchable: ValueFn<ZoomRefElement, Datum, boolean>): this

  wheelDelta(): ValueFn<ZoomRefElement, Datum, number>

  wheelDelta(delta: ((event: WheelEvent) => number) | number): this

  extent(): (
    this: ZoomRefElement,
    datum: Datum,
  ) => [[number, number], [number, number]]

  extent(extent: [[number, number], [number, number]]): this

  extent(
    extent: (
      this: ZoomRefElement,
      datum: Datum,
    ) => [[number, number], [number, number]],
  ): this

  scaleExtent(): [number, number]

  scaleExtent(extent: [number, number]): this

  translateExtent(): [[number, number], [number, number]]

  translateExtent(extent: [[number, number], [number, number]]): this

  clickDistance(): number

  clickDistance(distance: number): this

  tapDistance(): number

  tapDistance(distance: number): this

  duration(): number

  duration(duration: number): this

  interpolate<
    InterpolationFactory extends (
      a: ZoomView,
      b: ZoomView,
    ) => (t: number) => ZoomView,
  >(): InterpolationFactory

  interpolate(
    interpolatorFactory: (a: ZoomView, b: ZoomView) => (t: number) => ZoomView,
  ): this

  on(
    typenames: string,
  ): ((this: ZoomRefElement, event: D3Event, d: Datum) => void) | undefined

  on(typenames: string, listener: null): this

  on(
    typenames: string,
    listener: (this: ZoomRefElement, event: D3Event, d: Datum) => void,
  ): this
}

export interface Transition<
  GElement extends BaseType,
  Datum,
  PElement extends BaseType,
  PDatum,
> {
  // Sub-selection -------------------------

  select<DescElement extends BaseType>(
    selector: string,
  ): Transition<DescElement, Datum, PElement, PDatum>
  select<DescElement extends BaseType>(
    selector: ValueFn<GElement, Datum, DescElement>,
  ): Transition<DescElement, Datum, PElement, PDatum>

  selectAll<DescElement extends BaseType, OldDatum>(
    selector: string,
  ): Transition<DescElement, OldDatum, GElement, Datum>
  selectAll<DescElement extends BaseType, OldDatum>(
    selector: ValueFn<GElement, Datum, DescElement[] | ArrayLike<DescElement>>,
  ): Transition<DescElement, OldDatum, GElement, Datum>

  selectChild<DescElement extends BaseType, OldDatum>(
    selector?: string | ValueFn<GElement, Datum, DescElement>,
  ): Transition<DescElement, OldDatum, GElement, Datum>

  selectChildren<DescElement extends BaseType, OldDatum>(
    selector?: string | ValueFn<GElement, Datum, DescElement>,
  ): Transition<DescElement, OldDatum, GElement, Datum>

  selection(): Selection<GElement, Datum, PElement, PDatum>

  transition(): Transition<GElement, Datum, PElement, PDatum>

  // Modifying -------------------------------

  attr(name: string, value: null | string | number | boolean): this
  attr(
    name: string,
    value: ValueFn<GElement, Datum, string | number | boolean | null>,
  ): this

  attrTween(
    name: string,
  ): ValueFn<GElement, Datum, (this: GElement, t: number) => string> | undefined
  attrTween(name: string, factory: null): this
  attrTween(
    name: string,
    factory: ValueFn<GElement, Datum, (this: GElement, t: number) => string>,
  ): this

  style(name: string, value: null): this
  style(
    name: string,
    value: string | number | boolean,
    priority?: null | 'important',
  ): this
  style(
    name: string,
    value: ValueFn<GElement, Datum, string | number | boolean | null>,
    priority?: null | 'important',
  ): this

  styleTween(
    name: string,
  ): ValueFn<GElement, Datum, (this: GElement, t: number) => string> | undefined
  styleTween(name: string, factory: null): this
  styleTween(
    name: string,
    factory: ValueFn<GElement, Datum, (this: GElement, t: number) => string>,
    priority?: null | 'important',
  ): this

  text(value: null | string | number | boolean): this
  text(value: ValueFn<GElement, Datum, string | number | boolean>): this

  textTween():
    | ValueFn<GElement, Datum, (this: GElement, t: number) => string>
    | undefined
  textTween(factory: null): this
  textTween(
    factory: ValueFn<GElement, Datum, (this: GElement, t: number) => string>,
  ): this

  remove(): this

  tween(
    name: string,
  ): ValueFn<GElement, Datum, (this: GElement, t: number) => void> | undefined
  tween(name: string, tweenFn: null): this
  tween(
    name: string,
    tweenFn: ValueFn<GElement, Datum, (this: GElement, t: number) => void>,
  ): this

  merge(
    other: Transition<GElement, Datum, PElement, PDatum>,
  ): Transition<GElement, Datum, PElement, PDatum>

  filter(filter: string): Transition<GElement, Datum, PElement, PDatum>
  filter<FilteredElement extends BaseType>(
    filter: string,
  ): Transition<FilteredElement, Datum, PElement, PDatum>
  filter(
    filter: ValueFn<GElement, Datum, boolean>,
  ): Transition<GElement, Datum, PElement, PDatum>
  filter<FilteredElement extends BaseType>(
    filter: ValueFn<GElement, Datum, boolean>,
  ): Transition<FilteredElement, Datum, PElement, PDatum>

  // Event Handling -------------------

  on(typenames: string): ValueFn<GElement, Datum, void> | undefined
  on(typenames: string, listener: null): this
  on(typenames: string, listener: ValueFn<GElement, Datum, void>): this

  end(): Promise<void>

  // Control Flow ----------------------

  each(func: ValueFn<GElement, Datum, void>): this
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  call(
    func: (
      transition: Transition<GElement, Datum, PElement, PDatum>,
      ...args: any[]
    ) => any,
    ...args: any[]
  ): this

  empty(): boolean

  node(): GElement | null

  nodes(): GElement[]

  size(): number

  // Transition Configuration ----------------------

  delay(): number
  delay(milliseconds: number): this
  delay(milliseconds: ValueFn<GElement, Datum, number>): this

  duration(): number

  duration(milliseconds: number): this

  duration(milliseconds: ValueFn<GElement, Datum, number>): this

  ease(): (normalizedTime: number) => number

  ease(easingFn: (normalizedTime: number) => number): this

  easeVarying(
    factory: ValueFn<GElement, Datum, (normalizedTime: number) => number>,
  ): this
}

export interface D3Link extends Function {
  (params?: { source: number[]; target: number[] }): this
  x(d: nmber): this
  y(d: nmber): this
}

export interface DragBehavior<
  GElement extends DraggedElementBaseType,
  Datum,
  Subject,
> extends Function {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (selection: Selection<GElement, Datum, any, any>, ...args: any[]): void

  container(e: MouseEvent): ValueFn<GElement, Datum, DragContainerElement>
  container(accessor: ValueFn<GElement, Datum, DragContainerElement>): this
  container(container: DragContainerElement): this

  filter(): (this: GElement, event: D3Event, d: Datum) => boolean
  filter(filterFn: (this: GElement, event: D3Event, d: Datum) => boolean): this

  touchable(): ValueFn<GElement, Datum, boolean>
  touchable(touchable: boolean): this
  touchable(touchable: ValueFn<GElement, Datum, boolean>): this

  subject(): (this: GElement, event: D3Event, d: Datum) => Subject
  subject(accessor: (this: GElement, event: D3Event, d: Datum) => Subject): this

  clickDistance(): number
  clickDistance(distance: number): this

  on(
    typenames: string,
  ): ((this: GElement, event: D3Event, d: Datum) => void) | undefined
  on(typenames: string, listener: null): this
  on(
    typenames: string,
    listener: (this: GElement, event: D3Event, d: Datum) => void,
  ): this
}

export interface ScaleOrdinal<
  Domain extends { toString(): string },
  Range,
  Unknown = never,
> {
  (x: Domain): Range | Unknown

  domain(): Domain[]

  domain(domain: Iterable<Domain>): this

  range(): Range[]

  range(range: Iterable<Range>): this

  unknown(): UnknownReturnType<Unknown, { name: 'implicit' }>

  unknown<NewUnknown>(
    value: NewUnknown,
  ): NewUnknown extends { name: 'implicit' }
    ? ScaleOrdinal<Domain, Range>
    : ScaleOrdinal<Domain, Range, NewUnknown>

  copy(): this
}

declare interface D3 extends HTMLElement {
  min(iterable: Iterable<string>): string | undefined
  min<T extends Numeric>(iterable: Iterable<T>): T | undefined
  min<T>(
    iterable: Iterable<T>,
    accessor: (
      datum: T,
      index: number,
      array: Iterable<T>,
    ) => string | undefined | null,
  ): string | undefined
  min<T, U extends Numeric>(
    iterable: Iterable<T>,
    accessor: (
      datum: T,
      index: number,
      array: Iterable<T>,
    ) => U | undefined | null,
  ): U | undefined
  minIndex(iterable: Iterable<unknown>): number
  minIndex<TDatum>(
    iterable: Iterable<TDatum>,
    accessor: (
      datum: TDatum,
      index: number,
      array: Iterable<TDatum>,
    ) => unknown,
  ): number
  minIndex(iterable: Iterable<unknown>): number
  max(iterable: Iterable<string>): string | undefined
  max<T extends Numeric>(iterable: Iterable<T>): T | undefined
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  select<GElement extends BaseType, OldDatum>(
    selector: string,
  ): Selection<GElement, OldDatum, HTMLElement, any>
  select<GElement extends BaseType, OldDatum>(
    node: GElement,
  ): Selection<GElement, OldDatum, null, undefined>
  selectAll(): Selection<null, undefined, null, undefined>
  selectAll(selector: null): Selection<null, undefined, null, undefined>
  selectAll(selector: undefined): Selection<null, undefined, null, undefined>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  selectAll<GElement extends BaseType, OldDatum>(
    selector: string,
  ): Selection<GElement, OldDatum, HTMLElement, any>

  style(node: Element, name: string): string

  drag<GElement extends DraggedElementBaseType, Datum>(): DragBehavior<
    GElement,
    Datum,
    Datum | SubjectPosition
  >
  drag<GElement extends DraggedElementBaseType, Datum, Subject>(): DragBehavior<
    GElement,
    Datum,
    Subject
  >
  dragDisable(window: Window): void
  dragEnable(window: Window, noClick?: boolean): void

  zoomTransform(node: ZoomedElementBaseType): ZoomTransform
  zoom<ZoomRefElement extends ZoomedElementBaseType, Datum>(): ZoomBehavior<
    ZoomRefElement,
    Datum
  >

  transition<OldDatum>(
    name?: string,
  ): Transition<GElement, OldDatum, null, undefined>
  transition<OldDatum>(
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    transition: Transition<BaseType, any, BaseType, any>,
  ): Transition<GElement, OldDatum, null, undefined>
  active<GElement extends BaseType, Datum, PElement extends BaseType, PDatum>(
    node: GElement,
    name?: string,
  ): Transition<GElement, Datum, PElement, PDatum> | null
  interrupt(node: BaseType, name?: string): void
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  pointer(event: D3Event, target?: any): [number, number]
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  pointers(event: D3Event, target?: any): [number, number][]

  easePolyInOut: (normalizedTime: number) => number
  easePolyIn: (normalizedTime: number) => number
  easePolyOut: (normalizedTime: number) => number
  easeLinear: (normalizedTime: number) => number
  easePoly: (normalizedTime: number) => number

  linkHorizontal(): D3Link
  linkVertical(): D3Link

  scaleOrdinal<Range>(range?: Iterable<Range>): ScaleOrdinal<string, Range>
  schemePaired: string[]
}

export interface D3FlexTree<T> extends Function {
  (options?: {
    children?: (data) => T
    nodeSize?: (node) => number[]
    spacing: number
  })
}
