/** @format */

declare type NonType = null | undefined
declare type PrimitiveType = NonType | boolean | string | number
declare type ReferenceType<T> = T extends ArrayConstructor
  ? T[]
  : { [K in keyof T]: T[K] }

declare type NativeJSType = Date | RegExp | File

declare type BasicClassType =
  | FunctionConstructor
  | ArrayConstructor
  | ObjectConstructor
  | DateConstructor
  | RegExpConstructor
  | StringConstructor
  | NumberConstructor
  | BooleanConstructor

declare type StructJSONType =
  | PrimitiveType
  | { [property: string]: StructJSONType }
  | StructJSONType[]
type JSONType = Record<string, StructJSONType>

declare interface IResponse<T> {
  code: number
  data?: T
  msg: string
  url?: string
  fileName?: string
  total: number
}

declare interface IPage<T> {
  code: number
  pages: number
  rows?: T[]
  total: number
}

declare interface SearchType {
  explorer?: string
  [key: string]: PrimitiveType
}

type KV = Record<string, string>

declare interface IProcess {
  name: string
  publicPath: string
  isProduction: boolean
}

declare interface HTMLElementEvent<T extends HTMLElement>
  extends MouseEvent,
    DragEvent,
    TouchEvent,
    WheelEvent {
  target: T
  wheelDelta?: number
}
