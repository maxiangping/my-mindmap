/** @format */

import type { SpecialValueMap } from '@/store/model/common'

/** *********************** 基础类 ************************* */
// 纬度坐标实例对象
declare class ITMapLatLng {
  lat: string

  lng: string

  constructor(lat: string, lng: string)

  getLat(): number

  getLng(): number
}

// 描述一个矩形的地理坐标范围
declare class ITMapLatLngBounds {
  sw: ITMapLatLng // 西南角位置经纬度。

  ne: ITMapLatLng // 东北角位置经纬度。

  constructor(sw: ITMapLatLng, ne: ITMapLatLng)

  getCenter(): ITMapLatLng //	获取该范围的中心点坐标。

  getNorthEast(): ITMapLatLng //	获取该范围的东北角坐标。

  getSouthWest(): ITMapLatLng //	获取该范围的西南角坐标。

  extend(latlng: ITMapLatLng): ITMapLatLngBounds // 扩展该范围边界，以包含指定的坐标点。

  union(other: ITMapLatLngBounds): ITMapLatLngBounds //	扩展该范围边界，以包含指定的一个矩形范围。

  equals(other: ITMapLatLngBounds): boolean //	比较两个矩形范围是否完全相等。

  intersects(other: ITMapLatLngBounds): boolean //	判断该范围是否与另一矩形范围相交。

  isEmpty(): boolean //	判断该范围是否为空。

  contains(latlng: ITMapLatLng): boolean //	判断指定的坐标是否在这个范围内。

  toString(): string //	转换为字符串表示。
}

declare interface ITMapLatLngPoint {
  lat: string
  lng: string
}

declare class ITMapPoint {
  x: number

  y: number
}

// 用于创建二维坐标点
declare class ITMapPointXY {
  x: number

  y: number

  constructor(x: number, y: number)

  getX(): number //	获取x坐标值

  getY(): number //	获取y坐标值

  equals(other: ITMapPointXY): boolean //	判断两个点是否相等

  clone(): ITMapPointXY // 创建一个坐标值相同的点

  toString(): string //	转换为字符串表示
}

//  用于创建渐变色实例。
declare class ITMapGradientColor {
  constructor(options: ITMapGradientColorOptions)

  addColorStop(offset: number, color: string): ITMapGradientColor //	添加一个由偏移(offset)和颜色(color)定义的断点，offset取值范围为0～1，颜色支持rgb(), rgba(),#RRGGBB格式。

  setAngle(angle: number): ITMapGradientColor //	设置水平线和渐变线之间的角度，逆时针方向旋转，0度从左到右，90度从下到上。

  getAngle(): number //	获取水平线和渐变线之间的角度。

  static createDoubleColorGradient(
    color1: string,
    color2: string,
    angle: number,
  ): ITMapGradientColor //	创建双色渐变色。

  static convert(colors: SpecialValueMap<string>): ITMapGradientColor //	将字面量对象和双色值数组，
}

// GradientColor 配置参数。
declare interface ITMapGradientColorOptions {
  stops: SpecialValueMap<string> // 渐变色中的断点集合，key-value形式。key为偏移(offset)，value为颜色(color)，比如{0:’#FFFFFF’, 1:’#000000’}。
  angle: number // 水平线和渐变线之间的角度，逆时针方向旋转，0度从左到右，90度从下到上，默认值0度。
}

/** *********************** 控件的基类 ************************* */
// 控件的基类，控件的方法及常量说明。
declare class ITMapControl {
  setPosition(position: CONTROL_POSITION): ITMapControl //	设置控件的位置。

  setClassName(className: string): ITMapControl //	设置控件的css样式名。
}

interface CONTROL_POSITION {
  TOP_LEFT: 'TOP_LEFT' //	左上
  TOP_CENTER: 'TOP_CENTER' //	顶部中间
  TOP_RIGHT: 'TOP_RIGHT' //	右上
  CENTER_LEFT: 'CENTER_LEFT' //	左侧中间
  CENTER: 'CENTER' //	图区中间
  CENTER_RIGHT: 'CENTER_RIGHT' //	右侧中间
  BOTTOM_LEFT: 'BOTTOM_LEFT' //	左下
  BOTTOM_CENTER: 'BOTTOM_CENTER' //	底部中间
  BOTTOM_RIGHT: 'BOTTOM_RIGHT' //	右下
}

interface DEFAULT_CONTROL_ID {
  SCALE: 'SCALE' //	比例尺控件
  ZOOM: 'ZOOM' //	缩放控件
  ROTATION: 'ROTATION' //	旋转控件
}

/** *********************** 标注类 ************************* */
// marker geo配置
declare interface ITMapGeometries {
  id: string // 点标记唯一标识，后续如果有删除、修改位置等操作，都需要此id
  styleId: string // 指定样式id
  position: ITMapLatLngPoint // 点标记坐标位置
  properties?: {
    title: string // 自定义属性
  }
  content?: string
}

// marker 样式配置项
declare interface ITMapMarkerStyleOption {
  width: number // 点标记样式宽度（像素）
  height: number // 点标记样式高度（像素）
  src: string // 图片路径
  anchor: ITMapPoint // 焦点在图片中的像素位置，一般大头针类似形式的图片以针尖位置做为焦点，圆形点以圆心位置为焦点
}

// marker 样式对象
declare class ITMapMarkerStyle {
  constructor(option: ITMapMarkerStyleOption)
}

// 多个Marker配置项
declare interface ITMapMultiMarkerOption {
  map: ITMapCore
  styles: Record<string, ITMapMarkerStyle>
  geometries: ITMapGeometries[] // 点标记数据数组
}

// 多个Marker对象
declare class ITMapMultiMarker {
  constructor(option: ITMapMultiMarkerOption)

  add(geometries: ITMapGeometries[]) // 添加标记

  updateGeometries(geometries: ITMapGeometries[]) // 修改标记

  setGeometries(geometries: PointGeometry[]) // 设置标记

  remove(geometriesIds: string[]) // 删除指定标记

  on(eventName: string, eventFn: (e: GeometryOverlayEvent) => void) // 添加事件

  off(eventName: string, eventFn: (e: GeometryOverlayEvent) => void) // 删除事件
}

declare interface ITMapLabelStyleOption {
  color: string // 颜色属性
  size: number // 文字大小属性
  offset: ITMapPointXY // 文字偏移属性单位为像素
  angle: number // 文字旋转属性
  alignment: 'center' | 'left' | 'right' // 文字水平对齐属性
  verticalAlignment: 'middle' | 'top' | 'bottom' // 文字垂直对齐属性
}

declare class ITMapLabelStyle {
  constructor(option: ITMapLabelStyleOption)
}

declare interface ITMapMultiLabelOption {
  id: string
  map: ITMapCore
  styles: Record<string, ITMapLabelStyle>
  geometries: ITMapGeometries[] // 点标记数据数组
}

declare class ITMapMultiLabel {
  constructor(option: ITMapMultiLabelOption)
}

// 经纬度
declare interface ITMapLatLngPoint {
  lat: number
  lng: number
}

/** **************************地图核心类******************************* */
// Map 配置项
declare interface ITMapOptions {
  center?: ITMapLatLng // 地图中心点经纬度。
  zoom?: number // 设置地图缩放级别，支持3～20。
  pitch?: number // 设置俯仰角 取值范围为0~80，默认为0。
  rotation?: number //	地图在水平面上的旋转角度，顺时针方向为正，默认为0。
  centerPoint?: ITMapLatLngPoint
  viewMode?: '2D' | '3D' // 2D 3D
  minZoom?: number //	地图最小缩放级别，默认为3。
  maxZoom?: number //	地图最大缩放级别，默认为20。
  scale?: number //	地图显示比例，默认为1。
  offset?: ITMapPointXY // 地图中心与容器的偏移量，Object的格式为 {x:Number, y:Number}（右方下方为正，单位为像素）。
  draggable?: boolean // 是否支持拖拽移动地图，默认为true。
  scrollable?: boolean //	是否支持鼠标滚轮缩放地图，默认为true。
  pitchable?: boolean // 是否允许设置俯仰角度；默认为true。在2D视图下，此属性无效。
  rotatable?: boolean // 是否允许设置旋转角度；默认为true。在2D视图下，此属性无效。
  doubleClickZoom?: boolean //	是否支持双击缩放地图，默认为true。
  mapZoomType?: string // MAP_ZOOM_TYPE 地图缩放焦点控制。
  boundary?: ITMapLatLngBounds // 地图边界，设置后拖拽、缩放等操作无法将地图移动至边界外，默认为null。
  mapStyleId?: string // 地图样式ID，有效值为”style[编号]”，与key绑定，详见 个性化地图配置页面。
  baseMap?: ITMapBaseMap | ITMapBaseMap[] // 地图底图，BaseMap目前只支持矢量底图 （VectorBaseMap） 、卫星底图 （SatelliteBaseMap） 、路况底图 （TrafficBaseMap） ，可以使用数组形式实现多种底图叠加。默认为 VectorBaseMap ，如果传入null地图不显示任何地物。
  viewMode?: string // 地图视图模式，支持2D和3D，默认为3D。2D模式下不可对地图进行拖拽旋转，pitch和rotation始终保持为0。
  showControl?: boolean // 是否显示地图上的控件，默认true。
}

// 地图事件返回参数中的poi信息
declare interface ITMapPOIInfo {
  latLng: ITMapLatLng
  name: string
}

// 地图事件返回参数
declare interface MapEvent {
  latLng: ITMapLatLng // 事件发生时的经纬度坐标
  point: ITMapPointXY // 事件发生时的屏幕位置，返回{x:Number, y:Number}格式。
  type: string // 事件类型。
  target: HTMLElement //	事件的目标对象。
  poi: ITMapPOIInfo // 事件触发位置的poi信息，当触发位置没有poi点时值为null（仅支持click事件）
  originalEvent: MouseEvent | TouchEvent //	浏览器原生的事件对象。
}

//  几何覆盖物事件返回参数规范。

declare interface GeometryOverlayEvent {
  geometry: ITMapGeometries // 事件发生时的图形数据信息，不同图层中该值所属对象规范不同，比如 MultiMarker（点标记图层）触发的事件中该值为PointGeometry对象。
  latLng: ITMapLatLng // 事件发生时的经纬度坐标。
  point: ITMapPointXY //	事件发生时的屏幕位置，返回{x:Number, y:Number}格式。
  type: string // 事件类型。
  target: HTMLElement //	事件的目标对象。
  originalEvent: MouseEvent | TouchEvent //	浏览器原生的事件对象。
}

declare interface ITMapBaseMap {
  type: 'vector' | 'satellite' | 'traffic'
  features?: string[] // 矢量底图要素类型
}

declare interface ITMapOffset {
  top: number
  bottom: number
  left: number
  right: number
}
declare interface ITMapFitBoundsOptions {
  padding: number | ITMapOffset // 	设定的地理范围与可视窗口之间的距离，可以通过{top:Number, bottom:Number, left:Number, right:Number}的格式明确各方向的边距，或仅传入一个数字统一各方向的边距，不可为负数。
  minZoom: number //	调整视野时的最小缩放等级，默认值且最小值为地图的最小缩放等级。
  maxZoom: number //	调整视野时的最大缩放等级，默认值且最大值为地图的最大缩放等级。
  ease: ITMapEaseOptions //	缓动配置，可设置地图视野变化过程的动画效果。
}

declare interface ITMapEaseOptions {
  duration: number // 缓动动画时长，单位为ms，默认为500。
}

// Map 对象
declare class ITMapCore extends HTMLElement {
  container: HTMLElement

  constructor(container: HTMLElement, options: ITMapOptions)

  setCenter(center: ITMapLatLng): ITMapCore // 设置中心点

  setZoom(zoom: number): ITMapCore // 设置地图缩放级别。

  setRotation(rotation: number): ITMapCore // 设置地图水平面上的旋转角度。

  setPitch(pitch: number): ITMapCore // 设置地图俯仰角。

  setScale(scale: number): ITMapCore // 设置地图显示比例。

  setOffset(offset: ITMapPointXY): ITMapCore // 设置地图与容器偏移量，Object的格式为{x: number, y: number}，x方向向右偏移为正值，y方向向下偏移为正值。

  setDraggable(draggable: boolean): ITMapCore // 设置地图是否支持拖拽。

  setScrollable(scrollable: boolean): ITMapCore // 设置地图是否支持滚轮缩放。

  setMaxZoom(maxZoom: number): ITMapCore // 设置地图最大缩放级别，支持3～20。

  setMinZoom(minZoom: number): ITMapCore // 设置地图最小缩放级别，支持3～20。

  setPitchable(pitchable: boolean): ITMapCore // 设置地图是否支持改变俯仰角度。在2D视图下，此方法无效。

  setRotatable(rotatable: boolean): ITMapCore // 设置地图是否支持改变旋转角度。在2D视图下，此方法无效。

  setDoubleClickZoom(doubleClickZoom: boolean): ITMapCore // 设置地图是否支持双击缩放。

  setBoundary(boundary: ITMapLatLngBounds): ITMapCore // 设置地图限制边界，拖拽、缩放等操作无法将地图移动至边界外。

  setViewMode(viewMode: string): ITMapCore // 设置地图视图模式。

  setBaseMap(baseMap: ITMapBaseMap | ITMapBaseMap[]): ITMapCore // 动态设置地图底图，BaseMap目前支持矢量底图（VectorBaseMap）、卫星底图（SatelliteBaseMap）、路况底图（TrafficBaseMap），可以使用数组形式实现多种底图叠加。

  setMapStyleId(mapStyleId: string): ITMapCore // 动态设置个性化地图样式。

  panTo(latLng: ITMapLatLng, opts: ITMapEaseOptions): ITMapCore // 将地图中心平滑移动到指定的经纬度坐标。

  zoomTo(zoom: number, opts: ITMapEaseOptions): ITMapCore // 平滑缩放到指定级别。

  rotateTo(rotation: number, opts: ITMapEaseOptions): ITMapCore // 平滑旋转到指定角度。

  pitchTo(pitch: number, opts: ITMapEaseOptions): ITMapCore // 平滑变化到指定俯仰角度。

  easeTo(mapStatus: SpecialValueMap<string>, opts: ITMapEaseOptions): ITMapCore // 平滑过渡到指定状态，mapStatus为key-value格式，可以设定center、zoom、rotation、pitch。

  fitBounds(
    bounds: ITMapLatLngBounds,
    options: ITMapFitBoundsOptions,
  ): ITMapCore // 根据指定的地理范围调整地图视野。

  getCenter(): ITMapLatLng // 获取中心点

  getZoom(): number // 获取地图缩放级别。

  getRotation(): number //	获取地图水平面上的旋转角度。

  getPitch(): number // 获取地图俯仰角度。

  getBounds(): ITMapLatLngBounds //	返回当前地图的视野范围，该视野范围实际会大于等于地图的可视区域范围，尤其是当地图发生旋转和俯仰变化时，得到的是一个当前视野范围的最小外包矩形。

  getScale(): number // 获取地图显示比例。

  getOffset(): ITMapPointXY //	获取地图与容器的偏移量Object的格式为 {x:number, y:number}，x方向向右偏移为正值，y方向向下偏移为正值。

  getDraggable(): boolean //	获取地图是否支持拖拽。

  getScrollable(): boolean //	获取地图是否支持滚轮缩放。

  getDoubleClickZoom(): boolean //	获取地图是否支持双击缩放。

  getBoundary(): ITMapLatLngBounds //	获取地图限制边界。

  addControl(control: ITMapControl): ITMapCore //	添加控件到地图,传入控件对象。

  removeControl(id: string): ITMapCore //	从地图容器移出控件,默认控件的id列表参考 DEFAULT_CONTROL_ID

  getControl(id: string): ITMapControl //	根据控件id获取对应的控件对象,默认控件的id列表参考 DEFAULT_CONTROL_ID。

  getViewMode(): string // 获取地图视图模式。

  getBaseMap(): ITMapBaseMap | ITMapBaseMap[] // 获取当前的底图类型。

  // getIndoorManager()	IndoorManager	获取室内地图管理器。
  destroy() //	销毁地图。

  projectToContainer(latLng: ITMapLatLng): ITMapPointXY //	经纬度坐标转换为容器像素坐标，容器像素坐标系以地图容器左上角点为原点。

  unprojectFromContainer(pixel: ITMapPointXY): ITMapLatLng //	容器像素坐标转换为经纬度坐标。

  moveLayer(layerId: string, level: LAYER_LEVEL): ITMapCore //	修改图层层级顺序，根据输入 LAYER_LEVEL 常量调整 layerId 对应图层的渲染层级 ，其中layerId可以通过图层getId方法获取。注: 设置ZIndex 可调整同一大类层级下的不同图层顺序，此方法则是调整目标图层的大类层级。

  on(eventName: string, listener: (e: MapEvent) => void): ITMapCore //	添加listener到eventName事件的监听器数组中。

  off(eventName: string, listener: (e: MapEvent) => void): ITMapCore //	从eventName事件的监听器数组中移除指定的listener。
}

declare interface ITMap {
  Map: new (
    container: HTMLElement,
    options: ITMapOptions,
  ) => ITMapCore // 地图核心类
  LatLng: new (
    lng: string,
    lat: string,
  ) => ITMapLatLng // 经纬度
  MultiMarker: new (
    option: ITMapMultiMarkerOption,
  ) => ITMapMultiMarker // 标注
  MarkerStyle: new (
    option: ITMapMarkerStyleOption,
  ) => ITMapMarkerStyle // 标注样式
  MultiLabel: new (
    option: ITMapMultiLabelOption,
  ) => ITMapMultiLabel // 文本标注
  LabelStyle: new (
    option: ITMapLabelStyleOption,
  ) => ITMapLabelStyle // 文本标注样式
}
