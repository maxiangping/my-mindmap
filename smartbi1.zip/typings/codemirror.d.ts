/** @format */

declare module 'codemirror' {
  type HintDataItem = Record<string, string[]>
  interface HintData {
    tables: HintDataItem<string[]>
  }

  interface CodeMirrorEle {
    el: HTMLElement
    value: string
    hint: HintData
    setValue: (value: string) => void
    setOption: (type: string, hint: HintData) => void
    on: (eventType: string, handle: () => void) => void
    getValue: () => string
  }
  interface CodeMirrorModel {
    Pass: string
    innerMode: (a: string, b: string) => CodeMirrorState
    fromTextArea: (ele: Element, options: CodeMirrorOptions) => CodeMirrorEle
  }
  interface CodeMirrorState {
    state: {
      tagName: string
    }
  }
  interface CodeMirrorOptions {
    [property: string]:
      | boolean
      | string
      | number
      | ((cm: CodeMirrorCM, pred: () => string | boolean) => string)
      | ((cm: CodeMirrorCM) => void)
      | CodeMirrorOptions
  }

  interface HintOption {
    tables: string
    hint: string[]
  }
}
