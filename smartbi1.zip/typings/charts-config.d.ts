/** @format */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type IData = Record<string, any>

declare interface IDataItem {
  label: string
  value: string | number
  color?: string
}

declare interface IChartConfigure {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [index: string]: any

  title?: string
  containerSize?: string
  componentName?: string
  chartType?: string
  dataUrl?: string
  taskName?: string
  ref?: string
  assist_data?: string | number // 辅助数据
  thumbUrl?: string
  key?: string
  chartOption?: IData
  dataSource?: IData
  // 请求接口需要
  url?: string // 接口名称
  datasetId?: number // 数据集id
  cfg?: IData | string // 后台配置文件
  reload?: boolean

  flatmap?: (dataSource: IData) => IData | void

  hasOwnProperty(name: string): boolean
}

declare interface ITabItems {
  name: string
  charts: IChartConfigure[]

  hasOwnProperty(name: string): boolean
}

declare interface IChartBuilderConfigure<T = ITabItems | IChartConfigure> {
  caption: string
  subcaption: string
  dataUrl?: string
  items: T[]
}

declare interface IFCOption {
  dataFormat: string
  height: string
  maxHeight: string
  type: string
  width: string
}

declare interface IFCDSChart {
  caption?: string
  subcaption?: string
  sumText?: string
  divLineAlpha?: string | number
  divLineThickness?: string | number
  labelFontColor?: string
  numberPrefix?: string
  numbersuffix?: string
  outCnvBaseFontColor?: string
  paletteColors?: string
  plottooltext?: string
  subCaption?: string
  theme?: string
  valueFontColor?: string
  xAxisName?: string
  yAxisMaxValue?: string
  yAxisNameFontColor?: string
  showValues?: boolean | string
  showYAxisValues?: boolean
  divLineIsDashed?: string | boolean
  dashed?: boolean
  width?: string
  height?: string
  xAxisNameAlpha?: number
  maxBarHeight?: string
  legendPosition?: string
  alignLegendWithCanvas?: string
  legendIconSides?: string
  legendIconScale?: string
  maxLabelHeight?: string
  maxColWidth?: string
  divLineColor?: string
  numbersuffix?: string
  xAxisLineColor?: string
  xAxisPosition?: string
  xAxisLineThickness?: string
  showXAxisLine?: string
  maxLabelHeight?: string
  divLineThickness?: number
  showVDivLineValues?: number
  showLegend?: string
  labelFontSize?: string
  showLabels?: string
  baseFontSize?: string
  captionPadding?: string
  chartLeftMargin?: string
  chartRightMargin?: string
  chartTopMargin?: string
  chartBottomMargin?: string
  placeValuesInside?: number
  maxLabelWidthPercent?: number
  canvasRightPadding?: number
  hideTitle?: string
  horizontalPadding?: string
  legendItemFontBold?: string
  legendItemFontSize?: string
  legenditemfontcolor?: string
  legendpadding?: string
  nodeLabelFontSize?: string
  nodeLabelFontSize?: string
  plotToolText?: string
  plotbordercolor?: string
  plotborderthickness?: string
  showChildLabels?: string
  showParent?: string
  slantLabel?: string
  valueFontSize?: string
  verticalPadding?: string
  xAxisNameFontSize?: string
  showCaption?: string
  captionFontSize?: string
  captionOnTop?: string
  verticalPadding?: string
  slicingMode?: string
  rotateLabels?: string
  drawAnchors?: string
  legendNumColumns?: number
  startingAngle?: string
  yAxisValueFontSize?: string
  pieRadius?: string
  doughnutRadius?: string
  enableSmartLabels?: number
  labelDistance?: number
  yAxisNameFontSize?: string
  radius3D?: number
  syaxisname?: string
}

declare interface IFCDSDatasetItem {
  seriesname: string
  data: { value: string; displayValue: string }[]
}

type IFCDSDataset = IFCDSDatasetItem[]

declare interface IFCDSData {
  displayValue?: string
  label: string
  value: string
  sValue?: number
  displayvalue?: string
}

declare interface IFCDSColumn {
  label: string
  value: string
}

declare interface IFCDCategoriesItem {
  label: string
  showLabel?: string
  toolText?: string
  font?: string
  fontColor?: string
  fontSize?: number
  fontBold?: string
  fontItalic?: string
  bgColor?: string
  borderColor?: string
  alpha?: number
  bgAlpha?: number
  borderAlpha?: number
  borderPadding?: number
  borderRadius?: number
  borderThickness?: number
  borderDashed?: string
  borderDashLen?: number
  borderDashGap?: number
}

declare interface IFCDCategories {
  category: IFCDCategoriesItem[]
}

declare interface IFCDataSource {
  chart: IFCDSChart
  data: IFCDSData[]
  column?: IFCDSColumn[]
  dataset?: IFCDSDataset
  categories?: IFCDCategories[]
}

declare interface IFusionChartData {
  chartOption?: IFCOption
  chartType?: string
  componentName: string
  containerSize?: string
  dataSource?: IFCDataSource
  dataUrl?: string
  key?: string
  title?: string
  url?: string
}

declare interface IFCMapCitiesConfig {
  label: string
  posisiton: number[]
}
declare interface IFCMapProvinceConfig {
  label: string
  id: string
  position: number[]
  cities: Record<string, IFCMapCitiesConfig>
}

declare interface IFCMapClickEvent {
  cancelled: boolean
  data: IFCMapClickEventData
  defaultPrevented: boolean
  detachHandler: () => void
  detached: boolean
  eventId: number
  eventType: string
  originalEvent: MouseEvent
  preventDefault: () => void
  stopImmediatePropagation: () => void
  stopPropagation: () => void
  type: string
}
