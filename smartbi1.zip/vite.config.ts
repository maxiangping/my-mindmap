/** @format */

import { vue2HMR } from '@lancercomet/vite-plugin-vue2-hmr'
import { PluginOption, defineConfig, loadEnv } from 'vite'
import swc from './cli/swcpkg'
import vue from '@vitejs/plugin-vue2'
import { createHtmlPlugin } from 'vite-plugin-html'
import path from 'path'
import style from './templates/css'
import { proxyCreator } from './vite.proxy.mjs'
// import compress from 'vite-plugin-compress'
import legacy from '@vitejs/plugin-legacy'

const resolve = (dir: string) => {
  return path.join(__dirname, dir)
}

const Theme = {
  light: 'light',
  dark: 'dark',
  none: '',
}
const themeMap = {
  datagrip: Theme.dark,
  system: Theme.dark,
  reportplat: Theme.dark,
  crm: Theme.dark,
  home: Theme.dark,
  managercrm: Theme.dark,
  boardshare: Theme.dark,
  kmind: Theme.dark,
  questionnaire: Theme.dark,
  qrcode: Theme.dark,
  smartboard: Theme.dark,
}

type ThemeMapType = typeof themeMap

const getTheme = (project: keyof ThemeMapType) => {
  return themeMap[project]
}

// https://vitejs.dev/config/
export default defineConfig(async ({ mode }) => {
  // const keySet = await createLru()

  const env = loadEnv(mode, process.cwd(), '')

  const isDebug = env.NODE_ENV === 'development'

  const appName = env.VITE_APP_NAME
  const publicPath = env.VITE_APP_PUBLIC_PATH
  // const cdnPath = env.VITE_APP_CDN_PATH
  // const appHttpUrl = env.VITE_APP_HTTPURL
  // const rewriteAppHttpUrlKey = `^${appHttpUrl}`
  const projectName = env.VITE_APP_PROJECT_NAME

  // const webInf = process.env.VITE_WEB_INF
  const nodeEnv = env.NODE_ENV
  const sourceDir = env.VITE_SOURCE_DIR
  // 主题色
  const themeColor = env.VITE_APP_THEME

  const isProduction = nodeEnv === 'production'
  // 全局的接口项目配置 启动单个项目false  启动多个项目true
  const VITE_APP_OPEN_MUTIL_PROJECT = env.VITE_APP_OPEN_MUTIL_PROJECT === '1'

  const proxy = proxyCreator(projectName, VITE_APP_OPEN_MUTIL_PROJECT)

  const plugins: PluginOption[] = [
    swc({
      swcrc: true,
      root: __dirname,
      sourceMaps: isDebug,
      inlineSourcesContent: isDebug,
    }),
    vue(),
    createHtmlPlugin({
      minify: isDebug,
      /**
       * After writing entry here, you will not need to add script tags in `index.html`, the original tags need to be deleted
       * @default src/main.ts
       */
      entry: `/src/apps/${sourceDir}/main.ts`,
      /**
       * If you want to store `index.html` in the specified folder, you can modify it, otherwise no configuration is required
       * @default index.html
       */
      template: 'templates/index.html',

      /**
       * Data that needs to be injected into the index.html ejs template
       *  <script type="module" src="/src/main.ts"></script>
       */
      inject: {
        data: {
          appName,
          injectStyle: style,
          publicPath,
          // injectScript: script(projectName, cdnPath),
          projectName,
        },
      },
    }),
    // AutoImport({
    //   dts: './src/auto-imports.d.ts',
    //   resolvers: [
    //     ElementUiResolver({
    //       importStyle: 'css',
    //     }),
    //   ],
    // }),
    // Components({
    //   dts: './src/components.d.ts',
    //   resolvers: [
    //     ElementUiResolver({
    //       importStyle: 'css',
    //     }),
    //   ],
    // }),
  ]

  const isWin32 = process.platform === 'win32'

  if (isProduction) {
    plugins.unshift(
      legacy({
        targets: ['defaults', 'not dead', 'Safari > 10.1', 'ios > 10.3'],
        renderLegacyChunks: false,
        modernPolyfills: ['es/global-this'],
      }),
      // compress()
    )
    // plugins.push({
    //   ...esbuild({
    //     target: 'chrome70',
    //     // 如有需要可以在这里加 js ts 之类的其他后缀
    //     include: /\.vue|\.js|\.ts|\.tsx$/,
    //     loaders: {
    //       '.vue': 'js',
    //     },
    //     sourceMap: false,
    //   }),
    //   enforce: 'post',
    // })
  }

  if (isDebug) {
    plugins.push(vue2HMR())
  }

  return {
    esbuild: false,
    envPrefix: ['VITE', 'NODE'],
    base: publicPath,

    server: {
      host: '0.0.0.0',
      proxy,
      hmr: {
        protocol: 'ws',
        host: 'localhost',
      },
      watch: {
        ignored: [
          '**/node_modules/**',
          './built/**',
          './repository/**',
          './public/**',
          './plugins/**',
        ],
      },
    },
    build: {
      sourcemap: isDebug,
      minify: false,
      outDir: `built/${projectName}`,
      commonjsOptions: {
        transformMixedEsModules: true,
      },
      rollupOptions: {
        external: ['vfs_fonts', 'fusioncharts'],
        output: {
          assetFileNames: (chunkInfo) => {
            return 'assets/[name].[hash][extname]'
          },
          chunkFileNames: (chunkInfo) => {
            return 'bundle/[name].[hash].js'
          },
          manualChunks: {
            framework: [
              'vue',
              'vuex',
              'vue-class-component',
              'vue-property-decorator',
            ],
          },
        },
      },
    },
    plugins,
    resolve: {
      alias: {
        '@': path.resolve(__dirname, isWin32 ? 'src' : '/src'),
        vue: 'vue/dist/vue.runtime.esm.js',
        'vue-class-component':
          'vue-class-component/dist/vue-class-component.esm.js',
        vuex: 'vuex/dist/vuex.esm.js',
      },
      preserveSymlinks: true,
    },
    css: {
      postcss: './postcss.config.js',
      modules: {
        scopeBehaviour: 'local',
        generateScopedName: '[name]__[local]___[hash:base64:8]',
        hashPrefix: 'prefix',
      },
      preprocessorOptions: {
        less: {
          javascriptEnabled: true,
          modifyVars: {
            hack: `
            true;
            @import (reference) "${resolve('./src/variables.less')}";
            @import (reference) "${resolve(
              `./src/assets/stylesheets/theme/${getTheme(
                projectName as keyof ThemeMapType,
              )}.less`,
            )}";
            @import (reference) "${resolve(
              `./src/assets/stylesheets/theme_color/${themeColor}.less`,
            )}";
            `,
          },
        },
      },
      devSourcemap: true,
    },
    optimizeDeps: {
      include: [],
      exclude: ['wasm-security', 'wasm-qrcode'],
    },
  }
})
