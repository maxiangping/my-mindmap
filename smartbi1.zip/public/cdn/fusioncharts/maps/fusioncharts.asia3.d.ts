
import { FusionChartStatic } from 'fusioncharts';

declare namespace Asia3 {}
declare var Asia3: (H: FusionChartStatic) => FusionChartStatic;
export = Asia3;
export as namespace Asia3;

