
import { FusionChartStatic } from 'fusioncharts';

declare namespace Hunan {}
declare var Hunan: (H: FusionChartStatic) => FusionChartStatic;
export = Hunan;
export as namespace Hunan;

