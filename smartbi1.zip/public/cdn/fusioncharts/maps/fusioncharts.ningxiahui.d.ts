
import { FusionChartStatic } from 'fusioncharts';

declare namespace Ningxiahui {}
declare var Ningxiahui: (H: FusionChartStatic) => FusionChartStatic;
export = Ningxiahui;
export as namespace Ningxiahui;

