
import { FusionChartStatic } from 'fusioncharts';

declare namespace Neimongol {}
declare var Neimongol: (H: FusionChartStatic) => FusionChartStatic;
export = Neimongol;
export as namespace Neimongol;

