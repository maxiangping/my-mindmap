
import { FusionChartStatic } from 'fusioncharts';

declare namespace Zhejiang {}
declare var Zhejiang: (H: FusionChartStatic) => FusionChartStatic;
export = Zhejiang;
export as namespace Zhejiang;

