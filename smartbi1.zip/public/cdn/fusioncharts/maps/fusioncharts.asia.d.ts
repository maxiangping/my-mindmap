
import { FusionChartStatic } from 'fusioncharts';

declare namespace Asia {}
declare var Asia: (H: FusionChartStatic) => FusionChartStatic;
export = Asia;
export as namespace Asia;

