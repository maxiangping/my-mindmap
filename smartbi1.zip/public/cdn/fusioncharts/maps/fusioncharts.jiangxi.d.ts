
import { FusionChartStatic } from 'fusioncharts';

declare namespace Jiangxi {}
declare var Jiangxi: (H: FusionChartStatic) => FusionChartStatic;
export = Jiangxi;
export as namespace Jiangxi;

