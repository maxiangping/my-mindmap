
import { FusionChartStatic } from 'fusioncharts';

declare namespace Shanxi {}
declare var Shanxi: (H: FusionChartStatic) => FusionChartStatic;
export = Shanxi;
export as namespace Shanxi;

