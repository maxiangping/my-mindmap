
import { FusionChartStatic } from 'fusioncharts';

declare namespace World8 {}
declare var World8: (H: FusionChartStatic) => FusionChartStatic;
export = World8;
export as namespace World8;

