
import { FusionChartStatic } from 'fusioncharts';

declare namespace China {}
declare var China: (H: FusionChartStatic) => FusionChartStatic;
export = China;
export as namespace China;

