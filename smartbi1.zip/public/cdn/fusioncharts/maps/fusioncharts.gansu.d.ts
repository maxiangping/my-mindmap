
import { FusionChartStatic } from 'fusioncharts';

declare namespace Gansu {}
declare var Gansu: (H: FusionChartStatic) => FusionChartStatic;
export = Gansu;
export as namespace Gansu;

