
import { FusionChartStatic } from 'fusioncharts';

declare namespace Hongkong {}
declare var Hongkong: (H: FusionChartStatic) => FusionChartStatic;
export = Hongkong;
export as namespace Hongkong;

