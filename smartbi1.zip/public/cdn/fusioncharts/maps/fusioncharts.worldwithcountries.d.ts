
import { FusionChartStatic } from 'fusioncharts';

declare namespace Worldwithcountries {}
declare var Worldwithcountries: (H: FusionChartStatic) => FusionChartStatic;
export = Worldwithcountries;
export as namespace Worldwithcountries;

