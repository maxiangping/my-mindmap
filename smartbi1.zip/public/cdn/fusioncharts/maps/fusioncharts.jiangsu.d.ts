
import { FusionChartStatic } from 'fusioncharts';

declare namespace Jiangsu {}
declare var Jiangsu: (H: FusionChartStatic) => FusionChartStatic;
export = Jiangsu;
export as namespace Jiangsu;

