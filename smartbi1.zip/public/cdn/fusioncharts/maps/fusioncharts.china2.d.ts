
import { FusionChartStatic } from 'fusioncharts';

declare namespace China2 {}
declare var China2: (H: FusionChartStatic) => FusionChartStatic;
export = China2;
export as namespace China2;

