
import { FusionChartStatic } from 'fusioncharts';

declare namespace Tianjin {}
declare var Tianjin: (H: FusionChartStatic) => FusionChartStatic;
export = Tianjin;
export as namespace Tianjin;

