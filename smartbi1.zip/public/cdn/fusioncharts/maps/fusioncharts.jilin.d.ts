
import { FusionChartStatic } from 'fusioncharts';

declare namespace Jilin {}
declare var Jilin: (H: FusionChartStatic) => FusionChartStatic;
export = Jilin;
export as namespace Jilin;

