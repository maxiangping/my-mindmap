
import { FusionChartStatic } from 'fusioncharts';

declare namespace Guizhou {}
declare var Guizhou: (H: FusionChartStatic) => FusionChartStatic;
export = Guizhou;
export as namespace Guizhou;

