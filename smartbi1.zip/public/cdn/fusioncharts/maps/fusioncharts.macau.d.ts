
import { FusionChartStatic } from 'fusioncharts';

declare namespace Macau {}
declare var Macau: (H: FusionChartStatic) => FusionChartStatic;
export = Macau;
export as namespace Macau;

