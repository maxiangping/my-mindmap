/** @format */

import fs from 'fs'
import path from 'path'

const cssContent = fs.readFileSync(path.join(__dirname, './style.css'))
const style = `<style type="text/css">${cssContent}</style>`

export default style
