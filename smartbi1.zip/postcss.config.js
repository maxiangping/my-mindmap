/** @format */

module.exports = {
  plugins: {
    autoprefixer: {
      grid: true,
    },
    'postcss-import': true,
    'postcss-url': true,
    'postcss-custom-properties': true,
    'postcss-sorting': {
      order: [
        'custom-properties',
        'dollar-variables',
        'declarations',
        'at-rules',
        'rules',
      ],
      'properties-order': 'alphabetical',
      'unspecified-properties-position': 'bottom',
    },
  },
}
