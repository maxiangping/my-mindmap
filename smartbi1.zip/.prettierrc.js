/** @format */

module.exports = {
  arrowParens: 'always',
  bracketSameLine: true,
  bracketSpacing: true,
  embeddedLanguageFormatting: 'off',
  endOfLine: 'lf',
  eslintIntegration: true,
  insertPragma: true,
  printWidth: 120,
  quoteProps: 'preserve',
  semi: false,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'es5',
  useTabs: false,
}
