/** @format */

// 全局的接口项目配置 启动单个项目false  启动多个项目true
// const VITE_APP_OPEN_MUTIL_PROJECT = process.env.VITE_APP_OPEN_MUTIL_PROJECT === '1'

// 锦平本地
// target: 'http://172.16.23.22:80',
// 综合测试服务器
// target: 'http://172.16.23.216:9090',
// 正式数据
// target: 'http://10.18.1.31:8100',
// 测试服务器
// target: 'http://10.18.1.31:8080',
// 开发环境
const proxyIPTable = {
  // datagrip: 'http://172.16.163.8:8999',
  datagrip: 'http://10.18.1.31:11903',
  // datagrip: 'http://10.18.1.31:11902',
  // datagrip: 'http://172.16.23.87:8999', //刘强本地
  // datagrip: 'http://172.16.22.135:8099', // 小田本地
  // system: 'http://172.16.163.2:11101',
  // system: 'http://172.16.163.6:11906',
  system: 'http://10.18.1.31:11903',
  // system: 'http://172.16.249.14:8999', // 祝高本地
  // system: 'http://172.16.23.87:11901',
  // reportplat: 'http://172.16.23.87:11901',
  // reportplat: 'http://172.16.163.6:11906',
  // reportplat: 'http://10.18.1.31:11901',
  reportplat: 'http://172.16.163.5:21908', // 测试环境
  // reportplat: 'http://172.16.23.87:21901', // 刘强本地
  // reportplat: 'http://172.16.163.6:11909', // 开发环境
  // crm: 'http://172.16.23.87:11901',
  crm: 'http://172.16.163.5:21903',
  // crm: 'http://172.16.22.135:8999', // 小田本地
  // crm: 'http://172.16.163.5:21903',  // 测试环境
  home: 'http://10.18.1.31:11101',
  // managercrm: 'http://172.16.163.8:8098',
  managercrm: 'http://10.18.1.31:11904',
  boardshare: 'http://10.18.1.31:11101',
  // boardshare: 'http://172.16.163.6:11906',
  // kmind: 'http://172.16.163.6:11906',
  kmind: 'http://172.16.163.7:10906',
  // kmind: 'http://172.16.163.5:31905', //8400大数据量
  // kmind: 'http://172.16.23.87:8999',
  // kmind: 'http://172.16.163.5:21905', // 测试地址
  // kmind: 'http://172.16.22.253:11906', // 海洋本地
  questionnaire: 'http://172.16.163.6:11906',
  // questionnaire: 'http://172.16.163.5:21905', // 测试地址
  commonfile: 'http://172.16.163.6:11907',
  qrcode: 'http://10.18.1.31:11903',
  smartboard: 'http://172.16.163.5:21908', // 测试环境
  // smartboard: 'http://172.16.163.6:11909', // 开发环境
  // smartboard: 'http://172.16.23.87:11903', // 刘强本地
}
// 测试环境

const proxyProject = {
  datagrip: ['system', 'datagrip', 'reportplat'],
  system: ['system'],
  reportplat: ['system', 'reportplat'],
  crm: ['system', 'crm', 'reportplat', 'datagrip'],
  home: ['system', 'home'],
  managercrm: ['system', 'managercrm', 'crm', 'reportplat', 'datagrip'],
  boardshare: ['system', 'boardshare', 'reportplat'],
  kmind: ['system', 'kmind', 'reportplat', 'commonfile'],
  questionnaire: ['questionnaire', 'system'],
  qrcode: ['qrcode', 'crm', 'reportplat', 'system'],
  smartboard: ['smartboard', 'reportplat'],
}
const proxyCreatorItem = (runtimeName, VITE_APP_OPEN_MUTIL_PROJECT) => {
  const ossProjectName = runtimeName === 'datagrip' ? 'datagrip' : 'reportplat'
  const ossKey = `/oss/${
    VITE_APP_OPEN_MUTIL_PROJECT ? ossProjectName : runtimeName
  }`
  const ossRewriteKey = `^${ossKey}`
  const ossKeyRuntimeName = `/oss/${runtimeName}`
  const apiKey = `/${runtimeName}_api`
  const apiRewriteKey = `^${apiKey}`
  const target = proxyIPTable[runtimeName]

  return {
    [ossKey]: {
      target:
        proxyIPTable[
          VITE_APP_OPEN_MUTIL_PROJECT ? ossProjectName : runtimeName
        ],
      changeOrigin: true,
      rewrite: (path) => {
        // if (VITE_APP_OPEN_MUTIL_PROJECT) return path.replace(ossKey, `/${ossProjectName}_api`)
        const reg = new RegExp(String.raw`${ossRewriteKey}`)
        return path.replace(
          reg,
          VITE_APP_OPEN_MUTIL_PROJECT ? `/${ossProjectName}_api` : '',
        )
      },
      // pathRewrite: {
      //   // [ossRewriteKey]: `/${ossProjectName}_api`,
      //   [ossRewriteKey]: VITE_APP_OPEN_MUTIL_PROJECT ? `/${ossProjectName}_api` : '',
      // },
    },
    [ossKeyRuntimeName]: {
      target,
      changeOrigin: true,
      rewrite: (path) => {
        // if (VITE_APP_OPEN_MUTIL_PROJECT) return path
        const reg = new RegExp(String.raw`${ossKeyRuntimeName}`)
        return path.replace(reg, VITE_APP_OPEN_MUTIL_PROJECT ? apiKey : '')
      },
      // pathRewrite: {
      //   [ossKeyRuntimeName]: VITE_APP_OPEN_MUTIL_PROJECT ? apiKey : '',
      // },
    },
    [apiKey]: {
      target,
      ws: true,
      changeOrigin: true,
      secure: false,
      rewrite: (path) => {
        // if (VITE_APP_OPEN_MUTIL_PROJECT) return path
        const reg = new RegExp(String.raw`${apiRewriteKey}`)
        return path.replace(reg, VITE_APP_OPEN_MUTIL_PROJECT ? apiKey : '')
      },
      // pathRewrite: {
      //   // [apiRewriteKey]: apiKey,
      //   [apiRewriteKey]: VITE_APP_OPEN_MUTIL_PROJECT ? apiKey : '',
      // },
    },
  }
}

export const proxyCreator = (runtimeName, VITE_APP_OPEN_MUTIL_PROJECT) => {
  const proxyNames = proxyProject[runtimeName]
  const proxyList = proxyNames.map((pName) =>
    proxyCreatorItem(pName, VITE_APP_OPEN_MUTIL_PROJECT),
  )
  return Object.assign(...proxyList)
}

// "resolutions": {
//   "terser": "npm:@swc/core"
// },
